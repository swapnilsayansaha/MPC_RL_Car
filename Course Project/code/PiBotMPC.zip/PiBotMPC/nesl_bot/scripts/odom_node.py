#!/usr/bin/env python

import numpy as np
import math
import sys, os
import rospy 
from nesl_bot.msg import enc as EncoderMsg
from geometry_msgs.msg import Pose, PoseStamped, TransformStamped
from sensor_msgs.msg import Joy
from nav_msgs.msg import Odometry
from tf.transformations import quaternion_from_euler
import tf
sys.path.append("/home/natsubuntu/catkin_ws/src/nesl_bot/scripts/Util/Graphics")
sys.path.append("/home/natsubuntu/catkin_ws/src/nesl_bot/scripts/Util/Control/process_models")
from wheel_encoder_models import ackerman_steering_model
import SO3Rotation as SO3

joy_val = 0
ack_val = 0
ack_steer_max = 35.0 * np.pi / 180.0 
state = np.matrix([0,0,0]).reshape((3,1))

rospy.init_node("odom_node", anonymous=True)
pose_pub = rospy.Publisher("/odom", Odometry, queue_size=10)
tf_pub = tf.TransformBroadcaster()
odomMsg = Odometry()
tfMsg = TransformStamped()

time_cur = 0
time_last = 0
dt = .025 # Our best guess

def joy_2_angle(joy_val):
    ack_ang = ack_steer_max*joy_val
    return ack_ang

def joy_ack_callback(msg):
    global joy_val, ack_val
    joy_val = msg.axes[3]
    ack_val = joy_2_angle(joy_val)
    #print("Ack Angle: ", ack_val)

def encoder_ack_callback(msg):
    global ack_val, state, time_cur, time_last, dt,odomMsg
    dDl = msg.left_wheel_dist_dt
    dDr = msg.right_wheel_dist_dt
    phi = ack_val
    u = np.matrix([dDl,dDr,phi]).reshape((3,1))
    time_cur = msg.header.stamp
    if time_last == 0:
        time_last = time_cur
    else:
        dt = (time_cur - time_last).to_sec()
    
    # Propogate prior using control
    yaw_t = np.asscalar(state[2])
    state = ackerman_steering_model(state, u, dt) # Prior
    state = np.array(state).reshape(-1)
    yaw_t1 = np.asscalar(state[2])
    
    # Publish tf
    tfMsg.header.stamp = time_cur
    tfMsg.header.frame_id = "odom"
    tfMsg.child_frame_id = "base_link"
    tfMsg.transform.translation.x = state[0]
    tfMsg.transform.translation.y = state[1]
    tfMsg.transform.translation.z = 0
    #quat = SO3.euler_angles_to_quaternion(state[2], 0, 0)
    quat = quaternion_from_euler(0, 0, state[2])

    tfMsg.transform.rotation.w = quat[3]
    tfMsg.transform.rotation.x = quat[0]
    tfMsg.transform.rotation.y = quat[1]
    tfMsg.transform.rotation.z = quat[2]
    tf_pub.sendTransformMessage(tfMsg)

    # Publish Pose
    odomMsg.header.stamp = time_cur
    odomMsg.header.frame_id = "odom"
    odomMsg.pose.pose.position.x = state[0]
    odomMsg.pose.pose.position.y = state[1]
    odomMsg.pose.pose.position.z = 0
    odomMsg.pose.pose.orientation.w = quat[3]
    odomMsg.pose.pose.orientation.x = quat[0]
    odomMsg.pose.pose.orientation.y = quat[1]
    odomMsg.pose.pose.orientation.z = quat[2]
    odomMsg.twist.twist.linear.x = u[0] / dt
    odomMsg.twist.twist.linear.x = u[1] / dt
    odomMsg.twist.twist.angular.z = (yaw_t1 - yaw_t) / dt
    pose_pub.publish(odomMsg)
    
    # Save time
    time_last = time_cur


ack_sub = rospy.Subscriber("/joy", Joy, callback=joy_ack_callback, queue_size=10)
enc_sub = rospy.Subscriber("/encoder_ticks",EncoderMsg,callback=encoder_ack_callback,queue_size=20)
rospy.spin()

