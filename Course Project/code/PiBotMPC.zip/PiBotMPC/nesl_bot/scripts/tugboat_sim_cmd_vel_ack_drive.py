#!/usr/bin/env python
import rospy
import numpy 
#from gekko import GEKKO
#import matplotlib.pyplot as plt
#from geometry_msgs.msg import Twist, Quaternion, PoseStamped
from sensor_msgs.msg import Joy
from ackermann_msgs.msg import AckermannDriveStamped
#import tf
#import sys, os 
import numpy as np

rospy.init_node("tugboat_sim_cmd_vel_ack_drive", anonymous=True)

#Abusing Twist message to make it vx, vy, ang_z -> VL, VR, Phi
cmd_msg = AckermannDriveStamped()
cmd_msg.drive.speed = 0.0
cmd_msg.drive.steering_angle = 0.0
cmd_msg.drive.jerk = 0.0
cmd_msg.drive.acceleration = 0.0

cmd_pub = rospy.Publisher("/ackermann_cmd", AckermannDriveStamped, queue_size=5)
joy_msg = Joy()

def set_joy_cmd(msg):
    global cmd_msg, cmd_pub
    MAX_SPEED = 1.25 # m/s
    MAX_ANGLE = np.pi / 6.0
    cmd_msg.header.stamp = rospy.Time.now()
    cmd_msg.drive.speed = msg.axes[1] * MAX_SPEED
    cmd_msg.drive.steering_angle = msg.axes[3] * MAX_ANGLE

if __name__ == "__main__":
    cmd_sub = rospy.Subscriber("/joy", Joy, set_joy_cmd)
    rate = rospy.Rate(15)
    while not rospy.is_shutdown():
        cmd_pub.publish(cmd_msg)
        rate.sleep()