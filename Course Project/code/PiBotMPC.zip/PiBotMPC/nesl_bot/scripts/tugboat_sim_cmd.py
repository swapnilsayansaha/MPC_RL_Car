#!/usr/bin/env python
import rospy
import numpy 
from gekko import GEKKO
import matplotlib.pyplot as plt
from nav_msgs.msg import Odometry, Path
from geometry_msgs.msg import Twist, Quaternion, PoseStamped
from sensor_msgs.msg import Joy
import tf
import sys, os 
import numpy as np
import copy
sys.path.append("/home/natsubuntu/catkin_ws/src/nesl_bot/scripts/Util/Control/process_models")
from wheel_odometry_models import ackerman_steering_model_dtime, ackerman_steering_model_ctime


# Subscribe to cmd_vel and when we get it, update the model, and send the new TF
rospy.init_node("tugboat_sim_cmd", anonymous=True)

#Abusing Twist message to make it vx, vy, ang_z -> VL, VR, Phi
cmd_msg = Twist()
cmd_msg.linear.x = 0.0
cmd_msg.linear.y = 0.0
cmd_msg.linear.z = 0.0
cmd_msg.angular.x = 0.0
cmd_msg.angular.y = 0.0
cmd_msg.angular.z = 0.0

bc_Odom2BL = tf.TransformBroadcaster()
Odom2BL_lis = tf.TransformListener()
cmd_pub = rospy.Publisher("/cmd_vel", Twist, queue_size=5)
odom_pub = rospy.Publisher("/odom", Odometry, queue_size=10)
odom_msg = Odometry()
joy_msg = Joy()
hz = 20
dt = 1.0 / hz
rate = rospy.Rate(hz)

state = np.array([0.0,0.0,0.0])
nav_goal = np.array([0.0,0.0,0.0])
last_time = None
path_count = 0
    
def update_model_joy():
    global last_time, dt, state, cmd_msg

    # Time Update for dt
    time = rospy.Time.now()
    if last_time is None:
        last_time = time
    else:
        dt = (time - last_time).to_sec()
        last_time = time
    v = cmd_msg.linear.x
    phi = cmd_msg.angular.z
    # Apply Cmd Vel to EOM:
    u = np.matrix([v,phi]).reshape((2,1))
    dxdt = ackerman_steering_model_ctime(state, u, dt)
    state = np.matrix(state).reshape((3,1))
    state = state + dxdt * dt
    state = np.array(state).reshape(-1)
    # Now broadcast out to TF 
    q_new = tf.transformations.quaternion_from_euler(0,0,state[2])
    bc_Odom2BL.sendTransform((state[0], state[1], 0), q_new, rospy.Time.now(),"base_link","odom")
    
    odom_msg.header.stamp = time
    odom_msg.header.frame_id = "odom"
    odom_msg.child_frame_id = "base_link"
    odom_msg.pose.pose.position.x = state[0]
    odom_msg.pose.pose.position.y = state[1]
    odom_msg.pose.pose.position.z = 0
    odom_msg.pose.pose.orientation.x = q_new[0]
    odom_msg.pose.pose.orientation.y = q_new[1]
    odom_msg.pose.pose.orientation.z = q_new[2]
    odom_msg.pose.pose.orientation.w = q_new[3]
    odom_pub.publish(odom_msg)

def mpc_traj_follow(msg):
    global last_time, dt, state, cmd_msg, nav_goal, path_count
    path_count += 1
    if not (path_count % 2):
        return
    m = GEKKO()
    tf = 5
    intervals = int(tf / dt + 1)
    m.time = np.linspace(0,tf,intervals)

    # Controls 
    v = m.MV(value = cmd_msg.linear.x, lb= 0, ub=2)
    phi = m.MV(value = cmd_msg.angular.z, lb = -3.14 / 6, ub = 3.14 / 6)
    v.STATUS = 1 
    v.DCOST = 0.2
    v.DMAX = 10
    phi.STATUS = 1 
    phi.DCOST = 0.2
    phi.DMAX = 10

    # States 
    x0 = np.array(state)
    x1 = m.Var(value=x0[0])
    x2 = m.Var(value=x0[1])
    x3 = m.Var(value= x0[2]) 

    length = .14 # meters
    #Equations
    m.Equation(x1.dt() == v*m.cos(x3))
    m.Equation(x2.dt() == v*m.sin(x3))
    m.Equation(x3.dt() == v / length * m.tan(phi))

    # Format Path
    dum_x_in = np.linspace(0,tf,len(msg.poses))
    dum_x_out = np.linspace(0,tf,len(m.time))
    x1_refs_in = np.array([msg.poses[i].pose.position.x for i in range(len(msg.poses))])
    x2_refs_in = np.array([msg.poses[i].pose.position.y for i in range(len(msg.poses))])
    x1_refs_out = np.interp(dum_x_out, dum_x_in, x1_refs_in)
    x2_refs_out = np.interp(dum_x_out, dum_x_in, x2_refs_in)
    print( "Length of Formatted way-points: ", len(x1_refs_out))

    # Objective Function
    p1 = np.zeros(intervals)
    p1[-1] = 2
    p2 = np.ones(intervals) * .8
    p2[-1] = 0
    final = m.Param(value=p1)
    running = m.Param(value=p2)
    running_ref1 = m.Param(value=p2*x1_refs_out)
    running_ref2 = m.Param(value=p2*x2_refs_out)
    m.Obj((running_ref2 - running*x2)**2 + (running_ref1 - running*x1)**2 + (final*nav_goal[0] - final*x1)**2 + (final*nav_goal[1] -final*x2)**2 + (final*nav_goal[2] - final*x3)**2 ) 
    m.options.IMODE = 6
    m.options.NODES = 4 
    m.options.MV_TYPE = 1
    m.options.SOLVER = 3 
    m.solve()
    u_tape = np.vstack((v.value, phi.value)) 
    apply_sim_mpc_controls(x0,u_tape,dt)
   
def set_nav_goal_point(msg):
    global nav_goal
    nav_goal[0] = msg.pose.position.x
    nav_goal[1] = msg.pose.position.y
    qw = msg.pose.orientation.w
    qx = msg.pose.orientation.x
    qy = msg.pose.orientation.y
    qz = msg.pose.orientation.z

    xyz = tf.transformations.euler_from_quaternion([qx,qy,qz,qw])
    nav_goal[2] = xyz[2]
    #print("RPY: ", xyz)
    print("A New Goal Point of: ", nav_goal, " has been set!")

def set_joy_cmd(msg):
    global cmd_msg
    cmd_msg.linear.x = msg.axes[1] 
    cmd_msg.angular.z = msg.axes[3] * np.pi/6.0

def apply_sim_mpc_controls(x0,u_tape,dt):
    # Time Update for dt
    global state, cmd_msg
    ctrl_rate = rospy.Rate(int(1.0/dt))
    x = np.matrix(x0).reshape((3,1))
    for i in range(u_tape.shape[1]):
        v = u_tape[0,i]
        phi = u_tape[1,i]
        # Apply Cmd Vel to EOM:
        u = np.matrix([v,phi]).reshape((2,1))
        dxdt = ackerman_steering_model_ctime(x, u, dt)
        x = np.matrix(x).reshape((3,1))
        x = x + dxdt * dt
        x = np.array(x).reshape(-1)
        state = copy.deepcopy(x)
        # Now broadcast out to TF 
        q_new = tf.transformations.quaternion_from_euler(0,0,x[2])
        bc_Odom2BL.sendTransform((x[0], x[1], 0), q_new, rospy.Time.now(),"base_link","odom")
        
        odom_msg.header.stamp = rospy.Time().now()
        odom_msg.header.frame_id = "odom"
        odom_msg.child_frame_id = "base_link"
        odom_msg.pose.pose.position.x = x[0]
        odom_msg.pose.pose.position.y = x[1]
        odom_msg.pose.pose.position.z = 0
        odom_msg.pose.pose.orientation.x = q_new[0]
        odom_msg.pose.pose.orientation.y = q_new[1]
        odom_msg.pose.pose.orientation.z = q_new[2]
        odom_msg.pose.pose.orientation.w = q_new[3]
        odom_pub.publish(odom_msg)

        cmd_msg.linear.x = u_tape[0,i]
        cmd_msg.angular.z = u_tape[1,i]
        cmd_pub.publish(cmd_msg)
        ctrl_rate.sleep()
    cmd_msg.linear.x = 0
    cmd_msg.angular.z = 0
    cmd_pub.publish(cmd_msg)




#Modelled with Ackerman Steering Dynamics
#Needs Mutex for cmd_msg and cmd_pub...add
if __name__ == "__main__":
    cmd_sub = rospy.Subscriber("/joy", Joy, set_joy_cmd)
    path_sub = rospy.Subscriber("/move_base/NavfnROS/plan", Path, mpc_traj_follow, queue_size=1)
    nav_goal_sub = rospy.Subscriber("/move_base_simple/goal", PoseStamped, set_nav_goal_point)
    while(not rospy.is_shutdown()):
        update_model_joy()
        cmd_pub.publish(cmd_msg)
        rate.sleep()
        #print(state)
