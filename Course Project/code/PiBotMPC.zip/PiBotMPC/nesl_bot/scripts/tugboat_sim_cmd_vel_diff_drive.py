#!/usr/bin/env python
import rospy
import numpy 
from gekko import GEKKO
import matplotlib.pyplot as plt
from nav_msgs.msg import Odometry, Path
from geometry_msgs.msg import Twist, Quaternion, PoseStamped
from sensor_msgs.msg import Joy
import tf
import sys, os 
import numpy as np
import copy
sys.path.append("/home/natsubuntu/catkin_ws/src/nesl_bot/scripts/Util/Control/process_models")
from wheel_odometry_models import ackerman_steering_model_dtime, ackerman_steering_model_ctime


# Subscribe to cmd_vel and when we get it, update the model, and send the new TF
rospy.init_node("tugboat_sim_cmd_vel", anonymous=True)

#Abusing Twist message to make it vx, vy, ang_z -> VL, VR, Phi
cmd_msg = Twist()
cmd_msg.linear.x = 0.0
cmd_msg.linear.y = 0.0
cmd_msg.linear.z = 0.0
cmd_msg.angular.x = 0.0
cmd_msg.angular.y = 0.0
cmd_msg.angular.z = 0.0

cmd_pub = rospy.Publisher("/cmd_vel", Twist, queue_size=5)

joy_msg = Joy()

    
def set_joy_cmd(msg):
    global cmd_msg, cmd_pub
    cmd_msg.linear.x = -1*msg.axes[1] 
    cmd_msg.angular.z = -1*msg.axes[3] * np.pi/2.0
    cmd_pub.publish(cmd_msg)



#Modelled with Ackerman Steering Dynamics
#Needs Mutex for cmd_msg and cmd_pub...add
if __name__ == "__main__":
    cmd_sub = rospy.Subscriber("/joy", Joy, set_joy_cmd)
    rospy.spin()
