#!/usr/bin/env python3

import numpy as np
import math 
import scipy.linalg as la
import sys, os
sys.path.append("/home/natsubuntu/Desktop/UnrealAirSimDRL/Util/VirtualIMU")
import SO3Rotation as SO3

#Quat, Pos, Vel (inputs are acceleration and angular rotation)
#Full IMU state
def imu_10dof(x, u, dt):
    state = np.array(x).reshape(-1)
    u = np.array(u).reshape(-1) # ax, ay, az, wx, wy, wz
    I = np.matrix(np.eye(4))
    accel = np.matrix(u[0:3]).reshape((3,1))
    wx = u[3]
    wy = u[4]
    wz = u[5]
    q = np.matrix(state[0:4]).reshape((4,1))
    pos = np.matrix(state[4:7]).reshape((3,1))
    vel = np.matrix(state[7:]).reshape((3,1))
    omega = SO3.get_omega_matrix(wx,wy,wz)
    # Can propogate quaternion two ways: exponential or a first order taylor series hold
    #qt_1 = la.expm(omega*dt)*q #Exponential --> TRUE FORM
    qt_1 = (I + omega*dt/2)*q
    qt_1 = qt_1 / np.linalg.norm(qt_1) #keep quat normalized
    rot = SO3.quaternion_to_rotation_matrix(q)
    pos_t1 = pos + vel*dt + 0.5*rot*dt**2*accel
    vel_t1 = vel + dt*rot*accel
    qt1 = np.array(qt_1).reshape(-1)
    pos_t1 = np.array(pos_t1).reshape(-1)
    vel_t1 = np.array(vel_t1).reshape(-1)
    state_t1 = np.hstack((qt_1,pos_t1,vel_t1))
    state_t1 = np.matrix(state_t1).reshape((10,1))
    return state_t1


def imu_10dof_jac_x(x,u,dt):
    state = np.array(x).reshape(-1)
    u = np.array(u).reshape(-1) # ax, ay, az, wx, wy, wz
    I = np.matrix(np.eye(4))
    accel = np.matrix(u[0:3]).reshape((3,1))
    wx = u[3]
    wy = u[4]
    wz = u[5]
    qw = state[0]
    qx = state[1]
    qy = state[2]
    qz = state[3]
    ax = u[0]
    ay = u[1]
    az = u[2]
    q = np.matrix(state[0:4]).reshape((4,1))
    pos = np.matrix(state[4:7]).reshape((3,1))
    vel = np.matrix(state[7:]).reshape((3,1))
    omega = SO3.get_omega_matrix(wx,wy,wz)
    rot = SO3.quaternion_to_rotation_matrix(q)
    dr11dqw = 2*qw 
    dr11dqx = 2*qx 
    dr11dqy = -2*qy 
    dr11dqz = -2*qz
    dr12dqw = -2*qz 
    dr12dqx = 2*qy 
    dr12dqy = 2*qx 
    dr12dqz = -2*qw 
    dr13dqw = 2*qy
    dr13dqx = 2*qz 
    dr13dqy = 2*qw 
    dr13dqz = 2*qx 
    dr21dqw = 2*qz 
    dr21dqx = 2*qy
    dr21dqy = 2*qx
    dr21dqz = 2*qw 
    dr22dqw = 2*qw 
    dr22dqx = -2*qx 
    dr22dqy = 2*qy 
    dr22dqz = -2*qz 
    
    dr31dqw = -2*qy 
    dr31dqx = 2*qz 
    dr31dqy = -2*qw 
    dr31dqz = 2*qx 
    dr32dqw = 2*qx 
    dr32dqx = 2*qw
    dr32dqy = 2*qz 
    dr32dqz = 2*qy 
    dr33dqw = 2*qw 
    dr33dqx = -2*qx 
    dr33dqy = -2*qy 
    dr33dqz = 2*qz

    dpxdqw = 0.5*dt**2*(dr11dqw*ax + dr12dqw*ay + dr13dqw*az)
    dpxdqx = 0.5*dt**2*(dr11dqx*ax + dr12dqx*ay + dr13dqx*az)
    dpxdqy = 0.5*dt**2*(dr11dqy*ax + dr12dqy*ay + dr13dqy*az)
    dpxdqz = 0.5*dt**2*(dr11dqz*ax + dr12dqz*ay + dr13dqz*az)

    dpydqw = 0.5*dt**2*(dr21dqw*ax + dr22dqw*ay + dr23dqw*az)
    dpydqx = 0.5*dt**2*(dr21dqx*ax + dr22dqx*ay + dr23dqx*az)
    dpydqy = 0.5*dt**2*(dr21dqy*ax + dr22dqy*ay + dr23dqy*az)
    dpydqz = 0.5*dt**2*(dr21dqz*ax + dr22dqz*ay + dr23dqz*az)

    dpzdqw = 0.5*dt**2*(dr31dqw*ax + dr32dqw*ay + dr33dqw*az)
    dpzdqx = 0.5*dt**2*(dr31dqx*ax + dr32dqx*ay + dr33dqx*az)
    dpzdqy = 0.5*dt**2*(dr31dqy*ax + dr32dqy*ay + dr33dqy*az)
    dpzdqz = 0.5*dt**2*(dr31dqz*ax + dr32dqz*ay + dr33dqz*az)

    dvxdqw = dt*(dr11dqw*ax + dr12dqw*ay + dr13dqw*az)
    dvxdqx = dt*(dr11dqx*ax + dr12dqx*ay + dr13dqx*az)
    dvxdqy = dt*(dr11dqy*ax + dr12dqy*ay + dr13dqy*az)
    dvxdqz = dt*(dr11dqz*ax + dr12dqz*ay + dr13dqz*az)

    dvydqw = dt*(dr21dqw*ax + dr22dqw*ay + dr23dqw*az)
    dvydqx = dt*(dr21dqx*ax + dr22dqx*ay + dr23dqx*az)
    dvydqy = dt*(dr21dqy*ax + dr22dqy*ay + dr23dqy*az)
    dvydqz = dt*(dr21dqz*ax + dr22dqz*ay + dr23dqz*az)

    dvzdqw = dt*(dr31dqw*ax + dr32dqw*ay + dr33dqw*az)
    dvzdqx = dt*(dr31dqx*ax + dr32dqx*ay + dr33dqx*az)
    dvzdqy = dt*(dr31dqy*ax + dr32dqy*ay + dr33dqy*az)
    dvzdqz = dt*(dr31dqz*ax + dr32dqz*ay + dr33dqz*az)


    Fq_block = np.array([1,-wx,-wy,-wz,wx,1,wz,-wy,wy,-wz,1,wx,wz,wy,-wx,1]).reshape((4,4))
    Fq_zero_block = np.zeros((4,6))
    Fdpdq_block = np.array([dpxdqw,dpxdqx,dpxdqy,dpxdqz,dpydqw,dpydqx,dpydqy,dpydqz,dpzdqw,dpzdqx,dpzdqy,dpzdqz]).reshape((3,4))
    Fdvdq_block = np.array([dvxdqw,dvxdqx,dvxdqy,dvxdqz,dvydqw,dvydqx,dvydqy,dvydqz,dvzdqw,dvzdqx,dvzdqy,dvzdqz]).reshape((3,4))
    Fp_lin_block = np.array([1,0,0,dt,0,0,0,1,0,0,dt,0,0,0,1,0,0,dt]).reshape((3,6))
    Fv_lin_block = np.array([0,0,0,1,0,0,0,0,0,0,1,0,0,0,0,0,0,1]).reshape((3,6))

    tmp1 = np.hstack((Fq_block,Fq_zero_block))
    tmp2 = np.hstack((Fdpdq_block,Fp_lin_block))
    tmp3 = np.hstack((Fdvdq_block,Fv_lin_block))

    F = np.matrix(np.hstack((tmp1,tmp2,tmp3)))
    return F



def imu_10dof_jac_u(x,u,dt):
    state = np.array(x).reshape(-1)
    u = np.array(u).reshape(-1) # ax, ay, az, wx, wy, wz
    I = np.matrix(np.eye(4))
    accel = np.matrix(u[0:3]).reshape((3,1))
    wx = u[3]
    wy = u[4]
    wz = u[5]
    qw = state[0]
    qx = state[1]
    qy = state[2]
    qz = state[3]
    q = np.matrix(state[0:4]).reshape((4,1))
    pos = np.matrix(state[4:7]).reshape((3,1))
    vel = np.matrix(state[7:]).reshape((3,1))
    omega = SO3.get_omega_matrix(wx,wy,wz)
    rot = SO3.quaternion_to_rotation_matrix(q)
    dqdw = np.array([-qx,-qy,-qz,qw,-qz,qy,qz,qw,-qx,-qy,qx,qw]).reshape((4,3))
    zero_block1 = np.zeros((4,3))
    zero_block2 = np.zeros((3,3))
    tmp1 = np.hstack((dqdw,zero_block1))
    tmp2 = np.hstack((zero_block2,rot * 0.5*dt**2))
    tmp3 = np.hstack((zero_block2,rot*dt))
    G = np.matrix(np.vstack((tmp1,tmp2,tmp3)))
    return G
