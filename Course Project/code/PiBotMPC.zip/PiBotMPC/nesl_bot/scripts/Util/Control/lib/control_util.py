# -*- coding: utf-8 -*-
"""
Created on Tue Dec  5 10:43:13 2017

@author: natsn
"""
import numpy as np
import pandas as pd
import scipy as sci
import scipy.linalg as la
import scipy.signal as sig
import matplotlib.pyplot as plt
import matplotlib.axes as axes
from mpl_toolkits.mplot3d import Axes3D
# Generating all project data in single class so any updates can be done in a single place
from sympy import Matrix, cos,sin, symbols
import control


# returns two lists, x and y values
def unit_circle():
    x = []
    y = []
    w_max = 2*np.pi
    ws = np.arange(0, w_max, .05)
    for w in ws:
        x.append(np.cos(w))
        y.append(np.sin(w))
    return x, y

# Tuple of arrays


def stack_arrays(us):
    assert type(us) == tuple
    uv = np.vstack(us)
    uv = np.matrix(uv)
    uvs = [uv[:, i] for i in range(uv.shape[1])]
    return uvs


def preprocess_pulse_repsonse_data(us, ys):
    #remove any offsets in output data using data prior to pulse application
    num_channels = int(len(ys) / len(us))
    _us = None
    _ys = None
    for i in range(len(us)):
        u = np.array(us[i], dtype=np.float)
        tpulse = np.argmax(u)
        u_max = np.max(u)
        u /= u_max
        for j in range(num_channels):
            y_pp_mean = np.mean(ys[num_channels*i + j][0:tpulse-1])
            # Subtract mean perturbation before pulse happens from y
            ys[num_channels*i + j] = ys[num_channels*i + j] - y_pp_mean
            # Rescale IO data so pulse has magnitude 1
            ys[num_channels*i + j] / np.max(us[i])
    return us, ys


def get_input_output_data(fn='ProjectData.csv'):
    data = pd.read_csv('ProjectData.csv', delimiter=',')  # comma seperated
    u1 = data['u1'].values
    u2 = data['u2'].values
    y11 = data['y11'].values
    y21 = data['y21'].values
    y12 = data['y12'].values
    y22 = data['y22'].values
    return [u1, u2], [y11, y21, y12, y22]

def plot_MIMO(us, ys, dt):
    num_figs = len(us)
    num_ops = len(ys)
    num_channels = int(num_ops / num_figs)
    #Plot Input Response
    plt.figure(1)
    for j in range(num_figs):
        time = np.arange(0, dt*len(us[j]), dt)
        plt.subplot(num_channels, 1, j+1)
        plt.scatter(time, us[j])
        plt.title("Input Signal u"+str(j+1))
        plt.xlabel("time")
        plt.ylabel("u"+str(j))

    # Plot Output Responses
    for i in range(num_figs):
        plt.figure(i+2)
        for j in range(num_channels):
            time = np.arange(0, dt*len(ys[num_channels*i + j]), dt)
            plt.subplot(num_channels, i+1, j+1)
            plt.scatter(time, ys[num_channels*i + j])
            plt.title("Response y"+str(i+1)+str(j+1))
            plt.xlabel("u"+str(i+1))
            plt.ylabel("y"+str(i)+str(j))
    # 3D View Of input output and time
    # Add Legend
    for i in range(num_figs):
        fig = plt.figure(i + 2 + num_figs)
        ax = Axes3D(fig)
        for j in range(num_channels):
            time = np.arange(0, dt*len(ys[num_channels*i + j]), dt)
            ax.scatter3D(time, us[i], ys[num_channels*i + j])
            ax.set_title("Time, " + "Response y to Input Signal u"+str(i+1))
            ax.set_xlabel("u"+str(i+1))
            ax.set_ylabel("y")
    plt.show()


# place impulse responses in ascending order, per channel
def form_hankel_matrix(ys, indices=None, m=2, q=2):
    #Assert all input observations are same length
    assert len(ys) == m*q
    assert type(ys) == list
    for i in range(len(ys)-1):
        if len(ys[i]) != len(ys[i+1]):
            print("All of your observations must be same length!")
            break
    if indices is None:
        indices = []
        indices.append(0)
        indices.append(len(ys[0]))

    datachunk = [i for i in range(indices[0], indices[1])]
    hchunk = np.array(np.zeros((len(datachunk)*m, q)))  # initially
    for col in range(0, len(datachunk)):
        htemp = np.array(np.zeros((m, q)))
        for t in datachunk:
            hkls = []
            for y in ys:
                hkls.append(y[t+col])
            if q > 1:
                hk = np.array(hkls).reshape((m, q)).T
            else:
                hk = np.array(hkls).reshape((m, q))
            # initialize chunk
            if t == datachunk[0]:
                htemp = hk
            # else concatenate to chunk
            else:
                htemp = np.concatenate((htemp, hk), axis=0)
        if col == 0:
            hchunk = htemp
        else:
            hchunk = np.concatenate((hchunk, htemp), axis=1)

    return np.matrix(hchunk)  # return the hankel matrix


# H[0,0] of the hankel matrix is when the pulse occurs, so remember to have first indice has pulse stop + 1
def system_identification(ys, indices, m, q, state_factorizations=[2, 4, 6, 8]):
    # 1: Take the pulse repsonse data and form hankel
    # 2: Create SVD of Hankel
    #**User selects all the possible factorizations they want
    #**For each 'ns' state factorization..
    # 3: Choose a factorization for observability and controlability matrices
    # 4: Make another hankel (hankel of k+1) -> H_tilde
    # 6: B and C are found by the first ns
    # 6: A left and right inverse of H_tilde with the found obs and controllable matrices recovers A
    hankel = form_hankel_matrix(ys, indices=indices, m=2, q=2)
    hankel_tilde = form_hankel_matrix(
        ys, indices=[indices[0]+1, indices[1]+1], m=m, q=q)
    U, S, Vh = np.linalg.svd(hankel)
    U = np.matrix(U)
    #S = np.matrix(S)
    Vh = np.matrix(Vh)
    state_models = {}
    state_models["Hankel"] = hankel
    state_models["Hankel_tilde"] = hankel_tilde
    for sf in state_factorizations:
        # SVD Hankel System Identification
        state_models["ns"+str(sf)] = {}
        state_models["ns"+str(sf)]["Sing_Vals"] = S[0:sf]
        state_models["ns"+str(sf)]["ObsvMat_ns"] = U[:, 0:sf] * \
            np.matrix(np.sqrt(np.diag(S[0:sf])))
        state_models["ns"+str(sf)]["CtrbMat_ns"] = np.matrix(
            np.sqrt(np.diag(S[0:sf])))*Vh[0:sf, :]
        state_models["ns"+str(sf)]["B_ns"] = state_models["ns" +
                                                          str(sf)]["CtrbMat_ns"][:, 0:q]
        state_models["ns"+str(sf)]["C_ns"] = state_models["ns" +
                                                          str(sf)]["ObsvMat_ns"][0:m, :]
        state_models["ns"+str(sf)]["A_ns"] = state_models["ns"+str(sf)]["ObsvMat_ns"].getI(
        )*hankel_tilde*state_models["ns"+str(sf)]["CtrbMat_ns"].getI()

        # Grammians of the pulse response
        state_models["ns"+str(sf)]["ObsvGram_ns"] = state_models["ns" +
                                                                 str(sf)]["ObsvMat_ns"].T*state_models["ns"+str(sf)]["ObsvMat_ns"]
        state_models["ns"+str(sf)]["CtrbGram_ns"] = state_models["ns" +
                                                                 str(sf)]["CtrbMat_ns"].T*state_models["ns"+str(sf)]["CtrbMat_ns"]

    svs = S[0:state_factorizations[-1]]
    plt.scatter([i for i in range(len(svs))], svs)
    plt.show()
    return state_models


def auto_correlation(u, k_interval):
    Rxx = []
    temp = 0
    q = 0
    len_u = len(u)
    stop = 0
    start = 0
    set_temp = True
    for k in k_interval:
        q = 0
        set_temp = True
        if k < q:
            start = np.abs(k)
            stop = len(u)
        elif k > q:
            start = 0
            stop = len(u) - k
        else:
            start = 0
            stop = len(u)
        for q in range(start, stop):
            if set_temp:
                temp = u[k+q]*u[q].transpose()
                set_temp = False
            else:
                temp += u[k+q]*u[q].transpose()
        temp /= len_u
        Rxx.append(temp)
    return Rxx

# input u is a temporal list of matrices
# input y is a temporal list of observed states
def cross_correlation(u, y, k_interval):
    Rxx = []
    temp = 0
    q = 0
    len_u = len(u)
    stop = 0
    start = 0
    set_temp = True
    for k in k_interval:
        q = 0
        set_temp = True
        if k < q:
            start = np.abs(k)
            stop = len(u)
        elif k > q:
            start = 0
            stop = len(u) - k
        else:
            start = 0
            stop = len(u)
        for q in range(start, stop):
            if set_temp:
                temp = y[k+q]*u[q].transpose()
                set_temp = False
            else:
                temp += y[k+q]*u[q].transpose()
        temp /= len_u
        Rxx.append(temp)
    return Rxx


def discrete_pid_response(sysd, x0, xr, times, kp, ki=None, kd=None):
    zero_vector = np.matrix(np.zeros(len(x0))).T
    A = sysd[0]
    B = sysd[1]
    C = sysd[2]
    if ki is None:
        ki = 0
    if kd is None:
        kd = 0
    xc = x0  # current
    xl = x0  # last
    edl = zero_vector
    dt = times[1] - times[0]
    ei = 0
    xs = []
    ys = []
    us = []
    #xs.append(x0)
    for t in times:
        ep = kp*C*(xr - xc)
        ed = kd*C*((xr-xc) - edl) / dt
        ei += ki*C*(xr-xc) * dt

        u = ep+ed+ei
        xk_1 = A*xc + B*u
        yk = C*xk_1
        xc = xk_1
        edl = xr - xc
        xs.append(xc)
        ys.append(yk)
        us.append(u)
    for i in range(ys[0].shape[0]):
        plt.plot(times, [np.asscalar(y[i, 0]) for y in ys])
        plt.show()
    return (xs, ys, us)


# Input is of form: B.T*e^(A(t1 - t)*Gc.I*x1)
def continous_time_least_norm_input(A,B,xr,t1,dt):
    times = np.arange(0,t1,dt)
    Gc = gram_ctrb(A,B)
    uln_t = [B.T*la.expm(A.T*(t1 - t)) * Gc.I * xr for t in times]
    return uln_t
    

def continous_time_frequency_repsonse(A, B, C, plot=True):
    w_range = np.arange(0, 150, .1)  # radians / second
    e_jwt = [1j*w for w in w_range]
    num_responses = C.shape[0]
    num_inputs = B.shape[1]
    # Create Complex Frequency Response
    freq_resp_raw = [C*np.matrix(e*np.matrix(np.eye(A.shape[0])) - A).getI()*B for e in e_jwt]

    # Attain magnitude and angle
    freq_resp_mag = [np.abs(fr) for fr in freq_resp_raw]
    freq_resp_angle = [np.angle(fr, deg=True) for fr in freq_resp_raw]
    print(freq_resp_mag[0:10])
    if plot:
        plt.figure()
        k = 1
        for i in range(num_responses):
            for j in range(num_inputs):
                plt.subplot(2*num_responses, num_inputs, k)
                plt.loglog(w_range, [np.asscalar(frm[j, i])
                                     for frm in freq_resp_mag], k)
                plt.title("Mag Freq Response y" + str(j+1) + str(i+1))
                plt.xlabel("wnyq_rad")
                plt.ylabel("Mag y" + str(j+1) + str(i+1))
                k += 1
                plt.subplot(2*num_responses, num_inputs, k)
                plt.semilogx(w_range, [fra[j, i]
                                       for fra in freq_resp_angle], k)
                plt.title("Phase Freq Response y" + str(j+1) + str(i+1))
                plt.xlabel("wnyq_rad")
                plt.ylabel("Phase y" + str(j) + str(i))
                k += 1
        plt.show()
    return (w_range, freq_resp_raw, freq_resp_mag, freq_resp_angle)

# returns the full x and y state information for each and every state k0 -> # rounds
# we should know the sampling time interval and how it connects with how many rounds we play
# input a forcing term u that contains the matrix forcing history for the system at each timestep

def discrete_time_frequency_repsonse(A, B, C, wnyq_hz, dt, plot=True):
    w_max = wnyq_hz * 2*np.pi
    w_range = np.arange(0, w_max, .1)  # radians / second
    e_jwt = [np.exp(1j*w*dt) for w in w_range]
    num_responses = C.shape[0]
    num_inputs = B.shape[1]
    # Create Complex Frequency Response
    freq_resp_raw = [
        C*np.matrix(e*np.matrix(np.eye(A.shape[0])) - A).getI()*B for e in e_jwt]

    # Attain magnitude and angle
    freq_resp_mag = [np.abs(fr) for fr in freq_resp_raw]
    freq_resp_angle = [np.angle(fr, deg=True) for fr in freq_resp_raw]
    print(freq_resp_mag[0:10])
    if plot:
        plt.figure()
        k = 1
        for i in range(num_responses):
            for j in range(num_inputs):
                plt.subplot(2*num_responses, num_inputs, k)
                plt.loglog(w_range, [np.asscalar(frm[j, i])
                                     for frm in freq_resp_mag], k)
                plt.title("Mag Freq Response y" + str(j+1) + str(i+1))
                plt.xlabel("wnyq_rad")
                plt.ylabel("Mag y" + str(j+1) + str(i+1))
                k += 1
                plt.subplot(2*num_responses, num_inputs, k)
                plt.semilogx(w_range, [fra[j, i]
                                       for fra in freq_resp_angle], k)
                plt.title("Phase Freq Response y" + str(j+1) + str(i+1))
                plt.xlabel("wnyq_rad")
                plt.ylabel("Phase y" + str(j) + str(i))
                k += 1
        plt.show()
    return (w_range, freq_resp_raw, freq_resp_mag, freq_resp_angle)


def discrete_time_frequency_response_fourier(us, ys, dt, plot=True):
    k = 1
    om_yffts = []
    for i in range(len(us)):
        for j in range(int(len(ys)/len(us))):
            yfft = sci.fftpack.fft(
                ys[int(len(ys)/len(us))*i + j]) / sci.fftpack.fft(us[i])
            om = [i/(dt*len(yfft)) for i in range(len(yfft))]
            om_yffts.append((om, yfft))
            if plot:
                plt.subplot(2*int(len(ys)/len(us)), len(us), k)
                plt.loglog(om, np.abs(yfft))
                plt.title("Emperical Freq Resp Mag y" + str(j+1) + str(i+1))
                plt.xlabel("Omega rad/sec")
                plt.ylabel("Response y" + str(j+1) + str(i+1))
                k += 1
                plt.subplot(2*int(len(ys)/len(us)), len(us), k)
                plt.semilogx(om, np.angle(yfft, deg=True))
                plt.title("Emperical Freq Resp Mag y" + str(j+1) + str(i+1))
                plt.xlabel("Omega rad/sec")
                plt.ylabel("Response y" + str(j+1) + str(i+1))
                k += 1
    if plot:
        plt.show()
    return om_yffts


def pole_zeros(A, B, C, D=None, plot=True):
    assert A.shape[1] == C.shape[1]
    if D is None:
        D = np.zeros((C.shape[0], B.shape[1]))
    # attempt to solve the generalized eigenvalue problem
    temp1 = np.matrix(np.concatenate((A, B), axis=1))
    temp2 = np.matrix(np.concatenate((-1*C, -1*D), axis=1))
    S = np.matrix(np.concatenate((temp1, temp2), axis=0))
    eVals, _ = np.linalg.eig(A)

    temp1 = np.diag(np.ones((A.shape[0])))
    temp2 = np.zeros((B.shape[0], B.shape[1]))
    temp3 = np.zeros((C.shape[0], A.shape[1]+B.shape[1]))
    temp1 = np.concatenate((temp1, temp2), axis=1)
    RHS = np.matrix(np.concatenate((temp1, temp3), axis=0))

    #1) finding the eigenvalues and transmission zeros
    trans_zeros, _ = la.eig(S, RHS)  # gen eigenvalues
    trans_zeros = np.sort(trans_zeros)[0:5]

    if plot:
        plt.figure()
        xc, yc = unit_circle()
        plt.plot(xc, yc)
        plt.scatter([np.real(e) for e in eVals], [np.imag(e)
                                                  for e in eVals], c='r')
        plt.scatter([np.real(e) for e in trans_zeros], [np.imag(e)
                                                        for e in trans_zeros], c='g')
        plt.show()

    return (eVals, trans_zeros)

def gram_obsv(A, C):
    return la.solve_continuous_lyapunov(A.T, C.T*C)

def gram_ctrb(A,B):
    return la.solve_continuous_lyapunov(A, B*B.T)

def matrix_exponential(A,dt,n_terms = 10):
    eA = np.matrix(np.zeros(A.shape))
    for i in range(n_terms):
        eA += (A**i * dt**i ) / np.math.factorial(i)
    return eA 
