#!/usr/bin/env python 
import numpy as np 
from scipy.signal import StateSpace, lsim
import scipy.linalg as la 
import matplotlib.pyplot as plt
import sys, os
sys.path.append("/home/natsubuntu/catkin_ws/src/nesl_bot/scripts/Util/Control/lib/")
sys.path.append("/home/natsubuntu/catkin_ws/src/nesl_bot/scripts/Util/Control/process_models/")

import control_structures as cs 
import wheel_odometry_models as wom 

f = wom.diff_drive_model_ctime
A = wom.diff_drive_model_ctime_jac_x
G = wom.diff_drive_model_ctime_jac_u
C = np.matrix([1,0,0,0,1,0,0,0,0]).reshape((3,3))
Q = C.T*C
R = np.matrix([1,0,0,1]).reshape((2,2)) 
Qf = Q 
x0 = np.matrix([1,1,.3]).reshape((3,1))
tf = 4
dt = .05
x_goal = np.matrix([5,0,0]).reshape((3,1))
lqr = cs.CTimeNonLinearLQR_FiniteHorizon(f,A,G,C,Q,R,Qf,x0,tf,dt,udim=2)
lqr.run_ilqr(x_goal)

