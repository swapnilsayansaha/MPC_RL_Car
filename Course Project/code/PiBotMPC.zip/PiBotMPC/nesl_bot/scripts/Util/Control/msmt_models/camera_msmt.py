#!/usr/bin/env python
import numpy as np
import sys, os 

# Camera model for the three state system
def camera_msmt_model_xytheta(state, dt = None):
    return state

def camera_msmt_model_xytheta_jac_x(state, dt = None):
    xdim = 3 # state.shape[0]
    H = np.matrix(np.eye(xdim))
    return H