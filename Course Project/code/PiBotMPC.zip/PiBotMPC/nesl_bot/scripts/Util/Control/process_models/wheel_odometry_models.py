#!/usr/bin/env python3

import numpy as np
import math

# Assumes an x,y,theta state space
def diff_drive_model_dtime(x,u,dt=None,t = None, width = .1541):
    u = np.array(u).reshape(-1)
    x = np.array(x).reshape(-1)
    l = u[0] #delta left wheel
    r = u[1] #delta right wheel
    pos_x = x[0]
    pos_y = x[1]
    theta = x[2]
    if l != r: 
        w = width
        alpha = (r - l) / w
        R = l/alpha

        pos_x_t1 = pos_x + (R+w/2)*(np.sin(theta + alpha) - np.sin(theta))
        pos_y_t1 = pos_y + (R+w/2)*(-np.cos(theta+ alpha) + np.cos(theta))
        theta_t1 = theta + alpha

        state_t1 = np.matrix([pos_x_t1,pos_y_t1,theta_t1]).reshape((3,1))
        return state_t1
    else:
        pos_x_t1 = pos_x + l*np.cos(theta)
        pos_y_t1 = pos_y + l*np.sin(theta)
        theta_t1 = theta
        state_t1 = np.matrix([pos_x_t1,pos_y_t1,theta_t1]).reshape((3,1))
        return state_t1

# Jacobian of the Process with respect to the state vector
def diff_drive_model_dtime_jac_x(x,u,dt=None,t = None, width=.1541):
    u = np.array(u).reshape(-1)
    x = np.array(x).reshape(-1)
    theta = x[2]
    l = u[0]
    r = u[1]
    if l != r:
        w = width
        alpha = (r - l) / w
        R = l/alpha
        F = np.matrix([1,0,(R+w/2)*(np.cos(theta+alpha) - np.cos(theta)), 0,1, (R+w/2)*(np.sin(theta+alpha) - np.sin(theta)),0,0,1]).reshape((3,3))
        return F
    else:
        F = np.matrix([1,0,-l*np.sin(theta),0,1,l*np.cos(theta),0,0,1]).reshape((3,3))
        return F

def diff_drive_model_dtime_jac_u(x,u,dt=None,t = None, width=.1541):
    u = np.array(u).reshape(-1)
    x = np.array(x).reshape(-1)
    l = u[0] #delta left wheel
    r = u[1] #delta right wheel
    pos_x = x[0]
    pos_y = x[1]
    theta = x[2]
    if l != r: 
        w = width
        alpha = (r - l) / w
        R = l/alpha
        dg1dl = (w*r) / (r-l)**2 * (np.sin(theta + (r-l)/w) - np.sin(theta)) - (l+r)/(2*(r-l))*np.cos(theta + (r-l)/w)
        dg2dl = (w*r) / (r-l)**2 * (-np.cos(theta + (r-l)/w) + np.cos(theta)) - (l+r)/(2*(r-l))*np.sin(theta + (r-l)/w)
        dg3dl = -1.0/w
        dg1dr = (-w*l) / (r-l)**2 * (np.sin(theta + (r-l)/w) - np.sin(theta)) + (l+r)/(2*(r-l))*np.cos(theta + (r-l)/w)
        dg2dr = (-w*l) / (r-l)**2 * (-np.cos(theta + (r-l)/w) + np.cos(theta)) + (l+r)/(2*(r-l))*np.sin(theta + (r-l)/w)
        dg3dr = 1.0/w
        G = np.matrix([dg1dl, dg1dr,dg2dl,dg2dr,dg3dl,dg3dr]).reshape((3,2))
        return G
    else:
        dg1dl = 0.5*(np.cos(theta) + l/w*np.sin(theta))
        dg2dl = 0.5*(np.sin(theta) - l/w*np.cos(theta))
        dg3dl = 0
        dg1dr = 0.5*(-l/w*np.sin(theta) + np.cos(theta))
        dg2dr = 0.5*(l/w*np.cos(theta) + np.sin(theta))
        dg3dr = 0
        G = np.matrix([dg1dl,dg1dr,dg2dl,dg2dr,dg3dl,dg3dr]).reshape((3,2))
        return G

# returns dx_dt
def diff_drive_model_ctime(x,u,dt = None, t = None, width = .1541, radius = .031, is_u_vel = True):
    x = np.array(x).reshape(-1)
    u = np.array(u).reshape(-1)
    theta = x[2]
    vL = u[0]
    vR = u[1]
    R = radius
    if not is_u_vel:
        if dt is not None:
            u = u / dt
        else:
            print("Provide dt!")
            exit(0)
    dx_dt = R / 2.0 *(vL + vR)*np.cos(theta)
    dy_dt = R / 2.0 * (vL + vR)*np.sin(theta)
    dtheta_dt = R / width *(vR - vL)
    state = np.matrix([dx_dt, dy_dt, dtheta_dt]).reshape((3,1))
    return state

def diff_drive_model_ctime_jac_x(x,u,dt = None, t = None, width = .1541, radius = .031, is_u_vel = True):
    x = np.array(x).reshape(-1)
    u = np.array(u).reshape(-1)
    theta = x[2]
    vL = u[0]
    vR = u[1]
    R = radius
    if not is_u_vel:
        if dt is not None:
            u = u / dt
        else:
            print("Provide dt!")
            exit(0)
    F = np.matrix([0,0,R/2.0*(vR + vL)*-1.0*np.sin(theta),
                   0,0,R/2.0*(vL + vR)*np.cos(theta),
                   0,0,0]).reshape((3,3))
    return F

def diff_drive_model_ctime_jac_u(x,u,dt = None, t = None, width = .1541, radius = .031, is_u_vel = True):
    x = np.array(x).reshape(-1)
    u = np.array(u).reshape(-1)
    theta = x[2]
    vL = u[0]
    vR = u[1]
    R = radius
    if not is_u_vel:
        if dt is not None:
            u = u / dt
        else:
            print("Provide dt!")
            exit(0)
    G = np.matrix([R/2.0*np.cos(theta), R/2.0*np.cos(theta), 
                   R/2.0*np.sin(theta), R/2.0*np.sin(theta), 
                   -1.0*R / width, R/width]).reshape((3,2)) 
    return G

#Ack Steering with inputs dr, dl, theta -> mixed ack steering
def ackerman_steering_model_dtime(x,u,dt=None, t = None, width = .1541, length = .1401):
    x = np.array(x,dtype=np.float).reshape(-1)
    u = np.array(u,dtype=np.float).reshape(-1)
    pos_x = x[0]
    pos_y = x[1]
    theta = x[2]
    dDl = u[0]
    dDr = u[1]
    phi = u[2]
    dDk = (dDl + dDr) / 2.0
    alpha = (dDr - dDl) / width
    dtheta = dDk / length * np.tan(phi) 
    x_t1 = pos_x + dDk*np.cos(theta + dtheta/2.0 + alpha /2.0)
    y_t1 = pos_y + dDk*np.sin(theta + dtheta/2.0 + alpha/2.0)
    theta_t1 = theta + dtheta + alpha 
    state_t1 = np.matrix([x_t1,y_t1,theta_t1]).reshape((3,1))
    return state_t1

def ackerman_steering_model_dtime_jac_x(x,u,dt = None,t = None,  width = .1541, length = .1401):
    x = np.array(x).reshape(-1)
    u = np.array(u).reshape(-1)
    theta = x[2]
    dDl = u[0]
    dDr = u[1]
    phi = u[2]
    dDk = (dDl + dDr) / 2.0
    alpha = (dDr - dDl) / width
    dtheta = dDk / length * np.tan(phi) 
    dxk1dtheta = -1.0*dDk*np.sin(theta + dtheta/2.0 + alpha/2.0)
    dyk1dtheta = dDk*np.cos(theta + dtheta/2.0 + alpha/2.0)
    F = np.matrix([1,0,dxk1dtheta,0,1,dyk1dtheta,0,0,1]).reshape((3,3))
    return F

def ackerman_steering_model_dtime_jac_u(x,u,dt=None,t = None,  width = .1541, length = .1401):
    x = np.array(x).reshape(-1)
    u = np.array(u).reshape(-1)
    theta = x[2]
    dDl = u[0]
    dDr = u[1]
    phi = u[2]
    dDk = (dDl + dDr) / 2.0
    alpha = (dDr - dDl) / width
    expr = theta + dDk*np.tan(phi)/(2.0*length) + alpha/2.0
    expr2 = np.tan(phi)/(4.0*length) - 1.0/(2*width)
    expr3 = np.tan(phi)/(4.0*length) + 1.0/(2*width)
    dxk1ddDl = 0.5*np.cos(expr) - dDl/2.0*np.sin(expr)*expr2 - dDr/2.0*np.sin(expr)*expr2
    dxk1ddDr = 0.5*np.cos(expr) - dDr/2.0*np.sin(expr)*expr3 - dDl/2.0*np.sin(expr)*expr3
    dxk1dphi = -1.0*dDk*np.sin(expr)*(dDk / (2.0*length* np.cos(phi)**2))
    dyk1ddDl = 0.5*np.sin(expr) + dDl/2.0*np.cos(expr)*expr2 + dDr/2.0*np.cos(expr)*expr2
    dyk1ddDr = 0.5*np.sin(expr) + dDr/2.0*np.cos(expr)*expr3 + dDl/2.0*np.cos(expr)*expr3
    dyk1dphi = dDk*np.cos(expr)*(dDk / (2.0*length* np.cos(phi)**2))
    dthetak1ddDl = 0.5*np.tan(phi)/length
    dthetak1ddDr = 0.5*np.tan(phi)/length
    dthetak1dphi = dDk / ((np.cos(phi)**2)*length)
    G = np.matrix([dxk1ddDl, dxk1ddDr, dxk1dphi, dyk1ddDl, dyk1ddDr, dyk1dphi, dthetak1ddDl, dthetak1ddDr, dthetak1dphi]).reshape((3,3))
    return G

#Pure Ack steering, D-Time
def ackerman_steering_model_dtime2(x,u,dt,t = None,  width = .1541, length = .1401):
    x = np.array(x).reshape(-1)
    u = np.array(u).reshape(-1)
    theta = x[2]
    dDk = u[0]
    phi = u[1]
    dthetak = dDk / length * np.tan(phi)
    xk1 = x[0] + dDk*np.cos(theta + dthetak / 2.0)
    yk1 = x[1] + dDk*np.sin(theta + dthetak / 2.0)
    thetak1 = theta + dthetak
    state = np.matrix([xk1.yk1.thetak1]).reshape((3,1))
    return state 

def ackerman_steering_model_dtime2_jac_x(x,u,dt,t = None,  width = .1541, length = .1401):
    x = np.array(x).reshape(-1)
    u = np.array(u).reshape(-1)
    theta = x[2]
    dDk = u[0]
    phi = u[1]
    dthetak = dDk / length * np.tan(phi)
    F = np.matrix([1,0,-1.0*dDk*np.sin(theta + dthetak/2.0),
                   0, 1, dDk*np.cos(theta + dthetak / 2.0), 
                   0, 0, 1]).reshape((3,3))
    return F 

def ackerman_steering_model_dtime2_jac_u(x,u,dt,t = None,  width = .1541, length = .1401):
    x = np.array(x).reshape(-1)
    u = np.array(u).reshape(-1)
    theta = x[2]
    dDk = u[0]
    phi = u[1]
    dthetak = dDk / length * np.tan(phi)
    ddthetadphi = dDk / length * 1.0 / np.cos(phi)**2 
    g11 = np.cos(theta + dthetak / 2.0) + -1.0*dDk*np.sin(theta + dthetak / 2.0) * 1.0/length*np.tan(phi)
    g21 = np.sin(theta + dthetak / 2.0) + dDk*np.cos(theta + dthetak /2.0)* 1.0 / length * np.tan(phi)
    g31 = 1.0 / length *np.tan(phi)
    g12 = -1.0 * dDk * np.sin(theta + dthetak / 2.0) * ddthetadphi
    g22 = dDk*np.cos(theta + dthetak/2.0) *ddthetadphi
    g32 = ddthetadphi 
    G = np.matrix([g11,g12,g21,g22,g31,g32]).reshape((3,2))
    return G


#Pure Ack Steering, CTime, Returns dxdt
def ackerman_steering_model_ctime(x,u,dt=None,t = None, width = .1541,length = .1401, is_u_vel = True):
    x = np.array(x).reshape(-1)
    u = np.array(u).reshape(-1)
    if not is_u_vel:
        if dt is not None:
            u = u / dt
        else:
            print("Provide dt!")
            exit(0)
    theta = x[2]
    v = u[0]
    phi = u[1]
    dx_dt = v*np.cos(theta)
    dy_dt = v*np.sin(theta)
    dthetadt = v/length *np.tan(phi)
    xt1 = x[0] + dt*dx_dt
    yt1 = x[1] + dt*dy_dt
    theta_t1 = theta + dt*dthetadt
    return np.matrix([dx_dt,dy_dt,dthetadt]).reshape((3,1))

def ackerman_steering_model_ctime_jac_x(x,u,dt,t = None, width = .1541,length = .1401, is_u_vel = True):
    x = np.array(x).reshape(-1)
    u = np.array(u).reshape(-1)
    if not is_u_vel:
        if dt is not None:
            u = u/dt
        else:
            print("Provide dt!")
            exit(0)
    theta = x[2]
    v = u[0]
    F = np.matrix([1,0,v*-np.sin(theta), 0,1,v*cos(theta),0,0,0]).reshape((3,3))
    return F

def ackerman_steering_model_ctime_jac_u(x,u,dt, t = None, width = .1541,length = .1401, is_u_vel = True):
    x = np.array(x).reshape(-1)
    u = np.array(u).reshape(-1)
    if not is_u_vel:
        if dt is not None:
            u = u*dt
        else:
            print("Provide dt!")
            exit(0)
    theta = x[2]
    v = u[0]
    phi = u[1]
    g11 = np.cos(theta)
    g12 = 0
    g21 = np.sin(theta)
    g22 = 0
    g31 = 1.0 / length * np.tan(phi)
    g32 = v/length* 1.0/np.cos(phi)**2
    G = np.matrix([g11,g12,g21,g22,g31,g32]).reshape((3,2))
    return G 
