#!/usr/bin/env python
import numpy as np
import math
import sys, os
import rospy 
from nesl_bot.msg import enc as EncoderMsg
from geometry_msgs.msg import Pose, PoseStamped, TransformStamped
from sensor_msgs.msg import Joy
from nav_msgs.msg import Odometry
import tf

sys.path.append("/home/natsubuntu/catkin_ws/src/nesl_bot/scripts/Util/Control/lib")
sys.path.append("/home/natsubuntu/catkin_ws/src/nesl_bot/scripts/Util/Graphics")
sys.path.append("/home/natsubuntu/catkin_ws/src/nesl_bot/scripts/Util/Control/process_models")
sys.path.append("/home/natsubuntu/catkin_ws/src/nesl_bot/scripts/Util/Control/msmt_models")
from wheel_encoder_models import ackerman_steering_model, ackerman_steering_model_jac_x, ackerman_steering_model_jac_u
from camera_msmt import camera_msmt_model_xytheta, camera_msmt_model_xytheta_jac_x
from control_structures import DiscreteExtendedKalmanFilter as DEKF
import SO3Rotation as SO3

joy_val = 0
ack_val = 0
ack_steer_max = 35.0 * np.pi / 180.0 
state = np.matrix([0,0,0]).reshape((3,1))

time_cur = 0
time_last = 0
dt = .025 # Our best guess

def joy_2_angle(joy_val):
    ack_ang = ack_steer_max*joy_val
    return ack_ang

def joy_ack_callback(msg):
    global joy_val, ack_val
    joy_val = msg.axes[3]
    ack_val = joy_2_angle(joy_val)
    #print("Ack Angle: ", ack_val)

def encoder_ack_callback(msg):
    global ack_val, state, time_cur, time_last, dt, odomMsg
    dDl = msg.left_wheel_dist_dt
    dDr = msg.right_wheel_dist_dt
    phi = ack_val
    u = np.matrix([dDl,dDr,phi]).reshape((3,1))
    time_cur = msg.header.stamp
    if time_last == 0:
        time_last = time_cur
    else:
        dt = (time_cur - time_last).to_sec()
    
    # Propogate prior using control
    yaw_t = np.asscalar(state[2])
    state = ackerman_steering_model(state, u, dt) # Prior
    
    # Save time
    time_last = time_cur


def test_ekf_dummy_data():
    u = np.matrix([.05,.05,.03]).reshape((3,1))
    U = [u for _ in range(200)]
    dt = .025
    x0 = np.matrix([0,0,0]).reshape((3,1))
    x0_truth = x0 
    Q = np.matrix(np.eye(3))*.01
    V = np.matrix(np.eye(3))*.001
    P0 = np.matrix(np.eye(3))
    dekf = DEKF(f = ackerman_steering_model, h = camera_msmt_model_xytheta,
    F = ackerman_steering_model_jac_x, G = ackerman_steering_model_jac_u, H = camera_msmt_model_xytheta_jac_x,
    dt = dt, Q = Q, V = V,x0 =x0, P0 = P0, x0_truth= x0_truth)
    dekf.run_sim(U, plot=True)

if __name__ == "__main__":
    test_ekf_dummy_data()
