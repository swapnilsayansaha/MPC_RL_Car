#!/usr/bin/env python 
import numpy as np 
from scipy.signal import StateSpace, lsim
import scipy.linalg as la 
import matplotlib.pyplot as plt
import sys, os 
sys.path.append("/home/natsubuntu/catkin_ws/src/nesl_bot/scripts/Util/Control/lib")
import control_structures as cs 

# Two State Tracker:
def two_state_tracker():
    A = np.matrix([0,1,0,-.25]).reshape((2,2))
    B = np.matrix([0,4]).reshape((2,1))
    C = np.matrix([1,0,0,1]).reshape((2,2))
    I = np.matrix(np.eye(2))
    D = np.matrix([0,0]).reshape((2,1))
    ss = StateSpace(A,B,C,D)
    # e_t = r_t - x_t 
    Ae = np.hstack((np.matrix(np.zeros((2,1))), ss.A))
    Ae = np.vstack((np.matrix(np.eye(1,3,1)), Ae))
    Be = np.vstack((np.matrix([0]),-1.0 *ss.B))
    Ce = np.matrix([1,0,0])
    De = np.matrix([0])
    Qe = Ce.T*Ce
    Re = np.matrix([.5])
    ss_e = StateSpace(Ae,Be,Ce,De)
    Pe = la.solve_continuous_are(ss_e.A, ss_e.B, Qe, Re)
    Pe = np.matrix(Pe)
    Ke = Re.I*ss_e.B.T*Pe
    Kx = -Ke
    Krx = -1.0*Kx[0,0]
    x0 = np.matrix([8,2,0]).reshape((3,1))
    ref = np.matrix([3])
    u_x = 0
    dt = .05
    x = x0
    xs = []
    T = np.arange(0,20,dt)
    for _ in T:
        ux_dot =  Kx*x + Krx*ref
        u_x = u_x + dt*ux_dot
        x_dot = ss_e.A * x + ss_e.B * ux_dot
        x = x + dt * x_dot
        xs.append(x)
    x0 = np.matrix([8,5]).reshape((2,1))
    dlqr = cs.ContinousTimeLinearQuadraticRegulator_FiniteHorizon(A,B,C,np.matrix([1]),5*C,x0, 10,dt)
    refv = np.matrix([4,0]).reshape((2,1))
    dlqr.track_ref(refv)
    print("Final X is: ", x)
    plt.figure(1)
    plt.plot(T, [xs[i][0,0] for i in range(len(T))],'r')
    plt.plot(T, [xs[i][1,0] for i in range(len(T))],'b')
    plt.plot(T, [ref[0,0] for i in range(len(T))],'g')
    plt.show()

def n_state_tracker():
    A = np.matrix([0,0,1,0,0,0,0,1,-1,0,0,0,0,-1,0,0]).reshape((4,4))
    G = np.matrix([0,0,0,0,1,0,0,1]).reshape((4,2))
    C = np.matrix([1,0,0,0,
                   0,0,0,0,
                   0,0,1,0,
                   0,0,0,0]).reshape((4,4))
    D = np.matrix([0,0]).reshape((2,1))
    Q = C.T*C
    Qf = 5*Q
    R = np.matrix(np.eye(2))*.05
    x0 = np.matrix([-4,-1,1,2]).reshape((4,1))
    tf = 4
    dt = .05
    dlqr = cs.ContinousTimeLinearQuadraticRegulator_FiniteHorizon(A,G,C,Q,R,Qf,x0,tf,dt)
    ref = np.matrix([1,0,1.5,0]).reshape((4,1))
    # Can Track M - references depending on Q.
    # Tougher to track pos / vel for more than two directions
    # Position tracking and Velocity tracking work great
    # Mixed Position and Velocity tracking for single variable
    dlqr.track_ref(ref, order = 1, Qf_gain=1) # Treat as 2nd or 1st order system

#two_state_tracker()
n_state_tracker()