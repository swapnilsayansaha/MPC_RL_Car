
#!/usr/bin/env python3

import numpy as np 
import math 
import sys, os

#returns radians
def mag_msmt_rpy(x,dt=None):
    state = np.array(x).reshape(-1)
    qw = state[0]
    qx = state[1]
    qy = state[2]
    qz = state[3]
    roll = np.arctan2(2*(qw*qz + qx*qy), 1-2*(qy**2 + qz**2))
    pitch = np.arcsin(2*(qw*qy - qz*qx))
    yaw = np.arctan2(2*(quat[0]*quat[3] + quat[1]* quat[2]),1 - 2*(quat[2]**2 + quat[3]**2))
    return np.matrix([roll,pitch,yaw]).reshape((3,1))


def accel_msmt_roll_pitch_jac_x(x, dt=None)
    state = np.array(x).reshape(-1)
    qw = state[0]
    qx = state[1]
    qy = state[2]
    qz = state[3]
    alpha = 2*(qw*qy - qz*qx)
    beta = 2*(qw*qz + qx*qy)/ (1-2*(qy**2 + qz**2))
    BH = 2*(qw*qz + qx*qy)
    BL = (1-2*(qy**2 + qz**2))
    asin_form = 1/np.sqrt(1-alpha**2)
    atan_form = 1/(1 + beta**2)
    dpdqw = asin_form*2*qy 
    dpdqx = -1.0*asin_form*2*qz 
    dpdqy = asin_form*2*qw 
    dpdqz = -1.0*asin_form*2*qx
    drdqw = atan_form*(2*qz)/(1-2*(qy**2 + qz**2))
    drdqx = atan_form*(2*qy)/(1-2*(qy**2 + qz**2))
    drdqy = atan_form*(BL*2*qx + BH*4*qy)/BL**2
    drdqz = atan_form*(BL*2*qw + BH*4*qz)/BL**2
    H = np.matrix([dpdqw,dpdqx,dpdqy,dpdqz,drdqw,drdqx,drdqy,drdqz]).reshape((2,4))
  