# -*- coding: utf-8 -*-

import numpy as np
import math
import scipy.signal as sig
import scipy.linalg as la
import matplotlib.pyplot as plt
import os, sys
import time
import control

sys.path.append("/home/natsubuntu/catkin_ws/src/nesl_bot/scripts/Util/Control/lib")


class DTimeKalmanFilter:
    # input a discrete state space
    def __init__(self, A,B,C, dt, Q, V, x0, P0=None, x0_truth = None):
        self.dt = dt
        self.A = A
        self.B = B
        self.C = C
        self.x_bar = x0
        self.x_hat = x0
        self.K = np.matrix(np.eye(self.A.shape[0])) # --unset
        self.M = np.zeros(self.A.shape) # Mt -- unset
        if P0 is None:
            self.P = np.matrix(np.zeros(self.A.shape)) # P0
        else:
            self.P = P0
        if x0_truth is None:
            self.x_truth = x0
        else:
            self.x_truth = x0_truth
        self.Q = np.matrix(Q)
        self.V = np.matrix(V)
        self.I = np.matrix(np.eye(self.A.shape[0]))
        self.msmt = 0
        self.xtruths = []
        self.us = []
        self.xbars = []
        self.xhats = []
        self.msmts = []
        
    def propogate(self, U):
        if type(U) is list:
            self.x_bar = self.x_hat
            self.M = self.P
            for u in U:
                self.x_bar = self.A*self.x_bar + self.B*u
                self.x_truth = self.A*self.x_truth + self.B*u
                self.M = self.A*self.M*self.A.T + self.Q
                self.xbars.append(self.x_bar)
                self.xhats.append(self.x_hat)
                self.xtruths.append(self.x_truth)
                self.us.append(u)
        else:
            self.x_bar = self.A*self.x_hat + self.B*U
            self.x_truth = self.A*self.x_truth + self.B*U
            self.M = self.A*self.M*self.A.T + self.Q
            self.xbars.append(self.x_bar)
            self.xtruths.append(self.x_truth)
            self.us.append(U)
        return self.x_bar

    def update_kalman_gain(self):
        self.K = self.M*self.C.T*(self.C*self.M*self.C.T + self.V).getI()
        return self.K
    def set_measurement(self, measurement = None):
        if measurement is None: # its a sim..so let based on filters properties
            noise = 0
            if self.V.shape[0] == 1:
                noise = np.random.normal(0,np.sqrt(np.asscalar(self.V)))
            else:
                noise = np.matrix(np.random.multivariate_normal(np.array(np.zeros((self.V.shape[0]))), np.sqrt(self.V))).T
            self.msmt = self.C *self.x_truth + noise
            #print(noise, self.x_truth, self.x_hat, self.C, self.msmt)
        else:
            assert measurement.shape[0] == self.C.shape[0]
            self.msmt = measurement
    def update_state(self):
        self.x_hat = self.x_bar + self.K*(self.msmt - self.C*self.x_bar)
        self.xhats.append(self.x_hat)
        return self.x_hat
    
    def update_covariance(self):
        self.P = (self.I - self.K*self.C)*self.M*(self.I - self.K*self.C).T + self.K*self.V*self.K.T 
        #self.P = (self.I - self.K*self.C)*self.M
        return self.P
    
    def update(self, measurement = None):
        self.update_kalman_gain()
        self.set_measurement(measurement)
        self.update_state()
        self.update_covariance()
        return self.x_hat, self.P

    def run_sim(self,control_sequence, plot = True):
        for i in range(len(control_sequence)):
            self.propogate(control_sequence[i])
            self.update()        
        if plot:
            for i in range(self.x_hat.shape[0]):
                plt.figure(i+1)
                print(self.xhats[0])
                plt.plot([self.dt*j for j in range(len(self.xhats))],
                        [np.asscalar(x[i]) for x in self.xhats], color = 'blue')
                plt.plot([self.dt*j for j in range(len(self.xhats))],
                         [np.asscalar(xt[i]) for xt in self.xtruths], color = 'green')

                plt.title("DKF Reponse Y" + str(i) + " vs time")
            plt.show()

class CTimeKalmanFilter:
   # input a discrete state space
    def __init__(self, A, B, C, Q, V, x0, P0=None, x0_truth=None, tf =None):
        self.dt = .05
        self.A = A # F
        self.B = B # G
        self.C = C # H
        self.x_hat = x0
        self.dx_hat= None
        self.dx_truth = None
        self.dP = None
        self.K = np.matrix(np.eye(self.A.shape[0]))  # --unset
        if P0 is None:
            self.P = np.matrix(np.zeros(self.A.shape))  # P0
        else:
            self.P = P0
        if x0_truth is None:
            self.x_truth = x0
        else:
            self.x_truth = x0_truth
        self.Q = np.matrix(Q)
        self.V = V
        self.I = np.matrix(np.eye(self.A.shape[0]))
        self.msmt = 0
        self.xtruths = []
        self.us = []
        self.xhats = []
        self.msmts = []
        self.t = 0
        self.tf = tf

    def get_C(self):
        if callable(self.C):
            return self.C(self.tf, self.t)
        else:
            return self.C
    
    def get_V(self):
        if callable(self.V):
            return self.V(self.tf, self.t)
        else:
            return self.V

    def update_kalman_gain(self):
        self.K = self.P*self.get_C().T*self.get_V().I
        return self.K

    def set_measurement(self, measurement=None):
        if measurement is None:  # its a sim..so let based on filters properties
            noise = 0
            if self.V.shape[0] == 1:
                noise = np.random.normal(0, np.sqrt(np.asscalar(self.get_V())))
            else:
                noise = np.matrix(np.random.multivariate_normal(
                    np.array(np.zeros((self.V.shape[0]))), np.sqrt(self.get_V()))).T
            self.msmt = self.get_C() * self.x_truth + noise
            #print(noise, self.x_truth, self.x_hat, self.C, self.msmt)
        else:
            assert measurement.shape[0] == self.C.shape[0]
            self.msmt = measurement

    def update_state(self,u):
        self.dx_hat = self.A*self.x_hat + self.B*u + self.K*(self.msmt - self.get_C()*self.x_hat)
        self.x_hat =  self.x_hat + self.dx_hat * self.dt
        self.dx_truth = self.A*self.x_truth + self.B*u
        self.x_truth = self.x_truth + self.dx_truth * self.dt
        self.xhats.append(self.x_hat)
        self.xtruths.append(self.x_truth)
        self.t = self.t + self.dt
        return self.x_hat

    def update_covariance(self):
        self.dP = self.A*self.P + self.P*self.A.T - self.P*self.get_C().T*self.get_V().I*self.get_C()*self.P + self.B*self.Q*self.B.T
        self.P = self.P + self.dP * self.dt
        return self.P

    def update(self, u, measurement=None):
        self.update_kalman_gain()
        self.set_measurement(measurement)
        self.update_state(u)
        self.update_covariance()
        return self.x_hat, self.P

    def run_sim(self, control_sequence, plot=True):
        for i in range(len(control_sequence)):
            self.update(control_sequence[i])
        if plot:
            for i in range(self.x_hat.shape[0]):
                plt.figure(i+1)
                print(self.xhats[0])
                plt.plot([self.dt*j for j in range(len(self.xhats))],
                         [np.asscalar(x[i]) for x in self.xhats], color='blue')
                plt.plot([self.dt*j for j in range(len(self.xhats))],
                         [np.asscalar(xt[i]) for xt in self.xtruths], color='green')

                plt.title("CKF Reponse Y" + str(i) + " vs time")
            plt.show()

class DTimeExtendedKalmanFilter:
    def __init__(self,f, h, F, G, H, dt, 
                 Q, V, x0, P0, x0_truth = None, b_f = None, b_h = None):
        np.random.seed(np.random.choice([i for i in range(100)]))
        self.dt = dt
        self.count = 0
        self.f = f
        self.h = h
        self.F = F
        self.G = G
        self.H = H
        self.x_bar = x0
        self.x_hat = x0
        self.K = np.matrix(np.eye(self.x_bar.shape[0]))  # --unset
        self.M = np.matrix(np.eye(self.x_bar.shape[0]))  # Mt -- unset
        self.P = P0
        if x0_truth is None:
            self.x_truth = None
        else:
            self.x_truth = x0_truth
        self.Q = np.matrix(Q) #set Q before priors propogation if is time varying process noise
        self.V = np.matrix(V) #set V before priors propogation if it is time varying msmt noise
        self.I = np.matrix(np.eye(self.x_bar.shape[0]))
        self.msmt = 0
        self.xbars = []
        self.xhats = []
        self.xtruths = []
        self.us = []
        self.msmts = []

    def propogate(self, u, dt = None):
        # Propogate State
        if dt is not None:
            self.dt = dt
        self.x_bar = self.f(self.x_hat,u, self.dt)
        
        if self.x_truth is not None:
            self.x_truth = self.f(self.x_truth, u, self.dt)
        
        # Propogate Covariance Matrices
        F = self.F(self.x_hat,u,self.dt)
        G = self.G(self.x_hat,u,self.dt)
        Q = self.Q(self.x_hat,u,self.dt)
        self.M = F*self.P*F.T + G*Q*G.T
        
        # Save Priors
        self.xbars.append(self.x_bar)
        self.xtruths.append(self.x_truth)
        self.us.append(u)

        # For a-synchronous prop / updates
        self.x_hat = self.x_bar
        self.P = self.M

        return self.x_bar

    def _update_kalman_gain(self):
        H = self.H(self.x_bar, self.dt)
        self.K = self.M*H.T*(H*self.M*H.T + self.V(self.x_bar,self)).getI()
        return self.K

    def _set_measurement(self, measurement=None):
        if measurement is None:  # its a sim..so based on filters and actual model
            noise = 0
            if self.V.shape[0] == 1:
                noise = np.random.normal(0, np.sqrt(np.asscalar(self.V)))
            else:
                noise = np.matrix(np.random.multivariate_normal(
                    np.array(np.zeros((self.V.shape[0]))), self.V)).reshape((self.V.shape[0],1))
            self.msmt = self.h(self.x_truth, self.dt) + noise
        else:
            self.msmt = measurement

    def _update_state(self):
        self.x_hat = self.x_bar + self.K*(self.msmt - self.h(self.x_bar, self.dt))
        self.xhats.append(self.x_hat)
        #return self.x_hat

    def _update_covariance(self):
        H = self.H(self.x_bar,self.dt)
        self.P = (self.I - self.K*H)*self.M*(self.I - self.K*H).T + self.K*self.V*self.K.T
        self.x_bar = self.x_hat # now if update is called before prop again we will have most recent info as the new 'bar'
        #return self.P

    def update(self, measurement=None):
        self._update_kalman_gain()
        self._set_measurement(measurement)
        self._update_state()
        self._update_covariance()
        return self.x_hat, self.P

    def run_sim(self, control_sequence, plot=True):
        for i in range(len(control_sequence)):
            self.propogate(control_sequence[i])
            self.update()
        if plot:
            for i in range(self.x_hat.shape[0]):
                plt.figure(i+1)
                plt.plot([self.dt*j for j in range(len(self.xhats))],
                         [np.asscalar(x[i]) for x in self.xhats], color='green')
                plt.plot([self.dt*j for j in range(len(self.xhats))],
                         [np.asscalar(xt[i]) for xt in self.xtruths], color='red')
                plt.title("State: " + str(i) + " vs Time (sec)")
            plt.show()

class CTimeExtendedKalmanFilter:
    def __init__(self, f, h, F,G,H, Q, V, P0, x0, dt, x0_truth=None):
        np.random.seed(np.random.choice([i for i in range(100)]))
        self.dt = dt
        self.x0 = x0
        self.P = P0
        self.M = None 
        self.f = f 
        self.h = h 
        self.F = F 
        self.G = G 
        self.H = H 
        self.Q = Q 
        self.V = V 
        self.t = 0
        self.I = np.matrix(np.eye(self.F.shape[0]))
        self.msmt = 0
        self.u = 0
        self.x0_truth = x0_truth
        self.x_bar = self.x0
        self.x_hat = self.x0
        self.xtruths = []
        self.xhats = []

    def propogate(self, u, dt = None):
        if dt is not None:
            self.t += dt
        else:
            self.t =+ self.dt
        dt = self.dt
        t = self.t
        self.u = u
        self.x_bar = self.f(self.x_hat,u,dt,t)
        if self.x0_truth is not None:
            self.x_truth = self.f(self.x_hat,u,dt,t)
            self.xtruths.append(self.x_truth)
        # Propogate Covariance Matrices
        F = self.F(self.x_hat, u, dt, t)
        G = self.G(self.x_hat, u, dt, t)
        Q = self.Q(self.x_hat, u, dt, t)
        self.M = F*self.P*F.T * G*Q*G.T
        self.x_hat = self.x_bar
        return self.x_bar

    def _update_kalman_gain(self):
        H = self.H(self.x_bar,self.u,self.dt,self.t)
        V = self.V(self.x_bar,self.u,self.dt, self.t)
        self.K = self.M*H.T*(H*self.M*H.T + V).getI()

    def set_measurement(self, measurement=None):
        if measurement is None:  # its a sim..so based on actual model
            noise = 0
            if self.V.shape[0] == 1:
                noise = np.random.normal(0, np.sqrt(np.asscalar(self.V)))
            else:
                noise = np.matrix(np.random.multivariate_normal(
                    np.array(np.zeros((self.V.shape[0],1))), np.sqrt(self.V))).T
            self.msmt = self.h(self.x_truth, self.dt, self.t) + noise
        else:
            self.msmt = measurement

    def _update_state(self):
        self.x_hat = self.x_bar + self.K*(self.msmt - self.h(self.x_bar, self.dt, self.t))
        self.xhats.append(self.x_hat)
        self.x_bar = self.x_hat

    def _update_covariance(self):
        H = self.H(self.x_hat, self.u, self.dt, self.t)
        V = self.V(self.x_bar, self.u, self.dt, self.t)
        self.P = (self.I - self.K*H)*self.M*(self.I - self.K*H).T + self.K*V*self.K.T

    def update(self, measurement=None):
        self._update_kalman_gain()
        self.set_measurement(measurement)
        self._update_state()
        self._update_covariance()
        return self.x_hat, self.P

    def run_sim(self, control_sequence, plot=True):
        for i in range(len(control_sequence)):
            self.propogate(control_sequence[i])
            self.update()
        if plot:
            for i in range(self.x_hat.shape[0]):
                plt.figure(i+1)
                plt.plot([self.dt*j for j in range(len(self.xhats))],
                         [np.asscalar(x[i,0]) for x in self.xhats], color='blue')
                plt.plot([self.dt*j for j in range(len(self.xhats))],
                         [np.asscalar(xt[i,0]) for xt in self.xtruths], color='green')

                plt.title("Reponse Y" + str(i) + " vs time")
            plt.show()    

# This Class Solves the Deterministic LQ Problem using Discrete Lyapunov Equations 
class DTimeLQR_FiniteHorizon:
    def __init__(self, A,G,Q,C,R,x0,Qf,dt = .05,tf = 10):
        self.dt = dt  # Propogation Interval for the c-time dynamics
        self.A = A  # Dynamics Matrix
        self.G = G  # Control Gain
        self.C = C
        self.Q = Q  # This is the weighting across the time process
        self.R = R  # This is the input energy wieghting
        self.Qf = Qf  # This is the final cost condition on the cost equation
        self.tf = tf # Final Time
        self.x0 = x0 # Initial State

        # If the horizon is finite we need to:
        # Setup Boundary Conditions: Sf = Qf, PIf = 0
        # We know Optimal control law, need to store Propogation of Sf backwards in time
        # At each propogation backwards with the riccatti expression, we store Sn-1 and
        self.St = Qf  # Initially set the boundary condition of our energy term to roll back from the final state weighting
        self.St_prev = 0  # change in St rolled back thru time
        self.St0 = 0  # Final energy expression at initial time after backwards propogation
        self.lambdas = []
        self.times = np.arange(0, self.tf, dt)
        self.Sts = []
        self.xts = []

    # Finite horizon dynamic programming
    def solve_control(self, tf = None):
        if tf is not None:
            self.tf = tf
            self.times = np.arange(0, self.tf, self.dt)
        for _ in self.times:
            self.Sts.append(self.St)
            self.St_prev = self.Q + self.A.T*self.St*self.A - (self.G.T*self.St*self.A).T*(self.R + self.G.T*self.St*self.G).I*(self.G.T*self.St*self.A)
            self.St = self.St_prev
        
        self.S0 = self.St
        St = [i for i in reversed(self.Sts)]
        self.lambdas = [(self.R + self.G.T*St[i+1]*self.G).I*(self.G.T*St[i+1]*self.A) for i in range(len(St)-1)]
        self.cost = self.x0.T*self.S0*self.x0

    def run_sim(self, plot=True):
        self.solve_control()
        plt.figure(1)
        xt = self.x0
        for i in range(len(self.times)-1):
            self.xts.append(xt)
            xt = (self.A - self.G*self.lambdas[i])*xt

        for i in range(self.xts[0].shape[0]):
            plt.plot(self.times[0:-1], [x[i, 0] for x in self.xts])
            plt.title("D-Time LQ Deterministic Reponse X" + str(i))
        plt.ylabel("Response")
        plt.xlabel("Time")
        plt.show()
        print("Cost: ", self.cost)
        return self.cost

# This Class Solves the Deterministic Time Perfect Information LQ Control Problem
class CTimeLQR_FiniteHorizon:
    def __init__(self, A, G, C, Q, R, Qf, x0, tf=5, dt = .05):
        self.dt = dt  # Propogation Interval for the c-time dynamics
        self.A = A  # Dynamics Matrix
        self.G = G  # Control Gain
        self.C = C
        self.Q = Q  # This is the weighting across the time process
        self.R = R  # This is the input enrgy wieghting
        self.Qf = Qf  # This is the final cost condition on the cost equation
        self.tf = tf
        self.x0 = x0

        # If the horizon is finite we need to:
        # 1) Setup Boundary COnditions: Sf = Qf, PIf = 0
        # Use the resulting minimization of the hamilton jacobi bellman dynamic for stochastic programming
        # We know Optimal control law, need to store Propogation of Sf backwards in time
        # At each propogation backwards with the riccatti expression, we store Sn-1 and
        self.St = Qf  # Initially set the boundary condition of our energy term to roll back from the final state weighting
        self.neg_dSt = 0  # change in St rolled back thru time
        self.St0 = 0  # Final energy expression at initial time after backwards propogation
        self.lambdas = []
        self.times = np.arange(0, self.tf, self.dt)
        self.Sts = []
        self.xts = []
        #self.solve_control()
    # Finite_horizon

    def solve_control(self):
        self.St = self.Qf
        for t in self.times:
            self.neg_dSt = self.St*self.A + self.A.T*self.St - self.St*self.G*self.R.I*self.G.T*self.St + self.Q
            self.St = self.St + self.neg_dSt * self.dt
            self.Sts.append(self.St)
        self.S0 = self.St
        self.Sts = [s for s in reversed(self.Sts)]
        self.lambdas = [self.R.I*self.G.T*St for St in self.Sts]
        self.cost = self.x0.T*self.St*self.x0

    # Track an order one or order two system
    def track_ref(self, ref, order = 2, Qf_gain = 5):
        # reference must match state dim,
        # must use order of the ode (1,2,etc) to determine the bulk add block sizes,
        # this is done for the n-states of the ode
        n = self.A.shape[0]        
        ref_dim = ref.shape[0]
        assert n == ref_dim
        nb = int(n / order)
        if order == 2:
            zeros1 = np.hstack((np.zeros((nb,nb)), np.eye(nb), np.zeros((nb,nb))))
            zeros2 = np.zeros((order*nb,nb))
        else: # order 1
            zeros1 = np.hstack((np.zeros((nb,nb)), np.eye(nb)))
            zeros2 = np.zeros((nb,nb))
        zeros1 = np.matrix(zeros1)

        Ae = np.hstack((zeros2,self.A))
        Ae = np.vstack((zeros1,Ae))
        Be = np.vstack((np.matrix(np.zeros((nb,self.G.shape[1]))), -1.0*self.G))
        Ce = np.hstack((self.C , np.matrix(np.zeros((self.C.shape[0],nb))) ))
        De = np.matrix(np.zeros((n,self.G.shape[1])))
        Qe = Ce.T*Ce 
        Re = self.R
        Qf = Qe*Qf_gain
        self.St = Qf
        self.Sts = []
        for t in self.times:
            self.neg_dSt = self.St*Ae + Ae.T*self.St - self.St*Be*Re.I*Be.T*self.St + Qe
            self.St = self.St + self.neg_dSt * self.dt
            self.Sts.append(self.St)
        self.S0 = self.St
        self.Sts = [s for s in reversed(self.Sts)]
        lambdas = [Re.I*Be.T*St for St in self.Sts]
        x = np.vstack((self.x0, np.matrix(np.zeros((nb,1))))) # no deriv of initial state guessed initially
        self.cost = x.T*self.St*x
        xs = []
        for t in range(len(self.times)):
            Ke = lambdas[t]
            Kx = -Ke
            Krx = -1.0*Kx[0:self.G.shape[1],0:n]
            ux_dot =  Kx*x + Krx*ref
            x_dot = Ae * x + Be * ux_dot
            x = x + self.dt * x_dot
            xs.append(x)

        print("Final X is: ", x)
        plt.figure(1)
        ns = str(n)
        for i in range(n):
            plt.subplot(ns + '1' + str(i+1))
            plt.title('State ' + str(i+1))
            plt.plot(self.times, [xs[k][i,0] for k in range(len(self.times))],'r')
            plt.plot(self.times, [ref[i,0] for _ in range(len(self.times))],'g')
        plt.show()

    def plot_control_gains(self):
        time = np.arange(0, self.tf, self.dt)
        time_to_go = [j for j in reversed(time)]
        for i in range(self.lambdas[0].shape[1]):
            plt.plot(time_to_go, [l[0, i] for l in reversed(self.lambdas)])
        plt.title("Gains vs Time-To-Go")
        plt.gca().invert_xaxis()
        plt.show()
    
    # Plot The Energy St
    def plot_ricatti(self):
        plt.close()
        time = np.arange(0, self.tf, self.dt)
        for i in range(self.Sts[0].shape[0]):
            plt.plot(time, [s[i, i] for s in self.Sts])
        plt.title("CLQ Determ Ricatti Energy vs Time")
        #plt.gca().invert_xaxis()
        plt.show()
    
    def run_sim(self, plot=True):
        self.solve_control()
        plt.figure()
        xt = self.x0
        for i in range(len(self.times)):
            self.xts.append(xt)
            dxt = (self.A - self.G*self.lambdas[i])*xt
            xt = xt + dxt*self.dt

        for i in range(self.xts[0].shape[0]):
            plt.plot(self.times, [x[i, 0] for x in self.xts])
            plt.title("C-Time LQ Deterministic Reponse X" + str(i))
            plt.ylabel("Response")
            plt.xlabel("Time")

        plt.show()
        print("Cost: ", self.cost)
        return self.cost

# The Non-Perfect Measurement Case: The Linear Quadratic Gaussians
# Assumes a Finite Horizon -- The cascaded LQR and Kalman FIlter using recursive dynamic programming and Lyapunov/Riccatti Expressions
class DTimeLQG:
    def __init__(self,F,G,Q,Qf,R,H,V,Qproc,P0,x0,x0_truth=None,dt=.05):
        self.dlqr = DTimeLQR_FiniteHorizon(
            F, G, C, Q, R, x0, Qf, dt)
        self.dkf = DTimeKalmanFilter(F,G,H,dt,Qproc,V,x0,P0,x0_truth)
        self.state = x0
        self.states = []
    def track_ref(self,xref_val, duration, plot = False):
        self.dlqr.solve_control(tf= duration)
        self.state[-1] = xref_val
        self.dkf.x_hat = self.state
        for i in range(len(self.dlqr.times)-1):
            self.states.append(self.state)
            self.state = self.dkf.propogate(-self.dlqr.lambdas[i]*self.state)
            self.state, _ = self.dkf.update()
        if plot:
            self.plot_trajectory()
    def plot_trajectory(self):
        times = np.arange(0,len(self.states)*self.dlqr.dt,self.dlqr.dt)
        for i in range(self.states[0].shape[0]):
            plt.plot(times, [x[i, 0] for x in self.states])
        plt.title("LQG Deterministic Reponse X")
        plt.ylabel("Response")
        plt.xlabel("Time")
        plt.show()

# Assumes a Finite Horizon -- The cascaded LQR and Kalman Filter using Hamilton-Jacobi-Bellman Analysis
class CTimeLQG:
    def __init__(self, F, G, Q, Qf, R, H, V, Qproc, P0, x0, x0_truth=None, dt=.05):
        self.dlqr = CTimeLQR_FiniteHorizon(
            F, G, Q, R, x0, Qf, dt)
        self.dkf = CTimeKalmanFilter(
            F, G, H, dt, Qproc, V, x0, P0, x0_truth)
        self.state = x0
        self.states = []

    def track_ref(self, xref_val, duration, plot=False):
        self.dlqr.solve_control(tf=duration)
        self.state[-1] = xref_val
        for i in range(len(self.dlqr.times)):
            self.states.append(self.state)
            self.state = self.dkf.propogate(-self.dlqr.lambdas[i]*self.state)
            self.state = self.dkf.update()
        if plot:
            self.plot_trajectory()

    def plot_trajectory(self):
        times = np.arange(0, len(self.states)*self.dt, self.dt)
        for i in range(self.states[0].shape[0]):
            plt.plot(self.times[0:-1], [x[i, 0] for x in self.states])
        plt.title("LQG Deterministic Reponse X")
        plt.ylabel("Response")
        plt.xlabel("Time")
        plt.show()

class DTimeExtendedLGQ:
    def __init__(self, f_xu, h_x, Q, R, Qf, x_sym, u_sym,
                 Q_noise, V, x0, dt, P0=None, x0_truth=None,linearize_step =1):
        self.dlqr = DiscreteTimeLinearQuadraticRegulator_FiniteHorizon(None,None,Q,R,x0,Qf,dt)
        self.dekf = DiscreteExtendedKalmanFilter(x_sym,u_sym,f_xu,h_x,dt,Q_noise,V,x0,P0,x0_truth)
        self.state = x0
        self.states = []
    
    # Make sure your Q,Qf and Rs make sense
    def track_references(self,xrefs, tf, plot = True):
        self.state = self.dekf.x_hat
        self.state[4] = xrefs[0]
        self.state[6] = xrefs[1]
        self.state[8] = xrefs[2]
        
        ref = np.matrix([xrefs[0],xrefs[1],xrefs[2],0,xrefs[0],0,xrefs[1],0,xrefs[2]]).T
        linref = (ref + self.state) / 2
        self.dlqr.solve_control_non_linear(self.dekf,ref,linref,tf=tf)

        for i in range(len(self.dlqr.times)-1):
            self.states.append(self.state)
            print(self.state, -self.dlqr.lambdas[i]*self.state, self.dekf.x_truth)
            self.state = self.dekf.propogate(-self.dlqr.lambdas[i]*self.state)
            self.state, _ = self.dekf.update()
        if plot:
            for i in range(self.states[0].shape[0]):
                plt.plot(self.dlqr.times[0:-1], [x[i, 0] for x in self.states])
            plt.show()
            plt.title("D-Time Extended LQG Reponse X" + str(i))
            plt.ylabel("Response")
            plt.xlabel("Time")
            plt.show()

class CTimeNonLinearLQR_FiniteHorizon:
    def __init__(self, f, A, G, C, Q, R, Qf, x0, tf, dt, udim= 1):
        self.dt = dt  # Propogation Interval for the c-time dynamics
        self.f = f
        self.A = A  # Dynamics Matrix
        self.G = G  # Control Gain
        self.C = C
        self.Q = Q  # This is the weighting across the time process
        self.R = R  # This is the input enrgy wieghting
        self.Qf = Qf  # This is the final cost condition on the cost equation
        self.tf = tf
        self.x0 = x0
        self.udim = udim

        # If the horizon is finite we need to:
        # 1) Setup Boundary COnditions: Sf = Qf, PIf = 0
        # Use the resulting minimization of the hamilton jacobi bellman dynamic for stochastic programming
        # We know Optimal control law, need to store Propogation of Sf backwards in time
        # At each propogation backwards with the riccatti expression, we store Sn-1 and
        self.St = Qf  # Initially set the boundary condition of our energy term to roll back from the final state weighting
        self.neg_dSt = 0  # change in St rolled back thru time
        self.S0 = 0  # Final energy expression at initial time after backwards propogation
        self.lambdas = []
        self.ts = np.arange(0, self.tf, self.dt)
        self.Sts = []
        self.xts = []
    
    def run_ilqr(self, x_goal):
        # We want to get to goal x_goal as tf 
        ts = np.arange(0,self.tf,self.dt)
        x_dim = x_goal.shape[0]
        xpaths = []
        for i in range(x_dim):
            x0 = self.x0[i,0]
            xg = x_goal[i,0]
            xp = np.linspace(x0,xg,len(ts))
            xpaths.append(xp)
        xpaths = np.matrix(np.vstack(tuple(xpaths))).reshape((x_dim,len(ts)))
        gate = True
        us = [np.random.uniform((-1,1), (self.udim,1)) for _ in ts]
        lambdas = []
        while gate:
            # We start at x0
            # Initialize u_t to be random uniform for dt steps of t_final
            x = self.x0
            x_prev = x_goal*1000
            xs = []
            xs.append(x)
            # 1.    Fill out trajectory x_dot = f(x0,u_t), integrate, store
            for u in us:
                xdot = self.f(x,u)
                x = x + xdot*self.dt
                xs.append(x)
            # 2.    Fill out F, G about the trajectory x_t, u_t. Store F's, G's reverse order
            Fs = [self.A(x,u) for x,u in zip(xs,us)]
            Gs =[self.G(x,u) for x,u in zip(xs,us)]
            Fs_rev = [F for F in reversed(Fs)]
            Gs_rev = [G for G in reversed(Gs)]
            # 3.    Use Dynamic Programming to form the energy ricatti from Stf to St0 backwards in time, store St's in reverse (now forwards)
            St = self.Qf
            Sts = []
            for A,G in zip(Fs_rev,Gs_rev):
                neg_dSt = St*A + A.T*St - St*G*self.R.I*G.T*St + self.Q
                St = St + neg_dSt * self.dt
                Sts.append(St)
            Sts = [s for s in reversed(Sts)]
            # 4.    Form optimal control gains K = R.I*B.T*St going forwards in time
            lambdas = [self.R.I*G.T*St for St,G in zip(Sts, Gs)]        
            # 5.    update u_optimal iteratively: u_opt = u_0 - K*(xt -x_goal)
            x = self.x0
            u_opts = []
            for i in range(len(us)):
                u_opt = np.matrix(us[i]).reshape((self.udim,1)) - lambdas[i] *(x - x_goal)
                u_opts.append(u_opt)
                xdot = self.f(x,u_opt)
                x = x +xdot*self.dt
            if (np.linalg.norm(x-x_goal) < np.linalg.norm(x_prev - x_goal)):
                us = u_opts
                x_prev = x
            else:
                gate = False
        return lambdas

    def run_two_point_boudary_value_problem(self, x0, xf):
        pass

