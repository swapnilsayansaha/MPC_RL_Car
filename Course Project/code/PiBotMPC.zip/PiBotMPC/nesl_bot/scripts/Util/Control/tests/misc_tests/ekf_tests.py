# -*- coding: utf-8 -*-

def Vt(t,tf):
    R1 = 15e-6
    R2 = 1.67e-3
    return np.matrix([R1 + R2/(tf - t)**2])

def Ht(t,tf):
    Vc = 300
    return np.matrix([1/Vc*(tf - t), 0, 0])

def test_lq_stochastic_ctime():
    tau = 2
    t0 = 0
    tf = 10
    b = 1.52e-2
    x0 = np.matrix([2,8,15]).T
    x0_truth = np.matrix([0, 0, 0]).T
    A = np.matrix([[0,1,0],
                    [0,0,-1],
                    [0,0,-1/tau]])
    G = np.matrix([0,1,0]).T
    C = H
    B = np.matrix([0,0,1]).T
    W = 10000
    Q = np.matrix([[0, 0, 0], [0, 0, 0], [0, 0, 0]])
    R = np.matrix([b])
    Qf = np.matrix([[1,0,0],[0,0,0],[0,0,0]])
    Vc = V
    P0 = np.matrix([[0,0,0],[0,20,0],[0,0,10000]])
    lqr = ContinousTimeLinearQuadraticRegulator_FiniteHorizon(A,G,Q,R,x0,Qf,tf)
    lqr_stoch = ContinousTimeLinearQuadraticRegulator_FiniteHorizon(A,G,B,Q,R,W,x0,Qf,P0,tf)
    #ckf = ContinousKalmanFilter(A, G, C, B*W*B.T, Vc, x0, P0, x0_truth, tf = tf)
    
    lqr.run_sim()
    #lqr_stoch.run_sim()
    #ckf.run_sim()

    lqr.plot_control_gains()
    #lqr_stoch.plot_control_gains()

    lqr.plot_ricatti()
    #Test Discrete Time Response
    dt = .01
    ssd = sig.cont2discrete((A,B,np.matrix([1,0,0]), np.matrix([0])) ,dt)
    Ad = ssd[0]
    Gd = ssd[1]
    Cd = V
    Dd = ssd[3]
    Wd = Ad.T*B*W*B.T*Ad
    dlqr = DiscreteTimeDeterministicLinearQuadraticRegulator_FiniteHorizon(Ad, Gd, Q, R, x0, Qf, dt, tf = 10)
    dlqr_stoch = DiscreteTimeStochasticLinearQuadraticRegulator_FiniteHorizon(Ad, Gd, Q, R, Wd, x0, Qf, P0, dt=dt, tf=10)
    
    dlqr.run_sim()
    dlqr_stoch.run_sim()
    #dkf.run_sim()

    dlqr.plot_control_gains()
    dlqr_stoch.plot_control_gains()
    dlqr.plot_ricatti()
    foo = 9

def run_dlqr_plots(dlqrs):
    lgnds = []
    plt.close()
    plt.figure()
    for dlqr in dlqrs:
        lgnd = dlqr.plot_ricatti()
        lgnds.append(lgnd)
        print("My M is: ", dlqr.m)
    plt.legend(tuple(lgnds))
    plt.title("DLQ w/ Param Var Ricatti Energy vs Time")
    plt.ylabel("K(t)")
    plt.xlabel("Time")
    plt.show()
    plt.close()
    plt.figure()
    lgnds = []
    for dlqr in dlqrs:
        lgnd = dlqr.plot_covariance()
        lgnds.append(lgnd)
    plt.legend(tuple(lgnds))
    plt.title("DLQ w/ Param Var Covariance vs Time")
    plt.ylabel("K(t)")
    plt.xlabel("Time")
    plt.show()
    plt.close()
    plt.figure()
    for dlqr in dlqrs:
        lgnd = dlqr.plot_ricatti_with_m()
        lgnds.append(lgnd)
    plt.legend(tuple(lgnds))
    plt.title("DLQ w/ Param Var Ricatti Energy using ""m"" vs Time")
    plt.ylabel("Var")
    plt.xlabel("Time")
    plt.show()
    plt.close()
    plt.figure()
    for dlqr in dlqrs:
        lgnd = dlqr.run_sim()
        lgnds.append(lgnd)
    plt.legend(tuple(lgnds))
    plt.ylabel("Reponse")
    plt.xlabel("Time")
    plt.title("DLQ w/ Param Var Response vs Time")
    plt.show()
    plt.close()

def test_uncertainty_threshold_principal():
    A = np.matrix([1.1], dtype = np.float)
    B = np.matrix([1.0], dtype = np.float)
    Q = np.matrix([1.0], dtype=np.float)
    R = np.matrix([1.0], dtype = np.float)
    Qf = np.matrix([0], dtype=np.float)
    x0 = np.matrix([1.0], dtype = np.float)
    P0 = np.matrix([.25], dtype=np.float)
    
    # Case 1: Saa and Sab are zero
    Saa = np.matrix([0]) 
    Sab = np.matrix([0])
    Sbbs = [0,.81,1.44,2.25,2.89,3.61,4.41,4.84,5.76]
    dlqrs = [DiscreteTimeStochasticLinearQuadraticRegulator_ParamVar_FiniteHorizon(A, B, Q, R, x0,P0, Qf,Saa,np.matrix([Sbbs[i]]),Sab, dt=1, tf=50)
                for i in range(len(Sbbs))]
    #run_dlqr_plots(dlqrs)
    
    # Case 2: Sab is zero
    Sbb = np.matrix([0])
    Sab = np.matrix([0])
    Saas = [0, .25, .49, .64, .81, 1.00]#, 1.21]
    dlqrs = [DiscreteTimeStochasticLinearQuadraticRegulator_ParamVar_FiniteHorizon(A, B, Q, R, x0,P0, Qf, np.matrix([Saas[i]]),Sbb, Sab, dt=1, tf=50)
             for i in range(len(Saas))]
    run_dlqr_plots(dlqrs)

    # Case 3: Sab is zero
    Sbb = np.matrix([.64])
    Sab = np.matrix([0])
    Saas = [0, .16, .25, .36, .49]#,.64, .81]
    dlqrs = [DiscreteTimeStochasticLinearQuadraticRegulator_ParamVar_FiniteHorizon(A, B, Q, R, x0, P0, Qf, np.matrix([Saas[i]]), Sbb, Sab, dt=1, tf=50)
             for i in range(len(Saas))]
    run_dlqr_plots(dlqrs)
    foo = 8

def test_CMU_Mich_Car_Control():
    
    b = .4  # Ns/m
    m = 1  # kg
    gain = .1  # throttle model

    Ac = np.matrix([[0, 1], [0, -b/m]])
    Bc = np.matrix([[0], [gain/m]])
    #Cc = np.matrix([0,1])
    Cc = np.matrix([[1, 0],[0,1]])
    Dc = np.matrix([[0],[0]])
    #Dc = np.matrix([0])
    Umag = 20
    ssc = sig.StateSpace(Ac, Bc, Cc, Dc)
    dt = .1
    ssd = sig.cont2discrete((ssc.A, ssc.B, ssc.C, ssc.D), dt)
    Ad = ssd[0]
    Bd = ssd[1]
    Cd = ssd[2]
    Dd = ssd[3]
    
    """
    # LQR Work
    Q_lqr = np.matrix([[0,0],[0,1]])
    R_lqr = np.matrix([.01])
    K_lqr, P_lqr = dlqr(Ad,Bd,Q_lqr,R_lqr)
    x0 = np.matrix([0, 0]).T
    xr = np.matrix([0, 4]).T
    t_final = 10
    sim_dlqr(Ad, Bd, Cd, Q_lqr, R_lqr, x0, xr, dt, t_final = t_final)
    """

    spectral_density = .1  # White noise
    Qc = np.matrix([spectral_density])
    F = ssd[0]
    Qd = F*np.matrix([[0, 0], [0, .01*spectral_density]])*F.T
    Vc = np.matrix([[.05, 0], [0, .025]])
    V = Vc
    #Vc = np.matrix([.05])
    x0 = np.matrix([2.5, 0]).T
    x0_truth = np.matrix([2.5, .2]).T
    P0 = np.matrix([[0.01,0],[0,.05]])
    
    Us = np.concatenate((Umag*np.ones(40), np.zeros(40), Umag*np.ones(40)))
    Us2 = [Umag*np.sin(5*t) for t in np.arange(0,10,dt)]
    kf = DiscreteKalmanFilter(Ad,Bd,Cd, dt, Qd, V, x0, P0, x0_truth)
    ckf = ContinousKalmanFilter(Ac,Bc,Cc,Qc,Vc,x0,P0,x0_truth)
    
    R = np.matrix([.01])
    Q = Cc.T*Cc
    Qf = 2*Q
    lqr = DiscreteTimeLinearQuadraticRegulator_FiniteHorizon(Ad,Bd,Q,R,x0,Qf,dt,tf = 5)
    #clqr = ContinousTimeLinearQuadraticRegulator_FiniteHorizon(Ac,Bc,Q,R,x0,Qf,tf=5)
    
    #kf.run_sim(Us2, plot = True)
    ckf.run_sim(Us2, plot = True)
    lqr.run_sim()
    clqr.run_sim()
    lqr.plot_control_gains()
    lqr.plot_ricatti()
    foo = 9

def test_CMU_Mich_Car_Control_Reference_Tracking():
    
    b = .4  # Ns/m
    m = 1  # kg
    gain = .1  # throttle model
    Umag = 5
    dt = .05
    
    # Discrete Error System Home Brew
    Ad = np.matrix([[1, dt,0,0], 
                    [0, .985,0,0],
                    [0,-1,0,1],
                    [0,0,0,1]])
    Bd = np.matrix([.5*dt**2, dt,0,0]).T
    Cd = np.matrix([[1,0,0,0],[0,1,0,0]])
    Dd = np.matrix([0, 0]).T
    x0e = np.matrix([0,0,0,8]).T

    # Augmented Error System -- Speyer:
    Aaug = np.matrix([[0, 1, 0, 0, 0],
                      [0, -b/m, 0, 0, 0],
                    [0,0,0, 1,0], 
                    [0,0,0, 0,1],
                    [0,0,0,0,-b/m]])
    Baug = np.matrix([0,gain/m,0, 0, -gain/m]).T
    Caug = np.matrix([[1,0,0,0,0],[0,1,0,0,0]])
    Daug = np.matrix([0, 0]).T
    x0aug = np.matrix([0,0,6, 3, 0]).T
    
    # Kalman Filter
    spectral_density = .15  # White noise
    Qc = np.matrix([spectral_density])
    Qd = Ad*np.matrix([[0, 0,0,0],
                      [0, .01*spectral_density,0,0],
                      [0, 0,0,0],
                      [0, 0,0,0]])*Ad.T
    Vc = np.matrix([[.5, 0], [0, .25]])
    V = Vc
    P0d = np.matrix([[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]])
    P0c = np.matrix([[1,0,0,0,0],[0,1,0,0,0],[0,0,1,0,0],[0,0,0,1,0],[0,0,0,0,1]])
    x0c = np.matrix([.5, 0,5,2.5,0]).T
    x0d = np.matrix([.5, 0, 0, 5]).T
    x0c_truth = np.matrix([.5, .25,5,2.5,.25]).T
    x0d_truth = np.matrix([.5, .25,0,5]).T

    kf = DiscreteKalmanFilter(Ad,Bd,Cd, dt, Qd, V, x0d, P0d, x0d_truth)
    ckf = ContinousKalmanFilter(Aaug,Baug,Caug,Qc,Vc,x0c,P0c,x0c_truth)
    Us = [Umag*np.sin(t) for t in np.arange(0,10,dt)]
    #kf.run_sim(Us, plot = True)
    #ckf.run_sim(Us, plot = True)

    # Linear Quadratic Regulator
    tf = 4
    R = np.matrix([2.5])
    Raug = np.matrix([.1])
    xref_gain = 3
    xref_tf_gain = 200
    vref_gain = 10
    vref_tf_gain = 50
    Q = vref_gain*np.matrix([[0, 0, 0, 0],
                     [0, 0, 0, 0],
                     [0, 0, 1, 0],
                     [0, 0, 0, 0]])
    Qf = vref_tf_gain*Q

    Qaug = 4*np.matrix([[0, 0, 0, 0, 0],
                        [0, 0, 0, 0, 0],
                        [0, 0, 1, 0, 0],
                        [0, 0, 0, 1, 0],
                        [0, 0, 0, 0, 0]])
    Qfaug = .5*Qaug
    
    dlqr = DiscreteTimeLinearQuadraticRegulator_FiniteHorizon(Ad,Bd,Q,R,x0e,Qf,dt,tf = tf)
    clqr = ContinousTimeLinearQuadraticRegulator_FiniteHorizon(Aaug,Baug,Qaug,Raug,x0aug,Qfaug,tf=tf)

    dlqr.run_sim()
    clqr.run_sim()
    foo = 9

def test_CMU_Mich_Car_Control_LQG_Reference_Tracking():
    b = .4  # Ns/m
    m = 1  # kg
    gain = .1  # throttle model
    Umag = 5
    dt = .05
    
    # Discrete Error System -- Home Brew
    Ad = np.matrix([[1, dt,0,0], 
                    [0, .985,0,0],
                    [0,-1,0,1],
                    [0,0,0,1]])
    Bd = np.matrix([.5*dt**2, dt,0,0]).T
    Cd = np.matrix([[1,0,0,0],[0,1,0,0]])
    Dd = np.matrix([0, 0]).T

    # Augmented Error System -- Speyers:
    Aaug = np.matrix([[0, 1, 0, 0, 0],
                      [0, -b/m, 0, 0, 0],
                    [0,0,0, 1,0], 
                    [0,0,0, 0,1],
                    [0,0,0,0,-b/m]])
    Baug = np.matrix([0,gain/m,0, 0, -gain/m]).T
    Caug = np.matrix([[1,0,0,0,0],[0,1,0,0,0]])
    Daug = np.matrix([0, 0]).T
    
    # Kalman Filter
    spectral_density = .15  # White noise
    Qc = np.matrix([spectral_density])
    Qd = Ad*np.matrix([[0, 0,0,0],
                      [0, .01*spectral_density,0,0],
                      [0, 0,0,0],
                      [0, 0,0,0]])*Ad.T
    Vc = np.matrix([[.5, 0], [0, .25]])
    Vd = Vc
    P0d = np.matrix([[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]])
    P0c = np.matrix([[1,0,0,0,0],[0,1,0,0,0],[0,0,1,0,0],[0,0,0,1,0],[0,0,0,0,1]])

    # Initial States
    x0c = np.matrix([.2,0,6, 3, 0]).T
    x0c_truth = np.matrix([.2, -.05, 6, 3, -.05]).T
    
    x0d = np.matrix([0, .1, 0, 8]).T
    x0d_truth = np.matrix([.25, 0, 0, 8]).T

    # Linear Quadratic Regulator
    tf = 4
    R = np.matrix([2.5])
    Raug = np.matrix([.1])
    xref_gain = 3
    xref_tf_gain = 200
    vref_gain = 10
    vref_tf_gain = 50
    Q = vref_gain*np.matrix([[0, 0, 0, 0],
                     [0, 0, 0, 0],
                     [0, 0, 1, 0],
                     [0, 0, 0, 0]])
    Qf = vref_tf_gain*Q

    Qaug = 4*np.matrix([[0, 0, 0, 0, 0],
                        [0, 0, 0, 0, 0],
                        [0, 0, 1, 0, 0],
                        [0, 0, 0, 1, 0],
                        [0, 0, 0, 0, 0]])
    Qfaug = .5*Qaug
    

    kf = DiscreteKalmanFilter(Ad,Bd,Cd, dt, Qd, Vd, x0d, P0d)
    dlqr = DiscreteTimeLinearQuadraticRegulator_FiniteHorizon(Ad,Bd,Q,R,x0d,Qf,dt,tf = tf)

    dlqg = DiscreteTimeLinearQuadraticGaussian(Ad,Bd,Q,Qf,R,Cd,Vd,Qd,P0d,x0d,x0d_truth,dt)
    dlqg.track_ref(xref_val = 4,duration = 3, plot = False)
    dlqg.track_ref(xref_val = 8,duration = 3, plot = False)
    dlqg.track_ref(xref_val = 12,duration = 3, plot = False)
    dlqg.track_ref(xref_val = 8,duration = 3, plot = False)
    dlqg.track_ref(xref_val = 4,duration = 3, plot = False)
    dlqg.track_ref(xref_val = 0,duration = 3, plot = False)
    dlqg.track_ref(xref_val = -4,duration = 3, plot = False)
    dlqg.track_ref(xref_val = -8,duration = 3, plot = False)
    dlqg.track_ref(xref_val = -12,duration = 3, plot = False)
    dlqg.track_ref(xref_val = -8,duration = 3, plot = False)
    dlqg.track_ref(xref_val = -4,duration = 3, plot = False)
    dlqg.track_ref(xref_val = 0,duration = 3, plot = False)
    dlqg.plot_trajectory()
    foo = 9

def test_kalman_filter():
    dt = .05
    # time step
    F = np.matrix([[1, dt, 0, 0],
                        [0, 1, 0, 0],
                        [0, 0, 1, dt],
                        [0, 0, 0, 1]])
    
    G = np.matrix([dt**2/2, dt, dt**2/2, dt]).T

    H = np.matrix([[1/0.3048, 0, 0, 0],
                        [0, 0, 1/0.3048, 0]])
    
    spectral_density = 1  # White noise, for cont time spectral density
    Qc = np.matrix([[0, 0, 0, 0], 
                    [0, spectral_density, 0, 0],
                    [0,0,0,0],
                    [0,0,0,spectral_density]])
    Qd = F*Qc*F.T
    tst = Q_discrete_white_noise(4, dt=dt, var=1.)
    V = np.matrix([[.05, 0], [0, .05]])
    x0 = np.matrix([.25, .1, -.25, -.1]).T
    x0_truth = np.matrix([0, 0,0,0]).T
    P0 = np.matrix(np.eye(F.shape[0]))*5
    kf = DiscreteKalmanFilter(F,G,H,dt,Qd,V,x0,P0,x0_truth)
    Tf = 10
    times = np.arange(0,Tf,dt)
    U = [1.2*np.sin(2*t) for t in times]

    kf.run_sim(U, plot = True)
    foo = 9

def numeric(f,xsym,xvals):
    tmp = f
    for i in range(len(xvals)):
        tmp = tmp.subs([(xsym[i],xvals[i])])
    return tmp

def move2(x, u, dt, isSym = False):
    if not isSym: # Give numeric non linear function
        x = np.array(x).reshape(-1)
        u = np.array(u).reshape(-1)
        hdg = x[2]
        vel = u[0]
        steering_angle = u[1]
        dist = vel * dt
        wheelbase = .2
        if abs(steering_angle) >= 0.0001:  # is robot turning?
            beta = (dist / wheelbase) * np.tan(steering_angle)
            r = wheelbase / np.tan(steering_angle)  # radius
            x_k1 = np.array([[x[0]-r*np.sin(hdg) + r*np.sin(hdg + beta)],
                        [x[1] + r*np.cos(hdg) - r*np.cos(hdg + beta)],
                        [x[2]+ beta]])
            return x_k1
        else:  # moving in straight line
            dx = np.array([[dist*np.cos(hdg)],
                        [dist*np.sin(hdg)],
                        [0]])
            return x + dx
    else: # Give symbolic function representation
        hdg = x[2, 0]
        vel = u[0]
        steering_angle = u[1]
        dist = vel * dt
        wheelbase = .5
        beta = (dist / wheelbase) * sym.tan(steering_angle)
        r = wheelbase / sym.tan(steering_angle)  # radius
        x_k1 = sym.Matrix([[x[0] - r*sym.sin(hdg) + r*sym.sin(hdg + beta)],
                            [x[1] + r*sym.cos(hdg) - r*sym.cos(hdg + beta)],
                            [x[2] + beta]])
        return x_k1

def move3(x, u, dt, isSym=False):
    if not isSym:  # Give numeric non linear function
        x = np.array(x).reshape(-1)
        u = np.array(u).reshape(-1)
        hdg = x[2]
        vel = u[0]
        steering_angle = u[1]
        dist = vel * dt
        wheelbase = .2
        if abs(steering_angle) >= 0.0001:  # is robot turning?
            beta = (dist / wheelbase) * np.tan(steering_angle)
            r = wheelbase / np.tan(steering_angle)  # radius
            x_k1 = np.array([[x[0]-r*np.sin(hdg) + r*np.sin(hdg + beta)],
                             [x[1] + r*np.cos(hdg) - r*np.cos(hdg + beta)],
                             [x[2] + beta],
                             [-x[0] + x[4]],
                             [x[4]],
                             [-x[1] + x[6]],
                             [x[6]],
                             [-x[2] + x[8]],
                             [x[8]]])
            
            return x_k1
        else:  # moving in straight line
            dx = np.array([[x[0] + dist*np.cos(hdg)],
                           [x[1] + dist*np.sin(hdg)],
                           [0],
                           [-x[0] + x[4]],
                           [x[4]],
                           [-x[1] + x[6]],
                           [x[6]],
                           [-x[2] + x[8]],
                           [x[8]]])
            return dx
    else:  # Give symbolic function representation
        hdg = x[2, 0]
        vel = u[0]
        steering_angle = u[1]
        dist = vel * dt
        wheelbase = .2
        beta = (dist / wheelbase) * sym.tan(steering_angle)
        r = wheelbase / sym.tan(steering_angle)  # radius
        x_k1 = sym.Matrix([[x[0] - r*sym.sin(hdg) + r*sym.sin(hdg + beta)],
                           [x[1] + r*sym.cos(hdg) - r*sym.cos(hdg + beta)],
                           [x[2] + beta],
                           [-x[0] + x[4]],
                           [x[4]],
                           [-x[1] + x[6]],
                           [x[6]],
                           [-x[3] + x[8]],
                           [x[8]]])
        return x_k1

# Assumes x y theta first three states
def measure_move2(x,dt, isSym = False):
    landmark_pos = (5,5)
    x = np.array(x).reshape(-1)
    if not isSym:
        px = landmark_pos[0]
        py = landmark_pos[1]
        dist = np.sqrt((px - x[0])**2 + (py - x[1])**2)
        hx = np.matrix([[dist],
                    [np.arctan2(py - x[1], px - x[0]) - x[2]] ])
        return hx
    else:
        px = landmark_pos[0]
        py = landmark_pos[1]
        dist = sym.sqrt((px - x[0])**2 + (py - x[1])**2)
        hx = sym.Matrix([[dist],
                    [sym.atan2(py - x[1], px - x[0]) - x[2]]])
        return hx

def test_filter_py_ekf():
    x,y,theta = sym.symbols('x,y,theta')
    state = sym.Matrix([x,y,theta])
    vel_inp, steer_inp = sym.symbols('u, steer_ang')
    input_u = sym.Matrix([vel_inp,steer_inp])
    xu_sym = state.col_join(input_u)
    dt = .2
    x0 = np.matrix([0, 0, 0]).T
    x0_truth = np.matrix([.1,.1,0]).T
    u0 = np.matrix([0,0]).T
    spectral_density = .00001
    Qc = np.matrix([[spectral_density, 0, 0],
                    [0, spectral_density, 0],
                    [0, 0, 0]])
    #Qd = np.matrix([[spectral_density, 0],
    #                [0, .1e-3*spectral_density]])

    Fsym = move2(state,input_u, dt, isSym=True).jacobian(state)
    Fnum = np.matrix(numeric(Fsym,xu_sym,np.concatenate((x0,u0))), dtype = np.float)
    Qd = Fnum*Qc*Fnum.T
    V = np.matrix([[.001, .000056], [.000056, 1e-3]])
    P0 = np.matrix([[1,0,0],[0,1,0],[0,0,0]])
    ekf = DiscreteExtendedKalmanFilter(x_sym=state,u_sym=input_u,f_xu=move2,h_x=measure_move2,
                                       dt=dt, Q=Qd, V=V, x0=x0, P0=P0, x0_truth=x0_truth, lininearize_step=5)
    Tf = 8
    times = np.arange(0, Tf, dt)
    U1 = [np.array([np.asscalar(.5+ 5*np.sin(.5*t)),np.asscalar(.0034 + .0003*t)],dtype = np.float) for t in times]
    t = time.time()
    ekf.run_sim(U1, plot=True)
    print(time.time() -t)
    foo = 9

def test_CMU_Mich_Car_Control_Extended_LQG_Reference_Tracking():
    # Symbolic Dynamic Variables
    x, y, theta,xerr,xref,yerr,yref,theta_err,theta_ref = sym.symbols('x,y,theta,xerr,xref,yerr,yref,theta_err,theta_ref')
    state = sym.Matrix([x, y, theta,xerr,xref,yerr,yref,theta_err,theta_ref])
    vel_inp, steer_inp = sym.symbols('u, steer_ang')
    input_u = sym.Matrix([vel_inp, steer_inp])
    xu_sym = state.col_join(input_u)
    
    # Kalman Setup -- State and Error dynamics with reference added into state
    dt = .05
    spectral_density = 1e-12
    weights = np.matrix([1,1,0,0,0,0,0,0,0])
    weights2 = np.matrix([1,1,0,0,0,0,0,0,0])
    Qd = np.matrix(np.diag(weights))*spectral_density
    V = np.matrix([[1e-6, 0], [0, 1e-7]])
    P0 = .1*np.matrix(np.eye(9))*weights2.T*weights2
    
    # Setup Tracker -- Weight Error Dynamics
    weights3 = np.array([0,0,0,1,0,1,0,1,0])
    Q = np.matrix(np.diag(weights3))
    Qf = 2*Q
    R = np.matrix([[.01,0],[0,2]])
    
    xr = 1
    yr = 1
    thetar = np.arctan2(yr, xr)
    xrefs = [xr,yr,np.arctan2(yr,xr)] # x, y, theta
    x0 = np.matrix([.1, .1, .1, xrefs[0],
                    xrefs[0], xrefs[1], xrefs[1], xrefs[2], xrefs[2]]).T
    x0_truth = np.matrix([.1 + .01, .1 + .01, .1, xrefs[0],xrefs[0],xrefs[1],xrefs[1],xrefs[2],xrefs[2]]).T
    tf = .5
    delqg = DiscreteTimeExtendedLinearQuadraticGaussian(f_xu=move3,h_x=measure_move2,Q=Q,
                                                        R=R,Qf=Qf,x_sym=state,u_sym=input_u,
                                                        Q_noise=Qd,V = V,x0=x0,dt = dt,
                                                        P0 = P0,x0_truth = x0_truth, linearize_step= 1)
    delqg.track_references(xrefs,tf,plot = True)
    delqg.dlqr.plot_control_gains()
    delqg.dlqr.plot_ricatti()
    foo = 9

    #ekf = DiscreteExtendedKalmanFilter(x_sym=state, u_sym=input_u, f_xu=move3, h_x=measure_move2,
    #                                   dt=dt, Q=Qd, V=V, x0=x0, P0=P0, x0_truth=x0_truth, lininearize_step=1)

    #times = np.arange(0, Tf, dt)
    #U1 = [np.array([np.asscalar(.5 + 5*np.sin(.5*t)),
    #                np.asscalar(.0034 + .0003*t)], dtype=np.float) for t in times]
    #ekf.run_sim(U1, plot=True)

def test_hinf():
    thetas = -1.0*np.arange(0,100,.2)
    term = 1.21
    PI1 = [-1*(.1*(theta + 10.0) + 1.0 - term)/(2.0*(.1*theta + 1.0)*term) + np.sqrt((.1*(theta + 10.0) + 1.0 - term)**2 - 4.0*(term*(theta + 10.0)*.1)) / (2.0*term*(theta + 10.0)) for theta in thetas]
    PI2 = [-1*(.1*(theta + 10.0) + 1.0 - term)/(2.0*(.1*theta + 1.0)*term) - np.sqrt((.1*(theta + 10.0) + 1.0 -term)**2 - 4.0*(term*(theta + 10.0)*.1)) / (2.0*term*(theta + 10.0)) for theta in thetas]
    S1 = [(.1*theta + term) / (2.0*(.1*theta + 1.0)) + np.sqrt((.1*theta + term)**2 + 4.0*(.1*theta + 1.0)) / (2.0*(.1*theta + 1.0)) for theta in thetas]
    S2 = [(.1*theta + term) / (2.0*(.1*theta + 1.0)) - np.sqrt((.1*theta + term)**2 + 4.0*(.1*theta + 1.0)) / (2.0*(.1*theta + 1.0)) for theta in thetas]
    plt.figure(1)
    plt.xlim([-100,0])
    plt.plot(thetas,S1)#,thetas,S2)
    plt.title("S Ricatti Term")
    plt.figure(2)
    plt.xlim([-100, 0])
    plt.plot(thetas,PI2)#,thetas,PI2)
    plt.title("PI Riccatti Term")
    plt.show()
    print(thetas,S1,S2)
    foo = 9

# The difference in amplitude for discrete and regular impulse is 10  
if __name__ == "__main__":
    #test_kalman_ukf()
    test_kalman_filter()
    #test_lq_stochastic_ctime()
    #test_uncertainty_threshold_principal()
    #test_CMU_Mich_Car_Control()
    #test_CMU_Mich_Car_Control_Reference_Tracking()
    #test_CMU_Mich_Car_Control_LQG_Reference_Tracking()
    #test_filter_py_ekf()
    #test_CMU_Mich_Car_Control_Extended_LQG_Reference_Tracking()
    #test_hinf()
    #foo = 9
    
    
    












