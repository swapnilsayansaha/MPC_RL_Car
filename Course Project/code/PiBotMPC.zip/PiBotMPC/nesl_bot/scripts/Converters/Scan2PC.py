#!/usr/bin/env python

import rospy
from sensor_msgs.msg import PointCloud2 as pc2
from sensor_msgs.msg import LaserScan
from laser_geometry import LaserProjection
import sys, os

scan_topic = ""
pc_topic = ""
laser_proj = LaserProjection()

if len(sys.argv) < 3:
        print("Enter Laser Scan Topic and Output Point-Cloud Topic as ARGS!")
        exit(1)
else:
        scan_topic = sys.argv[1]
        pc_topic = sys.argv[2]
        print("Subscribe to ", scan_topic, " and Publish to ", pc_topic)


rospy.init_node("Scan2PC", anonymous=True)
pc_pub = rospy.Publisher(pc_topic, pc2, queue_size = 10)

def scan2pc_callback(msg):
        global pc_pub, laser_proj
        cloud_out = laser_proj.projectLaser(msg)
        pc_pub.publish(cloud_out)


scan_sub = rospy.Subscriber(scan_topic, LaserScan, scan2pc_callback, queue_size= 10)
rospy.spin()
