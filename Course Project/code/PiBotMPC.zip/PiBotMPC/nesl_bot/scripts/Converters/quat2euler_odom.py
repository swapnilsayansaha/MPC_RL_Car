#!/usr/bin/env python

import numpy as np
import sys, os 
sys.path.append("/home/natsubuntu/catkin_ws/src/nesl_bot/scripts/Util/Graphics")
import SO3Rotation as SO3 
import rospy
from tf.transformations import euler_from_quaternion
from nesl_bot.msg import nesl_odom
from nav_msgs.msg import Odometry

if len(sys.argv) < 3:
    print("Enter Odometry Topic To Subscribe To, Enter YPR Topic To Publish To...")
    exit(1)

rospy.init_node("quat2euler_odom", anonymous=True)
nesl_odom_msg = nesl_odom()
def q2ypr(msg):
    q = msg.pose.pose.orientation
    quat = np.array([q.w,q.x,q.y,q.z])
    #quat = np.array([q.x,q.y,q.z,q.w])
    #pyr = SO3.quaternion_to_euler_angles(quat)
    rpy = euler_from_quaternion(quat)
    nesl_odom_msg.x = msg.pose.pose.position.x
    nesl_odom_msg.y = msg.pose.pose.position.y
    nesl_odom_msg.z = msg.pose.pose.position.z
    nesl_odom_msg.roll = rpy[0]
    nesl_odom_msg.pitch = rpy[1]
    nesl_odom_msg.yaw = rpy[2]
    pub_ypr.publish(nesl_odom_msg)


sub_quat = rospy.Subscriber(sys.argv[1], Odometry, q2ypr, queue_size=5)
pub_ypr = rospy.Publisher(sys.argv[2], nesl_odom, queue_size=5)
rospy.spin()


