#!/usr/bin/env python

import numpy as np
import sys, os 
import rospy
from sensor_msgs.msg import Image

if len(sys.argv) < 2:
    print("Enter Image Topic...")
    exit(1)

rospy.init_node("img_size_help", anonymous=True)
def im_size(msg):
    print("Height and width of ", sys.argv[1], "are: ", msg.width, msg.height)


sub_quat = rospy.Subscriber(sys.argv[1], Image, im_size, queue_size=5)
rospy.spin()