#!/usr/bin/env python
import rospy
import tf 
from nav_msgs.msg import Odometry
import numpy as np 

rospy.init_node("ack_base_odom_linker", anonymous=True)
tf_broadcaster = tf.TransformBroadcaster()

def odom2tf(msg):
    global tf_broadcaster
    x = msg.pose.pose.position.x
    y = msg.pose.pose.position.y
    z = msg.pose.pose.position.z
    qw = msg.pose.pose.orientation.w
    qx = msg.pose.pose.orientation.x
    qy = msg.pose.pose.orientation.y
    qz = msg.pose.pose.orientation.z
    tf_broadcaster.sendTransform((x, y, 0), np.array([qx,qy,qz,qw]), rospy.Time.now(),"base_link","odom")

odom_sub = rospy.Subscriber("/odom", Odometry, odom2tf)
rospy.spin()