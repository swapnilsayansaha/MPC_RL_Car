#!/usr/bin/env python

import numpy as np
import math
import sys, os
import rospy 
from nesl_bot.msg import enc as EncoderMsg
from geometry_msgs.msg import Pose, PoseStamped, PoseWithCovarianceStamped
from sensor_msgs.msg import Joy
import tf

sys.path.append("/home/natsubuntu/catkin_ws/src/nesl_bot/scripts/Util/Control/lib")
sys.path.append("/home/natsubuntu/catkin_ws/src/nesl_bot/scripts/Util/Graphics")
sys.path.append("/home/natsubuntu/catkin_ws/src/nesl_bot/scripts/Util/Control/process_models")
sys.path.append("/home/natsubuntu/catkin_ws/src/nesl_bot/scripts/Util/Control/msmt_models")
from control_structures import DiscreteExtendedKalmanFilter as DEKF
from wheel_encoder_models import ackerman_steering_model, ackerman_steering_model_jac_x, ackerman_steering_model_jac_u
from camera_msmt import camera_msmt_model_xytheta, camera_msmt_model_xytheta_jac_x
import SO3Rotation as SO3

joy_val = 0
ack_val = 0
ack_steer_max = 35.0 * np.pi / 180.0 
state = np.matrix([0,0,0]).reshape((3,1))
P0 = np.matrix(np.eye(3))*.005
Q = np.matrix(np.eye(3))*.001
V = np.matrix(np.eye(3))*.005
dekf = DEKF(f = ackerman_steering_model, h = camera_msmt_model_xytheta,
            F = ackerman_steering_model_jac_x, G = ackerman_steering_model_jac_u,
            H = camera_msmt_model_xytheta_jac_x, dt = .025, 
            Q = Q, V = V, x0 = state, P0 = P0)

rospy.init_node("visual_odom_ekf", anonymous=True)
pose_pub = rospy.Publisher("/swole_boat/pose", PoseWithCovarianceStamped, queue_size=10)
poseMsg = PoseWithCovarianceStamped()

time_cur = 0
time_last = 0
dt = .025 # Our best guess

def joy_2_angle(joy_val):
    ack_ang = ack_steer_max*joy_val
    return ack_ang

def joy_ack_callback(msg):
    global joy_val, ack_val
    joy_val = msg.axes[3]
    ack_val = joy_2_angle(joy_val)
    #print("Ack Angle: ", ack_val)

def encoder_ack_callback(msg):
    global ack_val, state, dekf, time_cur, time_last, dt, poseMsg
    dDl = msg.left_wheel_dist_dt
    dDr = msg.right_wheel_dist_dt
    phi = ack_val
    u = np.matrix([dDl,dDr,phi]).reshape((3,1))
    time_cur = msg.header.stamp
    if time_last == 0:
        time_last = time_cur
    else:
        dt = (time_cur - time_last).to_sec()
    # Propogate prior using control
    state = dekf.propogate(u,dt) # Prior
    
    # Publish Pose
    state = np.array(state).reshape(-1)
    priorCov = np.array(dekf.M).reshape(-1)
    poseMsg.header.stamp = rospy.Time().now()
    poseMsg.pose.pose.position.x = state[0]
    poseMsg.pose.pose.position.y = state[1]
    poseMsg.pose.pose.position.z = .03
    quat = SO3.euler_angles_to_quaternion(state[2], 0, 0)
    poseMsg.pose.pose.orientation.w = quat[0]
    poseMsg.pose.pose.orientation.x = quat[1]
    poseMsg.pose.pose.orientation.y = quat[2]
    poseMsg.pose.pose.orientation.z = quat[3]
    for i in range(len(priorCov)):
        poseMsg.pose.covariance[i] = priorCov[i]
    pose_pub.publish(poseMsg)
    
    # Save time
    time_last = time_cur

# Something like
def camera_ack_callback(msg):
    global state, dekf
    x = msg.pose.position.x
    y = msg.pose.position.y 
    q = msg.pose.orientation
    qt = np.array([q.w,q.x,q.y,q.z])
    ypr = SO3.quaternion_to_euler_angles(qt)
    yaw = ypr[0]
    msmt = np.matrix([x,y,yaw]).reshape((3,1))
    state, P  = dekf.update(measurement=msmt)

    # Publish Pose
    state = np.array(state).reshape(-1)
    postCov = np.array(P).reshape(-1)
    poseMsg.header.stamp = rospy.Time().now()
    poseMsg.pose.pose.position.x = state[0]
    poseMsg.pose.pose.position.y = state[1]
    quat = SO3.euler_angles_to_quaternion(state[2], 0, 0)
    poseMsg.pose.pose.orientation.w = quat[0]
    poseMsg.pose.pose.orientation.x = quat[1]
    poseMsg.pose.pose.orientation.y = quat[2]
    poseMsg.pose.pose.orientation.z = quat[3]
    for i in range(len(postCov)):
        poseMsg.pose.covariance[i] = postCov[i]
    pose_pub.publish(poseMsg)
    print("Posterior: ", state)


ack_sub = rospy.Subscriber("/joy", Joy, callback=joy_ack_callback, queue_size=10)
enc_sub = rospy.Subscriber("/encoder_ticks",EncoderMsg,callback=encoder_ack_callback,queue_size=10)
cam_sub = rospy.Subscriber("/orb_pose_rgbd", PoseStamped, callback = camera_ack_callback,queue_size=5)
rospy.spin()
