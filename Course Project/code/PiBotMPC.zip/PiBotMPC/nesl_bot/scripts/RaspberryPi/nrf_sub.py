import RPi.GPIO as GPIO
from lib_nrf24 import NRF24
import time
import spidev
import rospy 
from std_msgs.msg import String
 
GPIO.setmode(GPIO.BCM)
 
pipes = [[0xe7, 0xe7, 0xe7, 0xe7, 0xe7], [0xc2, 0xc2, 0xc2, 0xc2, 0xc2]]
 
radio = NRF24(GPIO, spidev.SpiDev())
radio.begin(0, 17)
radio.setPayloadSize(32)
radio.setChannel(0x60)
 
radio.setDataRate(NRF24.BR_2MBPS)
radio.setPALevel(NRF24.PA_MIN)
radio.setAutoAck(True)
radio.enableDynamicPayloads()
radio.enableAckPayload()
 
radio.openReadingPipe(0, pipes[1])
radio.printDetails()
 
radio.startListening()

rospy.init_node("nrf_sub",anonymous=True)
pub_topics = ["/radio_chan0_in","/radio_chan1_in","/radio_chan2_in","/radio_chan3_in"]
radioPubs = [rospy.Publisher(pt, String, queue_size=50) for pt in pub_topics]

while(1):
    ackPL = [1]
    while not radio.available(0):
        time.sleep(1/1000)
    receivedMessage = []
    radio.read(receivedMessage, radio.getDynamicPayloadSize())
    print("Received: {}".format(receivedMessage))
 
    print("Translating the receivedMessage into unicode characters")
    string = ""
    for n in receivedMessage:
        # Decode into standard unicode set
        if (n >= 32 and n <= 126):
            string += chr(n)
    print(string)
    if string[0:2] == "rc":
        radio_string = String()
        radio_string.data = string[3:]
        radioPubs[int(string[2])].publish(radio_string)
    #radio.writeAckPayload(1, ackPL, len(ackPL))
    #print("Loaded payload reply of {}".format(ackPL))
    time.sleep(.00025)
