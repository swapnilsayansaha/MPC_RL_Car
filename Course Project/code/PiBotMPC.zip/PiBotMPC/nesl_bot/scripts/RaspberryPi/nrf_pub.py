import RPi.GPIO as GPIO
from lib_nrf24 import NRF24
import time
import spidev
import rospy
from std_msgs.msg import String
import sys, os

GPIO.setmode(GPIO.BCM)
 
pipes = [[0xe7, 0xe7, 0xe7, 0xe7, 0xe7], [0xc2, 0xc2, 0xc2, 0xc2, 0xc2]]
 
radio = NRF24(GPIO, spidev.SpiDev())
radio.begin(0, 17)
radio.setPayloadSize(32)
radio.setChannel(0x60)
 
radio.setDataRate(NRF24.BR_2MBPS)
radio.setPALevel(NRF24.PA_MIN)
radio.setAutoAck(True)
radio.enableDynamicPayloads()
radio.enableAckPayload()
 
# radio.openReadingPipe(1, pipes[1])
radio.openWritingPipe(pipes[1])
radio.printDetails()

def radio_callback_chan0(msg):
        print(list("rc0:" + msg.data))
        print("RC0: Sent Radio Data")
        #radio_string = list(msg.data)
        #radio.write(radio_string)
def radio_callback_chan1(msg):
        print(list("rc1:" + msg.data))
        print("RC1: Sent Radio Data")
        #radio_string = list(msg.data)
        #radio.write(radio_string)

def radio_callback_chan2(msg):
        print(list("rc2:" + msg.data))
        print("RC2: Sent Radio Data")
        #radio_string = list(msg.data)
        #radio.write(radio_string)

def radio_callback_chan3(msg):
        print(list("rc3:" + msg.data))
        print("RC3: Sent Radio Data")
        #radio_string = list(msg.data)
        #radio.write(radio_string)

rospy.init_node("nrf_pub",anonymous=True)
sub_topics = ["/radio_chan0_out","/radio_chan1_out","/radio_chan2_out","/radio_chan3_out"]
radioSubs = [rospy.Subscriber(sub_topics[0], String, radio_callback_chan0),rospy.Subscriber(sub_topics[1], String, radio_callback_chan1),rospy.Subscriber(sub_topics[2], String, radio_callback_chan2),rospy.Subscriber(sub_topics[3], String, radio_callback_chan3)]
rospy.spin()
