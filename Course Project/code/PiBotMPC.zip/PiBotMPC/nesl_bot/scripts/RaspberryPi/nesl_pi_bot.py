#!/usr/bin/env python

import rospy
import numpy

from std_msgs.msg import Float32,Int32
from sensor_msgs.msg import Joy, Imu
import sys, os

from nesl_servo_ros import NeslServo
from nesl_motor_ros import NeslMotor

user_bag_data = True
user_publish_data = True
if len(sys.argv) < 3:
        print("Need More CMD LINE ARGS! -- Set Publishing to True or False -- Set Bagging to true or false)")
        exit(1)
else:
        user_bag_data = sys.argv[1].lower() == 'true'
        user_publish_data = sys.argv[2].lower() == 'true'
        user_bag_data=False
        print("Bagging Data:", user_bag_data, ", Live Stream: ", user_publish_data)

class PIBot:
        def __init__(self, MotorLeft = None,
                           MotorRight = None,
                           SteeringServo = None,
                           TugBoat = False,
                           FrontCamera = True,
                           Estimation = False,
                           Control = "joy"):
                self.isTugBoat = TugBoat
                self.FrontCamera = FrontCamera
                if MotorLeft is not None:
                        self.MotorLeft = MotorLeft
                else:
                        self.MotorLeft = NeslMotor(38,40,0,name = "pibot_leftmotor", rate_hz = 50, bag_name = "/home/pi/catkin_ws/src/nesl_bot/Data/PIBOT_LEFTMOTOR.bag", is_bag_data = user_bag_data, is_publish_data = user_publish_data)
                if MotorRight is not None:
                        self.MotorRight = MotorRight
                else:
                        self.MotorRight = NeslMotor(35,36,1,name = "pibot_rightmotor", rate_hz = 50, bag_name = "/home/pi/catkin_ws/src/nesl_bot/Data/PIBOT_RIGHTMOTOR.bag", is_bag_data = user_bag_data, is_publish_data = user_publish_data)
                if SteeringServo is not None:
                        self.SteeringServo = SteeringServo
                else:
                        self.SteeringServo = NeslServo(2, name = "pibot_steering_axle", bag_name = "/home/pi/catkin_ws/src/nesl_bot/Data/PIBOT_SERVO.bag", is_bag_data = user_bag_data, is_publish_data = user_publish_data)
                if TugBoat:
                        self.TugBoat = NeslServo(5, name = "tugboat_base")
                if FrontCamera:
                        #self.SpyCamBase = NeslServo(6, name = "spycam_base", bag_name = "/home/pi/catkin_ws/src/nesl_bot/Data/PIBOT_BASELEV.bag", is_bag_data = user_bag_data, is_publish_data = user_publish_data)
                        self.SpyCamLever = NeslServo(6, name = "spycam_lever", bag_name = "/home/pi/catkin_ws/src/nesl_bot/Data/PIBOT_LEV.bag", is_bag_data = user_bag_data, is_publish_data = user_publish_data)
       	        if Estimation:
                        self.imu = rospy.Subscriber("/imu",IMU,self.imu_motion_callback)
                if Control == "joy" or Control == "/joy":
                        self.xbox_sub = rospy.Subscriber("/joy",Joy, self._joy_callback)
                # Initialize all devices
                self.drive_wheels_center = 0.0
                self.drive_wheels_min = -60.0
                self.drive_wheels_max = 60.0

                self.steering_axis_center = 200.0
                self.steering_axis_min = 130.0
                self.steering_axis_max = 270.0

                self.tugboat_center = 200.0
                self.tugboat_min = 140.0
                self.tugboat_max = 260.0

                self.spycam_base_center = 220.0
                self.spycam_base_min = 60.0
                self.spycam_base_max = 380.0
                self.spycam_base_angle = self.spycam_base_center

                self.spycam_lever_center = 220.0
                self.spycam_lever_min = 40.0
                self.spycam_lever_max = 400.0
                self.spycam_lever_angle = self.spycam_lever_center
        def map_val(self, mapval, val_min,val_max,ref_min,ref_max, val_center = None, ref_center = None):
                if val_center is None:
                        norm_val = (mapval - val_min) / (val_max - val_min)
                        new_val = norm_val*(ref_max - ref_min) + ref_min
                        return new_val
                else: # If center, then use val min and val max as radii from center for respective directions about the center
                        if ref_center is None:
                                ref_center = (ref_min + ref_max) / 2.0
                        if mapval >= val_center:
                                norm_val = (mapval - val_center) / (val_max - val_center)
                                new_val = norm_val*(ref_max -ref_center) + ref_center
                                return new_val
                        else:
                                norm_val = (mapval - val_min) / (val_center - val_min)
                                new_val = norm_val*(ref_center - ref_min) + ref_min
                                return new_val
        def _steering_axle_callback(self, msg_cmd):
                steering_angle = int(msg_cmd)
                print("Steering PiBot to: ", msg_cmd)
                self.SteeringServo.set_angle(steering_angle)
	def _speed_callback(self, speed_cmd):
                print("Setting PiBot Speed to: ",speed_cmd, "%")
                speed = int(speed_cmd)
                self.MotorLeft.set_speed(speed)
                self.MotorRight.set_speed(speed)
        def _spy_cam_base_callback(self, base_cmd):
                print("Spy Cam Base Angle ",base_cmd)
                base_angle = int(base_cmd)
                self.SpyCamBase.set_angle(base_angle)
        def _spy_cam_lever_callback(self,lever_cmd):
                print("Spy Cam Lever Angle", lever_cmd)
                lever_angle = int(lever_cmd)
                self.SpyCamLever.set_angle(lever_angle)
        def _tugboats_callback(self, tug_cmd):
                print("Turning Tugboat to: ", tug_cmd)
                #self.TugBoat.set_angle(tug_cmd)
        def _joy_callback(self, xbox_msg):
                steering_angle = float(xbox_msg.axes[3])
                speed_ref = float(xbox_msg.axes[1])
                #tugboats_angle_left = float(xbox_msg.axes[2])
                #tugboats_angle_right = float(xbox_msg.axes[5])
                pibot_mode = float(xbox_msg.buttons[0])
                #spycam_base_angle_left = float(xbox_msg.axes[2])
                #spycam_base_angle_right = float(xbox_msg.axes[5])
                gain_lev = 5
                gain_base = 10
                self.spycam_lever_angle += gain_lev*int(xbox_msg.axes[6]) if self.spycam_lever_angle <= self.spycam_lever_max - gain_lev and self.spycam_lever_angle >= self.spycam_lever_min + gain_lev else 0
                #self.spycam_base_angle += gain_base*int(xbox_msg.axes[6]) if self.spycam_base_angle <= self.spycam_base_max - gain_base and self.spycam_base_angle >= self.spycam_base_min + gain_base else 0

                #exit_drive = xbox_msg.buttons[1]
                #if(exit_drive):
                #        print("EXITING PIBOT DRIVE! GOODBYE!")
                #        exit(0)
                #print("PIBot Xbox Actuator Values")
                steering_angle_cmd = self.map_val(-1*steering_angle,-1.0,1.0,self.steering_axis_min,self.steering_axis_max)
                speed_cmd = self.map_val(-1.0*speed_ref,-1.0,1.0,self.drive_wheels_min,self.drive_wheels_max)
                #tugboats_angle_left_cmd = self.tugboat_center - self.tugboat_min +  self.map_val(-1.0*tugboats_angle_left,-1,1,self.tugboat_min, self.tugboat_center)
                #tugboats_angle_right_cmd = self.tugboat_center - (self.map_val(-1.0*tugboats_angle_right,-1,1,self.tugboat_center, self.tugboat_max) - self.tugboat_center)
                #spycam_base_cmd_left = self.map_val((-1*spycam_base_angle_left+1)/2.0,0,1,self.spycam_base_min, self.spycam_base_center) - self.spycam_base_min
                #spycam_base_cmd_right = self.map_val((-1*spycam_base_angle_right+1)/2.0,0,1,self.spycam_base_center, self.spycam_base_max) - self.spycam_base_center
                self._steering_axle_callback(steering_angle_cmd)
                self._speed_callback(speed_cmd)
                if self.FrontCamera:
                        #self._spy_cam_base_callback(self.spycam_base_angle)
                        self._spy_cam_lever_callback(self.spycam_lever_angle) 
        def _imu_motion_callback(self,imu_msg):
                print("Imu Heard: ", imu_msg)
                # Enter Particle Filter / EKF Service

def nesl_xbox_drive():
        rospy.init_node("nesl_pi_bot",anonymous = True)
        pibot = PIBot()
        rospy.spin()





if __name__ ==  "__main__":
        nesl_xbox_drive()


