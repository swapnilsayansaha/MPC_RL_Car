#!/usr/bin/env python
import sys, os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from SensorLibrary.Servo_EXI import Servo_EXI
import time
import rospy
import rosbag
from std_msgs.msg import Int32

#rospy.init_node("nesl_servo_ros",anonymous=True)
class NeslServo:
        def __init__(self, channel, name = "nesl_servo", bag_name = "/home/pi/catkin_ws/src/nesl_bot/Data/PIBOT_SERVO.bag", is_bag_data = False, is_publish_data = True):
                self.name = name
                self.channel = channel
                self.servo = Servo_EXI(self.channel)
                self.topic_angle = self.name + "_angle"
                self.topic_pwm = self.name + "_pwm"
                self.pub = rospy.Publisher(self.topic_angle, Int32, queue_size = 5)
                self.pub2 = rospy.Publisher(self.topic_pwm, Int32, queue_size = 5)
                self.bag_name = bag_name
                self.write_gate = True
                self.is_bag_data = is_bag_data
                self.is_publish_data = is_publish_data
                self.datas = []
        def _write_bag(self, msg_angle, msg_pwm, isChunk = False):
                if self.write_gate:
                        with rosbag.bag.Bag(self.bag_name,"w") as baggy:
                                if(isChunk):
                                        for data in self.datas:
                                                print("Bagging Servo Data")
                                                baggy.write(self.topic_angle,data[0])
                                                baggy.write(self.topic_pwm,data[1])
                                else:
                                        baggy.write(self.topic_angle,msg_angle)
                                        baggy.write(self.topic_pwm, msg_pwm)
                else:
                        with rosbag.bag.Bag(self.bag_name,"a") as baggy:
                                if(isChunk):
                                        for data in self.datas:
                                                print("Bagging Servo Data")
                                                baggy.write(self.topic_angle,data[0])
                                                baggy.write(self.topic_angle,data[1])
                                else:
                                        baggy.write(self.topic_angle, msg_angle)
                                        baggy.write(self.topic_name, msg_pwm)
                print("Bagging Servo Done!")
        def set_angle(self, angle):
                self.servo.set_angle(angle)
                msg = angle
                if self.is_publish_data:
                        self.pub.publish(Int32(msg))
                        self.pub2.publish(Int32(self.servo.pwm_value))
                if False:
                        self.datas.append((Int32(msg),Int32(self.servo.pwm_value),rospy.get_time()))
                #self._write_bag(Int32(msg), Int32(self.servo.pwm_value))
        def subscribe_to_reference(self, topic):
                self.sub = self.Subscriber(topic, Int32, queue_size = 5)
                self.topic = topic
	def __del__(self):
	       pass
               #for data in self.datas:
               #print("Writing To Servo Bag!")
               #self._write_bag(self.datas[0][0],self.datas[0][1], isChunk = True)
               #print("Write Servo Data!")
               #self.servo.stop()


