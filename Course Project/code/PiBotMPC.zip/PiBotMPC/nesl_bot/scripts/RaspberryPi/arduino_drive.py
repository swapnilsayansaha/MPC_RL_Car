#!/usr/bin/env python3

import rospy
import numpy 
from std_msgs.msg import Int16
from std_msgs.msg import UInt16
from sensor_msgs.msg import Joy

rospy.init_node("arduino_drive")
drive_pub = rospy.Publisher("/drive_motor", Int16, queue_size=10)
steer_pub = rospy.Publisher("/steer_servo", UInt16, queue_size=10)

def map_val(val, low_in, high_in, low_out, high_out):
    norm_val = (val - low_in) / (high_in - low_in)
    new_val = norm_val*(high_out - low_out) + low_out
    return new_val

# These variables should be set to the same values as in the uploaded arduino sketch
def get_steering_value(joy_val):
    center_steer = 80.0
    range_steer = 30.0
    max_steer = center_steer + range_steer
    min_steer = center_steer - range_steer
    steer_val = map_val(-1.0*joy_val, -1.0, 1.0, min_steer, max_steer)
    return int(steer_val)

def get_drive_value(joy_val):
    min_drive = -255.0 
    max_drive = 255.0 
    drive_val = map_val(joy_val, -1.0, 1.0, min_drive, max_drive)
    return int(drive_val)

def joy_2_steer_and_drive(msg):
    global drive_pub, steer_pub
    # Get Joystick Data
    steer_joy = msg.axes[3]
    drive_joy = msg.axes[1]
    
    # Convert joy to drive/steer commands
    steer_val = get_steering_value(steer_joy)
    drive_val = get_drive_value(drive_joy)
    
    print("Steer is: ", steer_val, "Drive is: ", drive_val)
    
    # Publish out to arduino
    steer_pub.publish(steer_val)
    drive_pub.publish(drive_val)


joy_sub = rospy.Subscriber("/joy", Joy, joy_2_steer_and_drive,queue_size=5)
rospy.spin()


