#!/usr/bin/env python
import subprocess
print("Bagging Data!")
subprocess.call(["rosbag","record","-a"])

