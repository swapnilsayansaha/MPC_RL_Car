#!/usr/bin/env python
import RPi.GPIO as GPIO
import rospy
from nesl_bot.msg import enc as encoder_msg
import spidev
import numpy as np
# Setup SPI
bus = 0
device = 1 # Chip Enable 1
spi = spidev.SpiDev()
spi.open(bus,device)
spi.max_speed_hz = 4000000
spi.mode = 0

# Setup ROS
rospy.init_node('wheel_encoders', anonymous = True)
encoderPub = rospy.Publisher('/encoder_ticks', encoder_msg, queue_size = 10)
rate = rospy.Rate(40) #hz

# Reinit Spi by flushing first few enteries
def flush_spi(spi):
        for i in range(600):
                print("Flush! ", spi.readbytes(4))
                rospy.sleep(.01) #200hz
flush_spi(spi)
right_ticks_tot = 0
left_ticks_tot = 0
encoderMsg = encoder_msg() #encoder message
def pub_wheel_encoders():
        global encoderMsg, left_ticks_tot, right_ticks_tot, spi, rate, encoderPub
        while(not rospy.is_shutdown()):
                r1 = spi.readbytes(4)
                #print("Bytes: ", r1)
                msb_right = r1[3]
                lsb_right = r1[2]
                msb_left = r1[1]
                lsb_left = r1[0]
                right_ticks = np.int16((msb_right << 8) | lsb_right)
                left_ticks = np.int16((msb_left << 8) | lsb_left)
                right_ticks_tot += right_ticks
                left_ticks_tot += left_ticks
                current_time = rospy.Time().now()
                encoderMsg.header.stamp = current_time
                encoderMsg.left_wheel_ticks_dt = left_ticks
                encoderMsg.left_wheel_ticks = left_ticks_tot
                encoderMsg.right_wheel_ticks_dt = right_ticks
                encoderMsg.right_wheel_ticks = right_ticks_tot
                encoderPub.publish(encoderMsg)
                print("Left Encoder: ", left_ticks_tot, ", Right Encoder: ", right_ticks_tot)
	        #print("MSBR: ", msb_right, ", LSBR: ", lsb_right, ", MSRL: ", msb_left, ", LSBL: ", lsb_left)
                rate.sleep()

pub_wheel_encoders()
