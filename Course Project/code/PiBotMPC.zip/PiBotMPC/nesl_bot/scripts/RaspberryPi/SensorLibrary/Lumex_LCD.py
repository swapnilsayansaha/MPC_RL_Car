import sys, os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
import time

import RPi.GPIO as GPIO

CLEAR_SCREEN = 0x01
TWO_LINE_DISPLAY = 0x38
TURN_ON_DISPLAY_CURSOR = 0x0E
PLACE_CURSOR = 0x80

class Lumex_LCD:
    def __init__(self, rs, en, d0, d1, d2, d3, d4, d5, d6, d7):
        """Takes in register select, data bus pins. Using 8-bit mode."""
        self._rs = rs
        self._en = en
        self._databus = [d0, d1, d2, d3, d4, d5, d6, d7]
        
        GPIO.setwarnings(False)
        GPIO.setmode(GPIO.BOARD)
        GPIO.setup(self._rs, GPIO.OUT)
        GPIO.setup(self._en, GPIO.OUT)
        for i in range(0, len(self._databus)):
            GPIO.setup(self._databus[i], GPIO.OUT)
            
        self.send_a_command(CLEAR_SCREEN)
        self.send_a_command(TWO_LINE_DISPLAY)
        self.send_a_command(TURN_ON_DISPLAY_CURSOR)
            
    def send_a_command(self, command):
        """Send a command to the databus."""
        self.write_to_bus(command)
        GPIO.output(self._rs, 0)        # Set to low to send instruction
        GPIO.output(self._en, 1)        # Set to high to receive instruction
        time.sleep(0.5)
        GPIO.output(self._en, 0)        # Set to low to indicate sent instruction
        #self.write_to_bus(0x00)         # Reset databus
        
    def send_a_character(self, char):
        """Send a character in hex form."""
        self.write_to_bus(char)
        GPIO.output(self._rs, 1)        # Set to low to send data
        GPIO.output(self._en, 1)        # Set to high to receive data
        time.sleep(0.5)
        GPIO.output(self._en, 0)        # Set to low to indicate sent data
        self.write_to_bus(0x00)         # Reset databus
        
    def write_to_bus(self, value):
        """Writes 8-bit value to databus."""
        for i in range(0, len(self._databus)):
            GPIO.output(self._databus[i], (value >> i) & 0x01)
            
    def clear_screen(self):
        self.send_a_command(CLEAR_SCREEN)
        
    def send_string_to_position(self, data, row = 1, col = 1):
        """Write a string to certain position on the LCD."""
        if (row == 1):
            row = 0
        elif (row == 2):
            row = 40
        else:
            sys.exit()
            
        starting_position = row + col - 1
        self.send_a_command(PLACE_CURSOR + starting_position)
        for i in range(0, len(data)):
            self.send_a_character(ord(data[i]))
            
#if __name__ == "__main__":
#    a = Lumex_LCD(3, 5, 7, 11, 13, 15, 19, 21, 23, 29)
#    while(1):  
#        a.send_a_command(0x01)                    # sending 'all clear' command
#        a.send_a_command(0x38)                    # 16*2 line LCD
#        a.send_a_command(0x06)