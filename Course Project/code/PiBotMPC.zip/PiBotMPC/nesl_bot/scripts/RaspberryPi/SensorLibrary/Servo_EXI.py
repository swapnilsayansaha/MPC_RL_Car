import sys, os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from SensorLibrary.PCA9685 import PCA9685
# ===========================================================================
# Example Code
# Yoyo edited July. 20th
# ===========================================================================
class Servo_EXI:
    #pwm = PWM(0x40, debug=True)
    def __init__(self, channel, pwm_freq = 50):# the default address is 0x40
        self.channel = channel
        self.servo = PCA9685()
        self.servo.set_pwm_freq(pwm_freq)
        self.MAX_PWM_VAL = 4096
        self.MIN_PWM_VAL = 0
        self.MAX_PWM_Servo = 500 # mechanical restriction of servo EXI
        self.MIN_PWM_Servo = 50
        self.cur_pwm = int(0.5*(self.MAX_PWM_Servo+self.MIN_PWM_Servo))# Necessary for discontinuous rotation, unnecessary for continous rotation
        self.cur_degree = int((self.cur_pwm - 10)/540*180) 
        #self.servo.setPWM(self.channel, 0, self.cur_pwm)
        self.pwm_value = 0
    def set_angle(self, angle):
        pwm_value = int(angle / 360.0 * (self.MAX_PWM_Servo - self.MIN_PWM_Servo) + 50)
        self.servo.set_pwm(self.channel, 0, pwm_value)
        self.pwm_value = pwm_value
    def stop(self):
        self.servo.set_pwm(self.channel, 0, 0)
