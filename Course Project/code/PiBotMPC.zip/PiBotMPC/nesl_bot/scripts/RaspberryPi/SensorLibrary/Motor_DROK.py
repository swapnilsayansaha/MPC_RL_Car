#!/usr/bin/python
import sys, os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from PCA9685 import PCA9685
import RPi.GPIO as GPIO


class Motor_DROK:
    
    # Note if you'd like more debug output you can instead run:
    #pwm = PWM(0x40, debug=True)
    #forwards pin is DIR
    #reverse pin is ENABLE
    def __init__(self, forwardsPin, reversePin, channel, pwm_freq = 50):
        # Set GPIO pins_Direction
        GPIO.setmode(GPIO.BOARD)
        GPIO.setup(forwardsPin, GPIO.OUT)
        GPIO.setup(reversePin, GPIO.OUT)
        # Store all arguments
        self.forwardsPin = forwardsPin
        self.reversePin = reversePin
        self.channel = channel
        self.motor = PCA9685()
        self.motor.set_pwm_freq(pwm_freq)
        self.MAX_PWM_VAL = 4096
        self.MIN_PWM_VAL = 0
	self.speed_pwm = 0
    def forwards(self,percent_max): # percent_max is a value 0~100
        speed_pwm = int(percent_max / 100.0 * self.MAX_PWM_VAL)# Values are 0 to MAX_PWM_VAL
        GPIO.output(self.forwardsPin, True)
        GPIO.output(self.reversePin, True)
        self.motor.set_pwm(self.channel, 0, speed_pwm)
        self.speed_pwm = speed_pwm
    def reverse(self,percent_max): # percent_max is a value 0~100
        speed_pwm = int(percent_max / 100.0 * self.MAX_PWM_VAL) # Values are 0 to MAX_PWM_VAL
        GPIO.output(self.forwardsPin, False)
        GPIO.output(self.reversePin, True)
        self.motor.set_pwm(self.channel, 0, speed_pwm)
        self.speed_pwm = speed_pwm

