#!/usr/bin/env python
import sys, os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
#from SensorLibrary.Motor_HBB import Motor_HBB
from SensorLibrary.Motor_DROK import Motor_DROK as Motor_HBB
#import time
import rospy
import rosbag
from std_msgs.msg import Int32
from sensor_msgs.msg import Joy

#rospy.init_node("nesl_motor_ros",anonymous=True)
#test here!

class NeslMotor:
        def __init__(self, forwardsPin, reversePin, channel, name = "neslmotor", rate_hz = 50,bag_name = "/home/pi/catkin_ws/src/nesl_bot/Data/PIBOT_RIGHT_MOTOR.bag", is_bag_data = False, is_publish_data = True):
	        self.motor = Motor_HBB(forwardsPin,reversePin,channel)
                self.forwardsPin = forwardsPin
                self.reversePin = reversePin
                self.channel = channel
                self.name = name
                self.topic_pwm = self.name + "_pwm"
                self.topic_speed = self.name + "_speed"
                self.pub1 = rospy.Publisher(self.topic_pwm,Int32, queue_size = 5)
                self.pub2 = rospy.Publisher(self.topic_speed, Int32, queue_size = 5)
                self.last_speed = None
                self.last_pwm = None
		#self.rate = rospy.Rate(rate_hz)
                self.bag_name = bag_name
                self.is_bag_data = is_bag_data
                self.is_publish_data = is_publish_data
                self.write_gate = True
                self.datas = []
        def _write_bag(self, msg_speed, msg_pwm, isChunk = False):
                if self.write_gate:
                        self.write_gate = False
                        with rosbag.bag.Bag(self.bag_name,"w") as baggy:
                                if(isChunk):
                                        print("Bagging Motor Data")
                                        for data in self.datas:
                                                baggy.write(self.topic_speed,data[0])
                                                baggy.write(self.topic_pwm,data[1])
                                else:
                                        baggy.write(self.topic_speed,msg_speed)
                                        baggy.write(self.topic_pwm,msg_pwm)
                else:
                        with rosbag.bag.Bag(self.bag_name, "a") as baggy:
                                if(isChunk):
                                        for data in self.datas:
                                                print("Bagging Motor Data")
                                                baggy.write(self.topic_speed,data[0])
                                                baggy.write(self.topic_pwm,data[1])
                                else:
                                        baggy.write(self.topic_speed,msg_speed)
                                        baggy.write(self.topic_pwm,msg_pwm)
        def _default_callback(self, msg):
                print("Motor heard: ", msg)
                speed = int(msg)
                if speed > 0:
                        self.motor.forwards(speed)
                else:
                        self.motor.reverse(abs(speed))
                self.last_speed = speed
                self.last_pwm = self.motor.speed_pwm
                msg_pwm = Int32(self.last_pwm)
                msg_speed = Int32(self.last_speed)
                if self.is_publish_data:
                        self.pub1.publish(msg_pwm)
                        self.pub2.publish(msg_speed)
                if False:
                       self.datas.append((msg_speed,pwm_msg,rospy.get_time()))
                #self._write_bag(Int32(msg_speed), Int32(msg_pwm))
                #self.rate.sleep()
        def subscribe_ref(self, topic, msg_type):
                self.topic = topic
                self.msg_type = msg_type
                self.sub = rospy.Subscriber(topic, msg_type, self._default_callback)
        def set_speed(self,speed):
                if speed > 0:
                        self.motor.forwards(speed)
                else:
                        self.motor.reverse(abs(speed))
                self.last_speed = Int32(speed)
                self.last_pwm = Int32(self.motor.speed_pwm)
                msg_pwm = self.last_pwm
                msg_speed = self.last_speed
                if self.is_publish_data:
                        self.pub1.publish(msg_pwm)
                        self.pub2.publish(msg_speed)
                if False:
                        self.datas.append((self.last_speed, self.last_pwm,rospy.get_time()))
                #self._write_bag(msg_speed, msg_pwm)
                #self.rate.sleep()
                #print(self.last_speed, self.last_pwm, speed, self.motor.speed_pwm)
                #print("Set Nesl Motor Speed!")
        def __del__(self):
                pass
                #for data in self.datas:
                #print("Writing Motor Data")
                #self._write_bag(self.datas[0][0],self.datas[0][1], isChunk=True)
                #print("Wrote Motor Data!")
