# Goal is for the Raspberry Pi to read the GPS Data over the serial COM Port line of the arduino
# Parse String and use ros to publish GPS at 1 HZ
import serial 
import rospy
from nesl_bot.msg import gps
import numpy as np
rospy.init_node("gps_node", anonymous = True)
gpsMsg = gps()
gpsPub = rospy.Publisher("gps", gps, queue_size = 5)
ser = serial.Serial("/dev/ttyACM4", 115200, timeout = 2)
while 1:
        if ser.in_waiting > 0:
                line = ser.readline()
                lines = line.split(';')
                lines = np.array(lines).reshape(-1)
                vals = np.array([l.split(': ') for l in lines]).reshape(-1)
                #print(line)
                #print(lines)
                print(lines.shape)
                print(vals.shape)
                if vals.shape[0] == 14:
                        cur_time = rospy.Time().now()
                        gpsMsg.header.stamp = cur_time
                        gpsMsg.latitude = float(vals[1])*1e-7
                        gpsMsg.longitude = float(vals[3])*1e-7
                        gpsMsg.altitude = float(vals[5])*1e-5
                        gpsMsg.groundspeed = float(vals[7])*.001
                        gpsMsg.heading = float(vals[9])
                        gpsMsg.PDOP = float(vals[11])
                        gpsMsg.SIV = int(vals[13].split('/')[0])
                        gpsPub.publish(gpsMsg)
                        print('GPS Data on ROS!')
