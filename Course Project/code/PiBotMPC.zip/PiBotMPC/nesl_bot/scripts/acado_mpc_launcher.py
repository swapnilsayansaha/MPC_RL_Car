#!/usr/bin/env python3

import sys, os
import subprocess
import time

dir_path = os.path.dirname(os.path.realpath(__file__))
cmd = dir_path + '/../src/ACADOtoolkit/examples/my_examples/ros_ackermann_trajectory_planner' #ackermann_nat
print(cmd)
sp = subprocess.run([cmd])
print("Running Ackermann Trajectory Planner")
while True:
    time.sleep(1)