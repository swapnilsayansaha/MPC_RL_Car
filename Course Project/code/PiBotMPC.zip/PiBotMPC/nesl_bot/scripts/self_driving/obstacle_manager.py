#!/usr/bin/env python
import numpy as np
import rospy
import pickle
import sys, os 
from gazebo_msgs.srv import SpawnModel, SpawnModelRequest, DeleteModel, DeleteModelRequest, GetWorldProperties, GetModelState, SetModelState
from geometry_msgs.msg import Pose
from visualization_msgs.msg import Marker, MarkerArray
import tf
import copy

# use TF to find most recent pose of the robot on the fly
def get_current_pose(listener, dt):
    #global dt
    tic = rospy.get_time()
    gate = True
    time_list = 0.0
    while gate:
        try:
            t,q = listener.lookupTransform('/odom', '/base_link', rospy.Time(0))
            time_list = rospy.get_time() - tic
            gate = False
            #print(t,r)
        except:
            rospy.sleep(.001) #1ms sleep
    rpy = tf.transformations.euler_from_quaternion(q)
    if time_list > dt:
        print("Transform Listener Took over DT!")
    #print("Pose is: ", t[0], t[1], rpy[2])
    #print("Time to get Pose: ", time_list)
    return np.array([ t[0], t[1], rpy[2] ]), time_list
 

rospy.init_node("obstacle_manager")
rospy.sleep(4)
self_drive_path = rospy.get_param("/self_drive_path_file")
#directory where centroids of markers are stored as pickle file
coord_list = "/home/natsubuntu/catkin_ws/src/nesl_bot/Data/warehouse_trajectories/self_drive_obstacles/obstacle_placements/" + self_drive_path + "_obj_centers"
#read the obstacle urdf file (P.S. I wanted to spawn cylinders but don't know the URDF properties for cylinders)
obstacle_file = open("/home/natsubuntu/catkin_ws/src/nesl_bot/urdf/obstacle.urdf")
obstacle_urdf = obstacle_file.read()
listener = tf.TransformListener()
marker_pub = rospy.Publisher("/tugboat/obstacle/markers", MarkerArray, queue_size=10)

#load list of centroids of obstacles from pickle file
z = pickle.load(open(coord_list))
z = np.array(z, dtype=np.float32)
print("Object Matrix Shape ", z.shape)
marker = Marker()
obj_markers = MarkerArray()
marker_count = 0
for zi in z:
    # Load a Marker into RVIZ at this point
    marker = Marker()
    marker.header.frame_id = '/map'
    marker.header.stamp = rospy.Time.now()
    marker.type = marker.CUBE
    marker.id = marker_count + 1
    marker.action = marker.ADD
    marker.scale.x = 0.2 
    marker.scale.y = 0.2 
    marker.scale.z = 0.5
    marker.color.a = 1.0 
    marker.color.r = 1.0 
    marker.color.g = 0.0 
    marker.color.b = 0.0 
    marker.pose.orientation.w = 1.0 
    marker.pose.position.x = np.asscalar(zi[0])
    marker.pose.position.y = np.asscalar(zi[1])
    marker.pose.position.z = 0.25
    obj_markers.markers.append(marker)
    marker_count += 1
for i in range(6):
    marker_pub.publish(obj_markers)
    rospy.sleep(.1)

HZ = 4
DT = 1.0 / HZ
while 1:
    try:
        cur_state, tk = get_current_pose(listener, DT)
        tic = rospy.get_time()
        #calculate current distance (L2 norm) of robot from obstacle centroid
        #robo_coordinates = rospy.ServiceProxy('/gazebo/get_model_state', GetModelState)
        dist = np.linalg.norm(z - cur_state[0:2],axis=1)

        #spawn those 4 obstacles which are nearest to robot location (check if they exist or not first)
        world_properties = rospy.ServiceProxy('/gazebo/get_world_properties', GetWorldProperties)().model_names
        #marker = Marker()
        #obj_markers = MarkerArray()
        #marker_count = 0
        for i in dist.argsort()[:4]:
            if 'obstacle'+str(i) not in world_properties:
                model_spawner = rospy.ServiceProxy('/gazebo/spawn_urdf_model', SpawnModel)
                req = SpawnModelRequest()
                req.model_name = "obstacle"+str(i)
                req.model_xml = obstacle_urdf
                object_pose = Pose()
                object_pose.position.x = float(z[i,0])
                object_pose.position.y = float(z[i,1])
                object_pose.position.z = float(0)
                object_pose.orientation.x = float(0)
                object_pose.orientation.y = float(0)
                object_pose.orientation.z = float(0)
                object_pose.orientation.w = float(1)
                req.initial_pose = object_pose
                model_spawner(req)
                # Load a Marker into RVIZ at this point
                """ marker = Marker()
                marker.header.frame_id = '/map'
                marker.header.stamp = rospy.Time.now()
                marker.type = marker.CUBE
                marker.id = marker_count + 1
                marker.action = marker.ADD
                marker.scale.x = 0.2 
                marker.scale.y = 0.2 
                marker.scale.z = 0.5
                marker.color.a = 1.0 
                marker.color.r = 1.0 
                marker.color.g = 0.0 
                marker.color.b = 0.0 
                marker.pose.orientation.w = 1.0 
                marker.pose.position.x = z[i,0] 
                marker.pose.position.y = z[i,1]
                marker.pose.position.z = 0.25
                obj_markers.markers.append(marker)
                marker_count += 1 """
        # Marker attempts
        #for i in range(1):
        #    marker_pub.publish(obj_markers)
        #    rospy.sleep(.01)
        #delete those obstacles that are far from the robot (if they exist)
        world_properties = rospy.ServiceProxy('/gazebo/get_world_properties', GetWorldProperties)().model_names

        for j in dist.argsort()[:3:-1]:
            if 'obstacle'+str(j) in world_properties:
                model_deleter = rospy.ServiceProxy('gazebo/delete_model', DeleteModel)
                model_deleter("obstacle"+str(j))
        toc = rospy.get_time()
        if DT - (toc - tic) - tk > 0:
            #print("Obj Spawn Sleeps for: ", DT - (toc-tic) - tk)
            rospy.sleep(DT - (toc - tic) - tk)

        #move those 4 obstacles stochastically
        
        for i in dist.argsort()[:4]:
            x_y_var = np.random.randint(2, size=1) #choose whether to move x or y (0 = x, 1 = y)
            mov_dist = np.random.normal(0, 0.5, size=1) #choose how much to move (change the variance, don't change mean)
            obstacle_coordinates = rospy.ServiceProxy('/gazebo/get_model_state', GetModelState)
            state_msg = ModelState()
            state_setter = rospy.ServiceProxy('/gazebo/set_model_state', SetModelState)
            state_msg.model_name = 'obstacle'+str(i)
            state_msg.pose.position.z = float(0)
            state_msg.pose.orientation.x = float(0)
            state_msg.pose.orientation.y = float(0)
            state_msg.pose.orientation.z = float(0)
            state_msg.pose.orientation.w = float(1)
            if(x_y_var==0):  
            #change position 
                state_msg.pose.position.y = obstacle_coordinates('obstacle'+str(i),'').pose.position.y
                state_msg.pose.position.x = obstacle_coordinates('obstacle'+str(i),'').pose.position.x + mov_dist
                set_state(state_msg)
            #wait
                rospy.sleep(0.05)
            #revert to previous position
                obstacle_coordinates = rospy.ServiceProxy('/gazebo/get_model_state', GetModelState)
                state_msg = ModelState()
                state_setter = rospy.ServiceProxy('/gazebo/set_model_state', SetModelState)
                state_msg.model_name = 'obstacle'+str(i)
                state_msg.pose.position.z = float(0)
                state_msg.pose.orientation.x = float(0)
                state_msg.pose.orientation.y = float(0)
                state_msg.pose.orientation.z = float(0)
                state_msg.pose.orientation.w = float(1)
                state_msg.pose.position.y = obstacle_coordinates('obstacle'+str(i),'').pose.position.y
                state_msg.pose.position.x = obstacle_coordinates('obstacle'+str(i),'').pose.position.x - mov_dist
                set_state(state_msg)
            else:
            #change position 
                state_msg.pose.position.x = obstacle_coordinates('obstacle'+str(i),'').pose.position.x
                state_msg.pose.position.y = obstacle_coordinates('obstacle'+str(i),'').pose.position.y + mov_dist
                set_state(state_msg)
            #wait
                rospy.sleep(0.05)
            #revert to previous position
                obstacle_coordinates = rospy.ServiceProxy('/gazebo/get_model_state', GetModelState)
                state_msg = ModelState()
                state_setter = rospy.ServiceProxy('/gazebo/set_model_state', SetModelState)
                state_msg.model_name = 'obstacle'+str(i)
                state_msg.pose.position.z = float(0)
                state_msg.pose.orientation.x = float(0)
                state_msg.pose.orientation.y = float(0)
                state_msg.pose.orientation.z = float(0)
                state_msg.pose.orientation.w = float(1)
                state_msg.pose.position.x = obstacle_coordinates('obstacle'+str(i),'').pose.position.x
                state_msg.pose.position.y = obstacle_coordinates('obstacle'+str(i),'').pose.position.y - mov_dist
                set_state(state_msg)
        
    except rospy.ROSInterruptException:
        pass