#!/usr/bin/env python
import numpy as np
import rospy
from ackermann_msgs.msg import AckermannDriveStamped
import pickle
import sys, os 
from nav_msgs.msg import Path
from geometry_msgs.msg import PoseStamped
import tf
import copy

# use TF to find most recent pose of the robot on the fly
def get_current_pose(listener, dt):
    #global dt
    tic = rospy.get_time()
    gate = True
    time_list = 0.0
    while gate:
        try:
            t,q = listener.lookupTransform('/odom', '/base_link', rospy.Time(0))
            time_list = rospy.get_time() - tic
            gate = False
            #print(t,r)
        except:
            rospy.sleep(.001) #1ms sleep
    rpy = tf.transformations.euler_from_quaternion(q)
    if time_list > dt:
        print("Transform Listener Took over DT!")
    #print("Pose is: ", t[0], t[1], rpy[2])
    #print("Time to get Pose: ", time_list)
    return np.array([ t[0], t[1], rpy[2] ]), time_list
 
#bring in columnwise numpy array of x,y,theta, outputs publishable path to ROS
def numpy_xyt_array_to_ros_path(np_array):
    # Now Republish the path to ROS for visualization
    path = Path()
    path.header.frame_id = "/map"
    #path.header.stamp = rospy.Time.now()
    x_os = np_array[:,0:3]
    for x in x_os:
        geom_msg = PoseStamped()
        geom_msg.header.frame_id = "/map"
        geom_msg.pose.position.x = x[0]
        geom_msg.pose.position.y = x[1]
        geom_msg.pose.position.z = 0
        #q = tf.transformations.quaternion_from_euler(0,0,x[2])
        #geom_msg.pose.orientation.x = q[0]
        #geom_msg.pose.orientation.y = q[1]
        #geom_msg.pose.orientation.z = q[2]
        #geom_msg.pose.orientation.w = q[3]
        path.poses.append(geom_msg)
    return path


def test_self_drive_path(path_file_name = "self_drive_3_37"):
    rospy.sleep(4)
    HZ = 15
    dur = rospy.Rate(HZ)
    cmd_pub = rospy.Publisher("/ackermann_cmd", AckermannDriveStamped, queue_size = 2)
    path_pub = rospy.Publisher("/tugboat/path/plan", Path, queue_size = 1)
    listener = tf.TransformListener()

    trajectories_dir = "/home/natsubuntu/catkin_ws/src/nesl_bot/Data/warehouse_trajectories/self_drive_no_obstacles/"
    trajectories_file = path_file_name
    paths_file = open(trajectories_dir + trajectories_file, 'rb')
    paths_data = pickle.load(paths_file) #, encoding='iso-8859-1')
    

    # Create Mega Path and Publish out for visualization
    mega_path = np.vstack( [path[2][:,0:3] for path in paths_data] )
    ros_mega_path = numpy_xyt_array_to_ros_path(mega_path)
    # Make sure the global path actually shows up
    for _ in range(5):
        path_pub.publish(ros_mega_path)
        dur.sleep()
    print("Published Full Path!")
    with_pause_between_trajectories = False
    while not rospy.is_shutdown():
        # Run Self Driving Loop
        rospy.sleep(1)
        print("Start Self Drive!")
        MAX_SPEED = 1.25 
        MAX_ANGLE = np.pi / 5.9
        #HZ = 15
        DT = 1.0 / HZ
        counter = 0
        for traj_data in paths_data:
            # Unpack start, goal, path, gains, time start / end
            #start_state = traj_data[0]
            #goal_state = traj_data[1]
            path_to_follow = traj_data[2]
            Ks = traj_data[3]
            #times = traj_data[4]
            x_os = path_to_follow[:,0:3]
            u_os = path_to_follow[:,3:5]
            times = traj_data[4]
            print("Path Start / End Times: ", times)
            # Track Path via LQR
            for xo, uo, K in zip(x_os, u_os, Ks):
                t1 = rospy.get_time()
                # Get current position
                xk, time_xk = get_current_pose(listener, DT)
                # Solve control
                if abs(xk[2] - xo[2]) > abs(xk[2] - xo[2] - 2*np.pi):
                    #print("QUATERNION SHIFT-> REAJUST!")
                    xk[2] -= 2*np.pi
                elif abs(xk[2] - xo[2] ) > abs(xk[2] - xo[2] + 2*np.pi):
                    #print("QUATERNION SHIFT-> REAJUST")
                    xk[2] += 2*np.pi
                ek = xk - xo
                #print("State Error is: ", ek)
                u_ek = np.matmul(K, ek)
                u_app = u_ek + uo
                if u_app[0] > MAX_SPEED + .0825:
                    u_app[0] = MAX_SPEED
                    #print("Clipped u_app speed!")
                if u_app[1] < -MAX_ANGLE:
                    u_app[1] = -MAX_ANGLE
                    #print("Clipped u_app! angle")
                elif u_app[1] > MAX_ANGLE:
                    u_app[1] = MAX_ANGLE
                    #print("Clipped u_app! angle")
                # Send Ackerman control off to ros
                ack_msg = AckermannDriveStamped()
                ack_msg.header.frame_id = "base_link"
                ack_msg.header.stamp = rospy.Time.now()
                ack_msg.drive.speed = u_app[0] #uo[0] #u_app[0]
                ack_msg.drive.steering_angle = u_app[1] #uo[1] #u_app[1]
                cmd_pub.publish(ack_msg)
                # Sleep for duration -- Enter Obstacle avoidance pipeline
                #print("Published Control: ", u_app)
                t2 = rospy.get_time()
                if not time_xk + (t2 - t1) > DT:
                    rospy.sleep(DT - (t2 - t1) - time_xk)
                    print("Slept For Time: ", DT - (t2 - t1) - time_xk)
            counter += 1
            # Make sure driving system is off at end of trajectory
            print("Finished Path Segment ", counter, " / ", len(paths_data))
            if with_pause_between_trajectories:
                ack_msg = AckermannDriveStamped()
                ack_msg.header.frame_id = "base_link"
                ack_msg.header.stamp = rospy.Time.now()
                ack_msg.drive.speed = 0
                ack_msg.drive.steering_angle = 0
                cmd_pub.publish(ack_msg)
                rospy.sleep(DT)
        ack_msg = AckermannDriveStamped()
        ack_msg.header.frame_id = "base_link"
        ack_msg.header.stamp = rospy.Time.now()
        ack_msg.drive.speed = 0
        ack_msg.drive.steering_angle = 0
        cmd_pub.publish(ack_msg)

def synch_path_with_lidar(path_file_name = "self_drive_3_37"):
    rospy.sleep(4)
    HZ = 15
    dur = rospy.Rate(HZ)
    cmd_pub = rospy.Publisher("/ackermann_cmd", AckermannDriveStamped, queue_size = 2)
    path_pub = rospy.Publisher("/tugboat/path/plan", Path, queue_size = 1)
    listener = tf.TransformListener()

    trajectories_dir = "/home/natsubuntu/catkin_ws/src/nesl_bot/Data/warehouse_trajectories/self_drive_no_obstacles/"
    trajectories_file = path_file_name
    paths_file = open(trajectories_dir + trajectories_file, 'rb')
    paths_data = pickle.load(paths_file) #, encoding='iso-8859-1')
    paths_file.close()

    # Create Mega Path and Publish out for visualization
    mega_path = np.vstack( [path[2][:,0:3] for path in paths_data] )
    ros_mega_path = numpy_xyt_array_to_ros_path(mega_path)
    # Make sure the global path actually shows up
    for _ in range(5):
        path_pub.publish(ros_mega_path)
        dur.sleep()
    print("Published Full Path!")
    with_pause_between_trajectories = False
    # Run Self Driving Loop Once
    rospy.sleep(1)
    print("Start Self Drive!")
    MAX_SPEED = 1.25 
    MAX_ANGLE = np.pi / 5.9
    DT = 1.0 / HZ
    counter = 0
    new_paths_data = []
    
    # Bring car along path
    for traj_data in paths_data:
        # Unpack start, goal, path, gains, time start / end
        #start_state = traj_data[0]
        #goal_state = traj_data[1]
        path_to_follow = traj_data[2]
        Ks = traj_data[3]
        #times = traj_data[4]
        x_os = path_to_follow[:,0:3]
        u_os = path_to_follow[:,3:5]
        lqr_controls = []
        real_time_poses = []
        # Print previous start end times
        old_times = copy.deepcopy(traj_data[4])
        #traj_data[4] = (0,0)
        print("Old Start / End Times: ", old_times)
        # This new time stamp can be used to sort the lidar data
        #traj_data[4] = list(traj_data[4])
        #traj_data[4][0] = rospy.get_time() # insert new time stamp into file
        tic = rospy.get_time()
        # Track Path via LQR
        for xo, uo, K in zip(x_os, u_os, Ks):
            t1 = rospy.get_time()
            # Get current position
            xk, time_xk = get_current_pose(listener, DT)
            # Solve control
            if abs(xk[2] - xo[2]) > abs(xk[2] - xo[2] - 2*np.pi):
                #print("QUATERNION SHIFT-> REAJUST!")
                xk[2] -= 2*np.pi
            elif abs(xk[2] - xo[2] ) > abs(xk[2] - xo[2] + 2*np.pi):
                #print("QUATERNION SHIFT-> REAJUST")
                xk[2] += 2*np.pi
            ek = xk - xo
            #print("State Error is: ", ek)
            u_ek = np.matmul(K, ek)
            u_app = u_ek + uo
            if u_app[0] > MAX_SPEED + .0825:
                u_app[0] = MAX_SPEED
                #print("Clipped u_app speed!")
            if u_app[1] < -MAX_ANGLE:
                u_app[1] = -MAX_ANGLE
                #print("Clipped u_app! angle")
            elif u_app[1] > MAX_ANGLE:
                u_app[1] = MAX_ANGLE
                #print("Clipped u_app! angle")
            # Send Ackerman control off to ros
            ack_msg = AckermannDriveStamped()
            ack_msg.header.frame_id = "base_link"
            ack_msg.header.stamp = rospy.Time.now()
            ack_msg.drive.speed = u_app[0] #uo[0] #u_app[0]
            ack_msg.drive.steering_angle = u_app[1] #uo[1] #u_app[1]
            cmd_pub.publish(ack_msg)
            lqr_controls.append(u_app) # append control to driving data set
            real_time_poses.append(xk)
            # Sleep for duration -- Enter Obstacle avoidance pipeline
            #print("Published Control: ", u_app)
            t2 = rospy.get_time()
            if not time_xk + (t2 - t1) > DT:
                rospy.sleep(DT - (t2 - t1) - time_xk)
                #print("Slept For Time: ", DT - (t2 - t1) - time_xk)
        
        toc = rospy.get_time() # insert new time stamp into file
        new_time_tuple = (tic,toc)
        #traj_data[4] = new_time_tuple
        print("New Times vs Old Times: ", new_time_tuple, old_times)
        new_paths_data.append(list(traj_data[0:4]) + [new_time_tuple, np.array(lqr_controls), np.array(real_time_poses)])
        # Assert the driving system is turned off at end of trajectory
        counter += 1
        print("Finished Path Segment ", counter, " / ", len(paths_data))
        if with_pause_between_trajectories:
            ack_msg = AckermannDriveStamped()
            ack_msg.header.frame_id = "base_link"
            ack_msg.header.stamp = rospy.Time.now()
            ack_msg.drive.speed = 0
            ack_msg.drive.steering_angle = 0
            cmd_pub.publish(ack_msg)
            rospy.sleep(5*DT)
    
    # Bring car to a hault
    ack_msg = AckermannDriveStamped()
    ack_msg.header.frame_id = "base_link"
    ack_msg.header.stamp = rospy.Time.now()
    ack_msg.drive.speed = 0
    ack_msg.drive.steering_angle = 0
    cmd_pub.publish(ack_msg)
    
    # Repickle old file with changed path times
    paths_file = open(trajectories_dir + trajectories_file, 'wb')
    pickle.dump(new_paths_data, paths_file)
    paths_file.close()
    print("Saved new parameters to file ", path_file_name)

if __name__ == "__main__":
    lidar_retime_path = False
    rospy.init_node("path_drive")
    rospy.sleep(1)
    self_drive_path = rospy.get_param("/self_drive_path_file")
    if lidar_retime_path:
        print("Resyncing Lidar and Controls!")
        synch_path_with_lidar(path_file_name=self_drive_path)
    else:
        print("Testing Self Drive!")
        test_self_drive_path(path_file_name=self_drive_path)