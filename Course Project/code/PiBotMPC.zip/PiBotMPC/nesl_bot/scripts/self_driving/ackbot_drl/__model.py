
from keras.models import Sequential, Model
from keras.layers import Dense, Activation, Flatten, BatchNormalization, Conv1D, MaxPool1D, LSTM, Input, Concatenate, Lambda, Dropout
from keras.optimizers import Adam, RMSprop
from keras.initializers import RandomUniform
from keras.models import load_model

from data_generator import get_transition_list, get_np_data_from_file, get_controls_from_q


from tensorboard import ModifiedTensorBoard

import numpy as np
import sys
import random
import os
import time
from collections import deque

VERBOSE=True


# Model for a network with purely just cnn layers
def pure_cnn(state_size, num_actions):

	model = Sequential()


	model.add(Conv1D(128, 3, activation='relu', input_shape=state_size))
	#model.add(MaxPool1D(pool_size=2))
	model.add(BatchNormalization())
	model.add(Dropout(0.25))

	model.add(Conv1D(128, 3, activation='relu', input_shape=state_size))
	#model.add(MaxPool1D(pool_size=2))
	model.add(BatchNormalization())
	model.add(Dropout(0.25))

	model.add(Conv1D(128, 3, activation='relu', input_shape=state_size))
	#model.add(MaxPool1D(pool_size=2))
	model.add(BatchNormalization())
	model.add(Dropout(0.25))


	#model.add(Conv1D(256, 3, activation='relu'))
	#model.add(MaxPool1D(pool_size=2))
	#model.add(BatchNormalization())
	#model.add(Dropout(0.25))

	#model.add(Conv1D(256, 3, activation='relu'))
	#model.add(MaxPool1D(pool_size=4))
	#model.add(BatchNormalization())
	#model.add(Dropout(0.25))

	
	model.add(Flatten())

	#model.add(Dense(1024, activation='relu'))
	#model.add(Dense(256, activation='relu'))

	#model.add(Dense(num_actions, activation='linear'))
	model.add(Dense(num_actions, activation='softmax'))

	return model


def cnn_lstm(state_size, num_actions):
	
	# Set up model weight initializers
	#init = RandomUniform(minval=0.,maxval=0.5)

	model = Sequential()

	model.add(Conv1D(128, 3, activation='relu', input_shape=state_size))
	model.add(MaxPool1D(pool_size=2))
	model.add(BatchNormalization())

	model.add(Conv1D(64, 3, activation='relu'))
	model.add(MaxPool1D(pool_size=2))
	model.add(BatchNormalization())

	model.add(Conv1D(32, 3, activation='relu'))
	model.add(MaxPool1D(pool_size=2))
	model.add(BatchNormalization())

	# Add an lstm layer
	model.add(LSTM(256, batch_input_shape=(None, 137,32))) # Reduce the values to a 256 element vector

	model.add(Dense(num_actions, activation='linear'))

	return model

# This is a hybrid network that splits based on the lidar data vs pose data
#  Separate conv network for each one.
def hybrid_network(state_size, num_actions):

	input = Input(shape=state_size) # Something like 100,1

	# Partition the data into what you want to focus on
	# In this case I split it into 40,1 and 60,1 (pose vs lidar)
	partitions = [[0,40],[40,100]]

	# Some custom finagling here:
	branch_outputs = []  #Where we put the outputs from the pose vs lidar data
	for partition in partitions:
		out = Lambda(lambda x: x[:,partition[0]:partition[1]])(input)
		# layer for each output
		out = Conv1D(64, 3, activation='relu')(out)
		out = MaxPool1D(pool_size=2)(out)

		out = Conv1D(64, 3, activation='relu')(out)
		out = MaxPool1D(pool_size=2)(out)
		out = Flatten()(out)
		out = Dense(32)(out)
		
		branch_outputs.append(out)

	out = Concatenate()(branch_outputs)

	out = Dense(num_actions, activation='linear')(out)
	
	model = Model(inputs=input, outputs=out)

	return model

# Create the class
class Delivery_boi:

	def __init__(self, state_size, num_actions, model_type="cnn"):

		random.seed(0)
	
		self.MODEL_NAME = "model_"
		if os.path.exists("logs"):
			self.MODEL_NAME += str(len(os.listdir("logs")))
		# Remember the log dir for tensorboard
		self.tensorboard = ModifiedTensorBoard(log_dir="logs/{}".format(self.MODEL_NAME))

		self.model_type = model_type

		# Other parameters
		self.REPLAY_MEMORY_SIZE = 1000
		self.MIN_REPLAY_MEMORY_SIZE = 800
		self.gamma = 0.95
		self.epsilon = 1.0
		self.epsilon_min = 0.1
		self.epsilon_decay = 0.995
		self.learning_rate = 0.01

		self.DISCOUNT = 0.99
		self.MINIBATCH_SIZE = 20#50
		self.UPDATE_TARGET_EVERY = 50# Every 5000 steps, we update the main model

		self.recent_save_path = "" # Remember the last model path you saved.

		#Get difference in predicted/measured q value
		self.q_differences = []

		# Check the number of actions we see in the training data for any particular action
		self.act_dict = {}
		
		# Count the number of updates
		self.target_update_counter = 0
		
		# Initialize the boi
		self.model = self.createModel(state_size, num_actions, model_type)
		# Initialize the target network - apparently Google Deepmind uses this 'double model' trick to help convergence
		self.target_model = self.createModel(state_size, num_actions, model_type)
		self.target_model.set_weights(self.model.get_weights()) # Take the weights from the main model used in training

		# Set the replay memory
		self.replay_memory = deque(maxlen=self.REPLAY_MEMORY_SIZE)

	# Update the action dictionary with the values
	def update_act_dict(self, action):

		if action not in self.act_dict:
			self.act_dict[action] = 1
		else:
			self.act_dict[action] += 1

	# Input is the number of states, output is the number of actions
	def createModel(self, state_size, num_actions, model_type):

		
		model = None
		if model_type == "cnn":
			model = pure_cnn(state_size, num_actions)
		elif model_type == "cnn-lstm":
			model = cnn_lstm(state_size, num_actions)
		elif model_type == "hybrid":
			model = hybrid_network(state_size, num_actions)
		
		model.compile(loss="sparse_categorical_crossentropy", optimizer=Adam(lr=0.0001), metrics=['accuracy'])
		#model.compile(loss="mse", optimizer=RMSprop(lr=0.000001, clipnorm=1.0), metrics=['mse'])
		

		# To deal with some random error
		#model.build(state_size)

		if VERBOSE:
			print(model.summary())

		return model

	# Only saves the self model
	def save_models(self, title="model"):

		model_dir = "models"
		if not os.path.exists(model_dir):
			os.makedirs(model_dir)
		model_type_dir = model_dir + "/" + self.model_type
		if not os.path.exists(model_type_dir):
			os.makedirs(model_type_dir)

		# Get the number of models in this models directory
		#  Model name is the number of models present
		model_name = title + "_" + str(len(os.listdir(model_type_dir)))
		model_path = model_type_dir + "/"  + model_name + ".h5"
		self.model.save_weights(model_path)

		self.recent_save_path = model_path


	# Update the replay memory
	# Each transition is a list of 5 elements:
	#  state vector (i.e. goal pose, current pose, next 10 poses, lidar scan)
	# action (i.e. LQR), should be two dimensions
	# reward (in this case, I think it should be -1 until done, in which case it is zero)
	#  next state vector (same size as state vector)
	#   boolean is episode over
	def update_replay_memory(self, transition):
		self.replay_memory.append(transition)

	# Get the Q values via DQN prediction
	def get_qs(self, state):
		return self.model.predict(state)

	#Get the average mae for the q values
	def get_average_q_mae(self):

		average_q_mae = -1
		if self.q_differences:
			average_q_mae = sum(self.q_differences)/len(self.q_differences)
			self.q_differences = []
		return average_q_mae

	def test_prediction(self, filepaths):

		#loaded_model = load_model(model_save_path, compile=False)
		#model.load_weights(model_save_path)
		#model = self.model

		for filepath in filepaths:

			full_np_data = get_np_data_from_file(filepath)
			# Get a random index from the paths
			#random_state_index = random.randint(0, full_np_data[0].shape[0]-1)

			print("Starting Prediction for " + str(filepath))

			# Iterate through the whole path:
			for i in range(0, full_np_data[0].shape[0]-1):

				print("\n\nWorking with Index : " + str(i))

				# Get the transition data from random index in random file
				transition_list = get_transition_list(i, full_np_data)
	
				# Get the train action
				true_action = transition_list[1]
				print("True action: " + str(true_action))
				v_true, phi_true = get_controls_from_q(true_action)
				print("V: " + str(v_true) + " Phi: " + str(phi_true))

				# Get one (or more) data points
				# These data points should be (100, 1) in the test_input, and become (M, 100, 1) in the current_states
				# test_input = random.sample(self.replay_memory, 20)

				#current_states = np.array([transition[0] for transition in test_input])
				current_states = transition_list[0][:35] # Get only the first 35 values
				current_states = np.expand_dims(current_states, axis=0)
				print("State size: " + str(current_states.shape))

				start_time = time.time()
				prediction = self.model.predict(current_states).flatten()
				latency = time.time() - start_time

				pred_action = prediction.argsort()[-5:][::-1]  # get top 5 in descending order
				#print("Predictions: " + str(prediction))
				#print()
				for pred in pred_action:
					print("Predicted action: " + str(pred))
					v_pred, phi_pred = get_controls_from_q(pred)
					print("V: " + str(v_pred) + " Phi: " + str(phi_pred))

				# If you want the assert statement, uncomment this.
				# assert latency < 0.06, "Prediction Latency is above acceptable 60 ms limit: %r" % latency
				print("Prediction Latency: " + str(latency))

			print("End Prediction for " + str(filepath))
		

	# Train main network
	def train(self):

		
		
		# Only train if we have enough samples saved
		if len(self.replay_memory) < self.MIN_REPLAY_MEMORY_SIZE:
			return


		# Get minibatch of data
		minibatch = random.sample(self.replay_memory, self.MINIBATCH_SIZE)


		# Predict Q value for current state
		current_states = np.array([transition[0] for transition in minibatch])
		current_qs_list = self.target_model.predict(current_states)

		# Get future states from minibatch, then query NN model for Q values
		# When using target network, query it, otherwise main network should be queried
		#new_current_states = np.array([transition[3] for transition in minibatch])
		#future_qs_list = self.target_model.predict(new_current_states)



		X = []
		y = []
		terminal_state = False

		# Now we need to enumerate our batches
		for index, (current_state, action, reward, new_current_state, done) in enumerate(minibatch):

			# If not a terminal state, get new q from future states, otherwise set it to 0
			# almost like with Q Learning, but we use just part of equation here
			#if not done:
			#	max_future_q = np.max(future_qs_list[index])

			#	new_q = reward + self.DISCOUNT * max_future_q
			#else:
				#print("Reached terminal state")
			#	new_q = reward
			#	terminal_state = True

			# Update the action dict
			self.update_act_dict(action)

			# Update Q value for given state
			current_qs = current_qs_list[index]
			
			# Get difference in predicted vs new q value
			#old_q = current_qs[action]
			#current_qs[action] = new_q
			#self.q_differences.append(abs(new_q - old_q))
			
			#print(current_qs[action])  # This is the prediction
			#print(current_qs[action-1:action+2]) # Show the surrounding items
			
			# And append to our training data
			#current_qs = np.zeros(current_qs.shape)
			#current_qs[action] = 1
			#current_qs = np.expand_dims(current_qs, axis=0)
			#print(current_qs.shape)
			X.append(current_state)
			y.append(action)
			#print("Training with action: " + str(action))

		#print(np.array(X).shape)
		#print(np.array(y).shape)

		# Fit on all samples as one batch, log only on terminal state
		#self.model.fit(np.array(X), np.array(y), batch_size=self.MINIBATCH_SIZE, verbose=0, shuffle=False)
		self.model.fit(np.array(X), np.array(y), batch_size=self.MINIBATCH_SIZE, verbose=0, 
			shuffle=False,	 callbacks=[self.tensorboard] if terminal_state else None)

		#asdf
		# Update target network counter every number of steps
		#if terminal_state:
		self.target_update_counter += 1

		# If counter reaches set value, update target network with weights of main network
		if self.target_update_counter > self.UPDATE_TARGET_EVERY:
			#print("UPDATING MODEL")
			self.target_model.set_weights(self.model.get_weights())
			self.target_update_counter = 0
		


# https://pythonprogramming.net/own-environment-q-learning-reinforcement-learning-python-tutorial/?completed=/q-learning-analysis-reinforcement-learning-python-tutorial/
