import numpy as np
import os
import math
from random import randrange
import pickle

class dict_keys:

	TIMESTAMP = "ts"	
	GOAL_POSE = "gp"
	START_POSE = "sp"
	PATHS = "pt"
	CONTROL_GAIN = "cg"
	LQR_CONTROLS = "lqr"
	S_HISTORY = "sh"
	LIDAR_SCAN = "ls"


# Receive an NP array containing two elements, the pose/lidar data and the goal pose
# Returns the ndarray of elements with pose/lidar data, goal pose, lqr controls, and state history
def get_np_data_from_file(filepath):

	path_dictionary = {}
	fp = open(filepath, 'rb')
	loaded_data = pickle.load(fp) #np.load(filepath, allow_pickle=True, encoding='bytes')
	return loaded_data
	
#  Returns a flattened array of path points, of window_size
#  Looks into the future path_pose_data and returns the next window_size poses, flattened.
#  If we reach the window is bigger than the data left, simply copy the last row until we fill the window.
#  TODO: Make sure the indexes are correct
def get_lookahead_window(window_size, index, path_pose_data):

	#  The reason why we use 2 is because we only need the x,y pose of the future poses.
	window_shape = (window_size, 2)
	window_data = np.zeros(window_shape)

	# Once we reach the end of a path, there will be no future points
	# So it's risky to just use the leftover data - instead we have to append zeroes.
	if index + window_size > path_pose_data.shape[0] - 1:	
		len_path = path_pose_data[index:].shape[0]
		window_data[0:len_path] = path_pose_data[index:]
		window_data[len_path:] = path_pose_data[-1,:]
	else:
		window_data = path_pose_data[index:index+window_size]
	
	return window_data.flatten()

def get_lookahead_window_no_flat(window_size, index, path_pose_data):

	#  The reason why we use 2 is because we only need the x,y pose of the future poses.
	window_shape = (window_size, 2)
	window_data = np.zeros(window_shape)

	# Once we reach the end of a path, there will be no future points
	# So it's risky to just use the leftover data - instead we have to append zeroes.
	if index + window_size > path_pose_data.shape[0] - 1:	
		len_path = path_pose_data[index:].shape[0]
		window_data[0:len_path] = path_pose_data[index:]
		window_data[len_path:] = path_pose_data[-1,:]
	else:
		window_data = path_pose_data[index:index+window_size]
	
	return window_data #.flatten()

# Given a state history value, find the closest path pose.
#  We only compare x,y values, not heading.
# Nominal pose path should be (Z x 5), we don't need all of it
def find_closest_nominal_pose(current_pose, nominal_pose_path):

	pose_no_heading = current_pose[:2].reshape((1,2)) # just the x,y value
	diff = np.linalg.norm(np.abs(pose_no_heading - nominal_pose_path[:,0:2]), axis = 1)
	#diff = diff[:,0] + diff[:,1]  # Distance is determined by x and y differences summed up
	min_index = np.argmin(diff)
	min_distance = diff[min_index]
	return min_index, min_distance


#  Arranges the state vectors, actions, and rewards from the get_np_data_from_file
#  Remember, this returns the full set of state vectors for a file
#   meaning you get X state vectors if you have X path poses.
def get_transition_data(loaded_data, future_window_size=15):

	full_states_vector=  [] # Full set of state vectors for file

	path_packet_data = loaded_data[0] # some (Z x 64, 1=ts + 3=pose + 60=lidar)
	goal_pose_data = loaded_data[1][:2]	 # Only take 2 values
	lqr_data = loaded_data[2] # ~Z x 2
	nominal_pose_path = loaded_data[3] # ~Zx5

	# Grab just the path pose data (just the x,y values)
	path_pose_data = path_packet_data[:,1:3]

	# Iterate through the paths, linking them up with the lqr data and state history
	for index, row in enumerate(path_packet_data):

		# Get the current timestamp
		current_timestamp = row[0]

		# Get the current pose
		current_pose = row[1:4]
		#print(current_pose.shape)

		# Get the lidar data:
		lidar_data = row[4:]
		
		# Get the closest index of the nominal path
		closest_nominal_index, _ = find_closest_nominal_pose(current_pose, nominal_pose_path)

		# Get the next window size points
		future_points = get_lookahead_window(future_window_size, closest_nominal_index, nominal_pose_path)
		
		# Arranged by a flattened set of vectors
		# goal pose, current pose, next X path poses, lidar scan.
		current_state_vector = [goal_pose_data]
		#print(goal_pose_data.shape)
		#  Append everything we got to the current_state_vector
		current_state_vector.append(current_pose)
		#print(current_pose.shape)
		current_state_vector.append(future_points)
		#print(future_points.shape)
		current_state_vector.append(lidar_data)
		#print(lidar_data.shape)

		# stack the vector so it remains flat
		current_state_vector = np.hstack(current_state_vector)
		
		full_states_vector.append(current_state_vector)
	# Stack the state vector so we have a 2 d array 
	full_states_vector = np.vstack(full_states_vector)
	return full_states_vector, lqr_data


def get_all_possible_paths(desired_titles, top_dir="../generated/"):

	path_files = []

	# list the directory, choose a valid folder
	possible_folders = os.listdir(top_dir)
	desired_folders = []
	# Filter out the folders based on desired_titles
	# Basically, for each desired title we create a list of possible_paths that contain that title
	#  We then append it to desired_folders and use that get the paths.
	for title in desired_titles:
		desired_folders.extend([x for x in possible_folders if title in x])

	for chosen_folder in desired_folders:

		# List out paths in this folder
		paths_dir = top_dir + chosen_folder
		possible_paths = os.listdir(paths_dir)

		for path in possible_paths:
			path_files.append(paths_dir + "/" + path)

	return path_files

# Reward is currently determined if this is the end of the episode.
#  Since everything is a nominal path, the reward increases the closer we get
#  However, we do need to account for time.
def get_reward(full_length, index):

	reward = index/full_length
	#if index == full_length-1: # Episode is over
	#	reward = 100

	# With some probability (i.e. 60%), drop out the reward (introduce sparse rewards)
	# Fuck me it's 3am
	dropout_val = randrange(100)
	if dropout_val < 60:
		reward = 0

	return reward

# Sets the bins for our discretization, and returns those bins.
def get_discretized_space():

	v_vals = [-0.25, 0.0, 0.25, 0.50, 0.75, 1.0, 1.25] # 7 bins
	phi_deg_interval = 3 # Let's do a bin every 3 degrees
	phi_deg = [x for x in range(-30, 30, phi_deg_interval)] # This is in degrees, from -30 to 30.
	phi_radians = [math.radians(x) for x in phi_deg]

	return v_vals, phi_radians

# Returns the controls corresponding to the q index
def get_controls_from_q(q_index):

	v_vals, phi_radians = get_discretized_space()
	
	phi_index = q_index % len(phi_radians)
	phi_val = phi_radians[phi_index]
	v_index = q_index // len(phi_radians)
	v_val = v_vals[v_index]

	return v_val, phi_val
	

#  Takes vector of two values (v and phi) and discretizes them
#  How this binning actually works is depending on what value the lqr control is closest to.
#  I have originally set the velocity into the following bins:
#  v = [-0.25, 0.0, 0.05, 0.35, 0.65, 0.95, 1.25] which is 7 bins total
#  phi = [-30deg, -20, -10, 0, 10, 20, 30] which is 7 bins total.
#  Think of this space of actions being represented as a one hot vector,
#  which is of shape v_bins * phi_bins, with the first entry representing i.e. -0.25v and -30deg
#  This resulting output is actually the index of the bin.
def discretize_lqr(lqr_row):
	
	v_vals, phi_radians = get_discretized_space()	

	# Find the index of closest lqr value for v and phi
	v_index = v_vals.index(min(v_vals, key=lambda x:abs(x-lqr_row[0])))
	phi_index = phi_radians.index(min(phi_radians, key=lambda x:abs(x-lqr_row[1])))

	# Return a one hot vector, where the position of the 1 depends on v_index*vbinsize + phi_index
	one_hot_index = v_index * len(phi_radians) + phi_index
	
	# Size of the model output
	#print(len(v_vals) * len(phi_radians))

	return one_hot_index

# Determined by the discretized space, which is 0 velocity and 0 phi.
#  It's probably 1*7 + 10
def get_zero_action():
	return 17

# Gets the state vector at index, the action taken, the reward, the next state vector, and a boolean if this episode is over.
def get_transition_list(index, full_np_data):

	full_states_vector, lqr_data = get_transition_data(full_np_data) # Get the state vector and lqr controls

	# This is to deal with an error where if the amount of lqr data is actually less than our full states,
	#  we just shrink the full_states_vector until they are the same size, and also change the index
	#size_diff = full_states_vector.shape[0] - lqr_data.shape[0]
	#if size_diff > 0:
#		full_states_vector = full_states_vector[:lqr_data.shape[0]]
#		index -= size_diff


	current_state_vector = full_states_vector[index]
	
	reward = get_reward(full_states_vector.shape[0], index)
	
	action_taken = get_zero_action()  # By default, if we reach the end state, we take the zero action.
	future_state_vector = full_states_vector[-1]  # By default the future state vector is the last state.
	isDone = True
	if index < full_states_vector.shape[0]-1:  #If we aren't at the last state vector, we aren't done.
		future_state_vector = full_states_vector[index+1]
		action_taken = discretize_lqr(lqr_data[index])
		isDone = False
	

	# Filter out NaNs, Nones
	current_state_vector = np.array(current_state_vector, dtype=float)
	current_state_vector = np.nan_to_num(current_state_vector)
	future_state_vector = np.array(future_state_vector, dtype=float)
	future_state_vector = np.nan_to_num(future_state_vector)

	# Try changing state vectors into 2dim (i.e. 1111,1)
	current_state_vector = np.expand_dims(current_state_vector, axis=1)
	#current_state_vector = np.expand_dims(current_state_vector, axis=0)
	future_state_vector = np.expand_dims(future_state_vector, axis=1)
	#future_state_vector = np.expand_dims(future_state_vector, axis=0)

	return [current_state_vector, action_taken, reward, future_state_vector, isDone]
	
	

#loaded_data =  get_np_data_from_file("../data/self_drive_0_26/0.npy")
#full_states_vector = arrange_state_vector(loaded_data)
#print(full_states_vector.shape)
#random_path_file = get_all_possible_paths()[5]
#full_np_data = get_np_data_from_file(random_path_file)
#for i, e in enumerate(get_transition_list(0, full_np_data)):
#	if i == 2 or i == 4:
#		print(e)
#	else:
#		print(e.shape)
	

