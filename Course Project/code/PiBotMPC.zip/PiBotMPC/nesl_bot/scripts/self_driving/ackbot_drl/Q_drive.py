#!/usr/bin/env python
import numpy as np
import rospy
from ackermann_msgs.msg import AckermannDriveStamped
import pickle
import sys, os 
from nav_msgs.msg import Path
from geometry_msgs.msg import PoseStamped
import tf
import copy
from sensor_msgs.msg import LaserScan
from data_extractor import get_most_significant_lidar_points
from data_generator import get_all_possible_paths, get_np_data_from_file, get_lookahead_window, get_controls_from_q, find_closest_nominal_pose, get_lookahead_window_no_flat
from model import Delivery_boi
import numpy as np
import random
from sensor_msgs.msg import Joy
from visualization_msgs.msg import MarkerArray, Marker
from keras.models import load_model

state_vector_shape = (95,1)
action_vector_shape = 147
lidar_ranges = 30*np.ones(60)
controls = np.zeros(2) 
start_log = False
pause_between_traj = False
delete_path_interval = False
phi_bins = np.linspace(start = -np.pi / 6, stop = np.pi / 6, num = 21 )
vel_bins = np.array([-0.25, 0.0, 0.25, 0.50, 0.75, 1.0, 1.25])
control_indxs = np.array([[v,p] for p in phi_bins for v in vel_bins ])

class TrajectoryStats:
    def __init__(self, total_num_paths, is_q_lqr_compare = True, DT = 1.0 / 15):
        # Need to find these stats for each traj along the full loop
        self.is_q_lqr_compare = is_q_lqr_compare
        self.q_vs_lqr_ratios = []
        #self.goal_completion_ratio = None
        self.states = []
        self.controls = []
        self.dt = DT
        self.traj_packets = []
        self.total_num_paths = total_num_paths

    def add_state_control(self, state, control, is_q_lqr = None):
        if self.is_q_lqr_compare:
            assert is_q_lqr is not None
            self.q_vs_lqr_ratios.append(is_q_lqr)
        self.states.append(state)
        self.controls.append(control)
    
    def set_trajectory_stats(self):
        # Find the time of the trajectory taken
        tictoc = len(self.states) * self.dt 
        # Length of path 
        states = np.array(self.states)[:,0:2]
        traj_length = np.sum(np.linalg.norm(states[1:] - states[0:-1], axis = 1))
        traj_q_vs_lqr = None 
        if self.is_q_lqr_compare:
            traj_q_vs_lqr = np.sum(self.q_vs_lqr_ratios) / len(self.q_vs_lqr_ratios)
        # Find Average Speed taken:
        speeds = np.array(self.controls)[:,0]
        avg_speed = np.mean(speeds)
        print(traj_length, tictoc, traj_q_vs_lqr, avg_speed, np.array(self.states).shape, np.array(self.controls).shape)
        self.traj_packets.append([traj_length, tictoc, traj_q_vs_lqr, 
                                 avg_speed, np.array(self.states), np.array(self.controls)])
        # reset lists
        self.states = []
        self.controls = []
        self.q_vs_lqr_ratios = []

    def save_data(self, file_path):
        fp = open(file_path, 'wb')
        pickle.dump(self.traj_packets,fp)
        fp.close()

def swap_nat_get_control_label(indx):
    global control_indxs
    return control_indxs[indx]

def laser_callback(msg):
    global lidar_ranges
    #Brian prune
    lscan = np.array(msg.ranges)
    lidar_ranges = get_most_significant_lidar_points(lscan)

def joy_callback(msg):
    global controls, start_log, pause_between_traj, delete_path_interval
    # Need to lock controls temporarily
    controls[0] = msg.axes[1] * 1.00
    controls[1] = msg.axes[3] * np.pi / 6.0
    if msg.buttons[0]:
        start_log = True
    # If right button was pressed, pause after next waypoint
    if msg.buttons[5]:
        print("Requested pause between paths")
        pause_between_traj = True
    # If left trigger is presed, resume
    if msg.buttons[4]:
        pause_between_traj = False
    if msg.buttons[1]:
        delete_path_interval = True

def get_normal_line(x1, y1, x2, y2):
    #if np.abs(x2 - x1) < 1e-12:
    #    delt_x = 1e-12
    #if y2 - y1 
    m = (y2 - y1) / (x2 - x1) 
    #b = y2 - m * x2 
    m2 = -1.0 / m 
    b2 = y2 - m2 * x2 
    return (np.array([-m2, 1.0]), b2)

def get_sign_of_point_wrt_line(A, b, x):
    return np.sign( np.dot(A,x) - b)

#bring in columnwise numpy array of x,y,theta, outputs publishable path to ROS
def numpy_xyt_array_to_ros_path(np_array):
    # Now Republish the path to ROS for visualization
    path = Path()
    path.header.frame_id = "/map"
    #path.header.stamp = rospy.Time.now()
    x_os = np_array[:,0:3]
    for x in x_os:
        geom_msg = PoseStamped()
        geom_msg.header.frame_id = "/map"
        geom_msg.pose.position.x = x[0]
        geom_msg.pose.position.y = x[1]
        geom_msg.pose.position.z = 0
        #q = tf.transformations.quaternion_from_euler(0,0,x[2])
        #geom_msg.pose.orientation.x = q[0]
        #geom_msg.pose.orientation.y = q[1]
        #geom_msg.pose.orientation.z = q[2]
        #geom_msg.pose.orientation.w = q[3]
        path.poses.append(geom_msg)
    return path

def pub_np_path_2_rviz(np_array, pub):
    # Now Republish the path to ROS for visualization
    path = Path()
    path.header.frame_id = "/map"
    #path.header.stamp = rospy.Time.now()
    x_os = np_array[:,0:2]
    for x in x_os:
        geom_msg = PoseStamped()
        geom_msg.header.frame_id = "/map"
        geom_msg.pose.position.x = x[0]
        geom_msg.pose.position.y = x[1]
        geom_msg.pose.position.z = 0
        geom_msg.pose.orientation.w = 1
        #q = tf.transformations.quaternion_from_euler(0,0,x[2])
        #geom_msg.pose.orientation.x = q[0]
        #geom_msg.pose.orientation.y = q[1]
        #geom_msg.pose.orientation.z = q[2]
        #geom_msg.pose.orientation.w = q[3]
        path.poses.append(geom_msg)
    for i in range(3):
        pub.publish(path)
        rospy.sleep(.001)

# use TF to find most recent pose of the robot on the fly
def get_current_pose(listener, dt):
    #global dt
    tic = rospy.get_time()
    gate = True
    time_list = 0.0
    while gate:
        try:
            t,q = listener.lookupTransform('/odom', '/base_link', rospy.Time(0))
            time_list = rospy.get_time() - tic
            gate = False
            #print(t,r)
        except:
            rospy.sleep(.001) #1ms sleep
    rpy = tf.transformations.euler_from_quaternion(q)
    if time_list > dt:
        print("Transform Listener Took over DT!")
    #print("Pose is: ", t[0], t[1], rpy[2])
    #print("Time to get Pose: ", time_list)
    return np.array([ t[0], t[1], rpy[2] ]), time_list
 

def hybrid_q_self_drive(path_file_name = "self_drive_3_37"):
    global lidar_ranges
    HZ = 15
    dur = rospy.Rate(HZ)
    cmd_pub = rospy.Publisher("/ackermann_cmd", AckermannDriveStamped, queue_size = 2)
    path_pub = rospy.Publisher("/tugboat/path/plan", Path, queue_size = 1)
    path_rl_pub = rospy.Publisher("/tugboat/path/rl_bot", Path, queue_size = 1)
    marker_array_pub = rospy.Publisher("/tugboat/goal_point/markers", MarkerArray, queue_size=10)
    listener = tf.TransformListener()

    trajectories_dir = "/home/natsubuntu/catkin_ws/src/nesl_bot/Data/warehouse_trajectories/self_drive_no_obstacles/"
    trajectories_file = path_file_name
    #paths_file = open(trajectories_dir + trajectories_file, 'rb')
    #paths_data = pickle.load(paths_file) #, encoding='iso-8859-1')

    drive_stats_path = "/home/natsubuntu/catkin_ws/src/nesl_bot/scripts/self_driving/ackbot_drl/drive_stats/drive_stats1_hyrbid_" + trajectories_file
    MODEL_FILEPATH = "/home/natsubuntu/catkin_ws/src/nesl_bot/scripts/self_driving/ackbot_drl/models/cnn/swap_nat_rl3.hdf5"

    # Initialize the RL model
    #dev_boi = Delivery_boi(state_vector_shape, action_vector_shape, MODEL_TYPE)
    model = load_model(MODEL_FILEPATH)
    # Load the model
    print("Model Loaded!")
    
    rospy.sleep(4)
    goal_points, goal_lines, start_signs, paths_data = load_path_to_rviz(path_pub, path_file = trajectories_dir + trajectories_file)
    t_stats = TrajectoryStats(len(goal_points))
    # Create Mega Path and Publish out for visualization
    #mega_path = np.vstack( [path[2][:,0:3] for path in paths_data] )
    #ros_mega_path = numpy_xyt_array_to_ros_path(mega_path)
    # Make sure the global path actually shows up
    #for _ in range(5):
    #    path_pub.publish(ros_mega_path)
    #    dur.sleep()
    #print("Published Full Path!")
    with_pause_between_trajectories = False
    #while not rospy.is_shutdown():
    # Run Self Driving Loop
    rospy.sleep(1)
    print("Start Self Drive!")
    MAX_SPEED = 1.25 
    MAX_ANGLE = np.pi / 5.9
    #HZ = 15
    DT = 1.0 / HZ
    counter = 0
    try:
        for traj_data in paths_data:
            # Publish out next three goal positions
            if counter + 3 >= len(goal_points):
                publish_goal_point_markers(marker_array_pub, goal_points[counter:])
            else:
                publish_goal_point_markers(marker_array_pub, goal_points[counter:counter+3])
            # Unpack start, goal, path, gains, time start / end
            #start_state = traj_data[0]
            goal_state = traj_data[1]
            path_to_follow = traj_data[2]
            Ks = traj_data[3]
            #times = traj_data[4]
            x_os = path_to_follow[:,0:3]
            u_os = path_to_follow[:,3:5]
            times = traj_data[4]
            print("Path Start / End Times: ", times)
            # Track Path via LQR
            l2_norm_min = 1.25
            xk, time_xk = get_current_pose(listener, DT) # current pose
            cl_indx, path_error = find_closest_nominal_pose(xk.reshape(-1), x_os[:,0:2])
            path_chunk = get_lookahead_window(15, cl_indx, x_os[:,0:2])
            path_chunk_no_flat = get_lookahead_window_no_flat(15, cl_indx, x_os[:,0:2])
            xo = x_os[cl_indx]
            #for xo, uo, K in zip(x_os, u_os, Ks):
            while  not ( (np.linalg.norm(goal_points[counter] - xk[0:2]) < l2_norm_min) and (get_sign_of_point_wrt_line(goal_lines[counter][0], goal_lines[counter][1], xk[0:2]) != start_signs[counter]) ):
                t1 = rospy.get_time()
                # find about where we are on the nominal path 
                # Solve control
                if abs(xk[2] - xo[2]) > abs(xk[2] - xo[2] - 2*np.pi):
                    #print("QUATERNION SHIFT-> REAJUST!")
                    xk[2] -= 2*np.pi
                elif abs(xk[2] - xo[2] ) > abs(xk[2] - xo[2] + 2*np.pi):
                    #print("QUATERNION SHIFT-> REAJUST")
                    xk[2] += 2*np.pi
                
                # Publish out closest path chunk
                pub_np_path_2_rviz(path_chunk_no_flat, path_rl_pub)

                # Create conditional for when the norm of x,y,theta deviates from x,y,theta (path), use LQR to regain control
                phi_app = 0
                v_app = 0
                # use LQR
                q_net_bool = True
                if path_error > .60:
                    ek = xk - xo
                    _K = Ks[cl_indx]
                    uo = u_os[cl_indx]
                    #print("State Error is: ", ek)
                    u_ek = np.matmul(_K, ek)
                    u_app = u_ek + uo
                    if u_app[0] > MAX_SPEED + .0825:
                        u_app[0] = MAX_SPEED
                        #print("Clipped u_app speed!")
                    if u_app[0] < .05:
                        u_app[0] = .10
                    if u_app[1] < -MAX_ANGLE:
                        u_app[1] = -MAX_ANGLE
                    #print("Clipped u_app! angle")
                    elif u_app[1] > MAX_ANGLE:
                        u_app[1] = MAX_ANGLE
                    v_app = u_app[0]
                    phi_app = u_app[1]
                    print("LQR Actions: ", v_app, phi_app)
                    q_net_bool = False
                # use Q-Net
                else:
                    q_vec = np.concatenate((goal_state[0:2], xk, path_chunk, lidar_ranges)).reshape((1,95,1))
                    q_control = model.predict(q_vec)
                    best_act = np.argmax(q_control)
                    v_app, phi_app = swap_nat_get_control_label(best_act)
                    if v_app < .05:
                        v_app = .05
                    print("Q-Net Actions: ", v_app, phi_app)
                # log states, controls, action decision
                t_stats.add_state_control(xk.reshape(-1), np.array([v_app,phi_app]), is_q_lqr=q_net_bool)
                
                # Send Ackerman control off to ros
                ack_msg = AckermannDriveStamped()
                ack_msg.header.frame_id = "base_link"
                ack_msg.header.stamp = rospy.Time.now()
                ack_msg.drive.speed = v_app #uo[0] #u_app[0]
                ack_msg.drive.steering_angle = phi_app #uo[1] #u_app[1]
                cmd_pub.publish(ack_msg)
                # Sleep for duration -- Enter Obstacle avoidance pipeline
                t2 = rospy.get_time()
                if not time_xk + (t2 - t1) > DT:
                    rospy.sleep(DT - (t2 - t1) - time_xk)
                    print("Slept For Time: ", DT - (t2 - t1) - time_xk)
                # Get new current position
                xk, time_xk = get_current_pose(listener, DT)
                cl_indx, path_error = find_closest_nominal_pose(xk.reshape(-1), x_os[:,0:2])
                path_chunk = get_lookahead_window(15, cl_indx, x_os[:,0:2])
                path_chunk_no_flat = get_lookahead_window_no_flat(15, cl_indx, x_os[:,0:2])
                xo = x_os[cl_indx]
            counter += 1
            t_stats.set_trajectory_stats()
            # Make sure driving system is off at end of trajectory
            print("Finished Path Segment ", counter, " / ", len(paths_data))
            if with_pause_between_trajectories:
                ack_msg = AckermannDriveStamped()
                ack_msg.header.frame_id = "base_link"
                ack_msg.header.stamp = rospy.Time.now()
                ack_msg.drive.speed = 0
                ack_msg.drive.steering_angle = 0
                cmd_pub.publish(ack_msg)
                rospy.sleep(DT)
        ack_msg = AckermannDriveStamped()
        ack_msg.header.frame_id = "base_link"
        ack_msg.header.stamp = rospy.Time.now()
        ack_msg.drive.speed = 0
        ack_msg.drive.steering_angle = 0
        cmd_pub.publish(ack_msg)
        t_stats.save_data(drive_stats_path)
    except Exception:
        ack_msg = AckermannDriveStamped()
        ack_msg.header.frame_id = "base_link"
        ack_msg.header.stamp = rospy.Time.now()
        ack_msg.drive.speed = 0
        ack_msg.drive.steering_angle = 0
        cmd_pub.publish(ack_msg)
        t_stats.traj_packets.append(t_stats.total_num_paths)
        t_stats.save_data(drive_stats_path)
        print("Saved Data to file!")

def pure_q_self_drive(path_file_name = "self_drive_3_37"):
    global lidar_ranges
    HZ = 15
    dur = rospy.Rate(HZ)
    cmd_pub = rospy.Publisher("/ackermann_cmd", AckermannDriveStamped, queue_size = 2)
    path_pub = rospy.Publisher("/tugboat/path/plan", Path, queue_size = 1)
    path_rl_pub = rospy.Publisher("/tugboat/path/rl_bot", Path, queue_size = 1)
    marker_array_pub = rospy.Publisher("/tugboat/goal_point/markers", MarkerArray, queue_size=10)
    listener = tf.TransformListener()

    trajectories_dir = "/home/natsubuntu/catkin_ws/src/nesl_bot/Data/warehouse_trajectories/self_drive_no_obstacles/"
    trajectories_file = path_file_name
    #paths_file = open(trajectories_dir + trajectories_file, 'rb')
    #paths_data = pickle.load(paths_file) #, encoding='iso-8859-1')

    drive_stats_path = "/home/natsubuntu/catkin_ws/src/nesl_bot/scripts/self_driving/ackbot_drl/drive_stats/drive_stats_pure_q_obstacle_" + trajectories_file
    MODEL_FILEPATH = "/home/natsubuntu/catkin_ws/src/nesl_bot/scripts/self_driving/ackbot_drl/models/cnn/foo.hdf5" #swap_nat_rl3

    # Initialize the RL model
    #dev_boi = Delivery_boi(state_vector_shape, action_vector_shape, MODEL_TYPE)
    model = load_model(MODEL_FILEPATH)
    # Load the model
    print("Model Loaded!")
    
    rospy.sleep(4)
    goal_points, goal_lines, start_signs, paths_data = load_path_to_rviz(path_pub, path_file = trajectories_dir + trajectories_file)
    t_stats = TrajectoryStats(len(goal_points), is_q_lqr_compare=True)
    # Create Mega Path and Publish out for visualization
    #mega_path = np.vstack( [path[2][:,0:3] for path in paths_data] )
    #ros_mega_path = numpy_xyt_array_to_ros_path(mega_path)
    # Make sure the global path actually shows up
    #for _ in range(5):
    #    path_pub.publish(ros_mega_path)
    #    dur.sleep()
    #print("Published Full Path!")
    with_pause_between_trajectories = False
    #while not rospy.is_shutdown():
    # Run Self Driving Loop
    rospy.sleep(1)
    print("Start Self Drive!")
    MAX_SPEED = 1.25 
    MAX_ANGLE = np.pi / 5.9
    #HZ = 15
    DT = 1.0 / HZ
    counter = 0
    try:
        for traj_data in paths_data:
            # Publish out next three goal positions
            if counter + 3 >= len(goal_points):
                publish_goal_point_markers(marker_array_pub, goal_points[counter:])
            else:
                publish_goal_point_markers(marker_array_pub, goal_points[counter:counter+3])
            # Unpack start, goal, path, gains, time start / end
            #start_state = traj_data[0]
            goal_state = traj_data[1]
            path_to_follow = traj_data[2]
            Ks = traj_data[3]
            #times = traj_data[4]
            x_os = path_to_follow[:,0:3]
            u_os = path_to_follow[:,3:5]
            times = traj_data[4]
            print("Path Start / End Times: ", times)
            # Track Path via LQR
            l2_norm_min = 1.25
            xk, time_xk = get_current_pose(listener, DT) # current pose
            cl_indx, path_error = find_closest_nominal_pose(xk.reshape(-1), x_os[:,0:2])
            path_chunk = get_lookahead_window(15, cl_indx, x_os[:,0:2])
            path_chunk_no_flat = get_lookahead_window_no_flat(15, cl_indx, x_os[:,0:2])
            xo = x_os[cl_indx]
            #for xo, uo, K in zip(x_os, u_os, Ks):
            while  not ( (np.linalg.norm(goal_points[counter] - xk[0:2]) < l2_norm_min) and (get_sign_of_point_wrt_line(goal_lines[counter][0], goal_lines[counter][1], xk[0:2]) != start_signs[counter]) ):
                t1 = rospy.get_time()
                # find about where we are on the nominal path 
                # Solve control
                if abs(xk[2] - xo[2]) > abs(xk[2] - xo[2] - 2*np.pi):
                    #print("QUATERNION SHIFT-> REAJUST!")
                    xk[2] -= 2*np.pi
                elif abs(xk[2] - xo[2] ) > abs(xk[2] - xo[2] + 2*np.pi):
                    #print("QUATERNION SHIFT-> REAJUST")
                    xk[2] += 2*np.pi
                
                # Publish out closest path chunk
                pub_np_path_2_rviz(path_chunk_no_flat, path_rl_pub)

                # Create conditional for when the norm of x,y,theta deviates from x,y,theta (path), use LQR to regain control
                phi_app = 0
                v_app = 0
                q_vec = np.concatenate((goal_state[0:2], xk, path_chunk, lidar_ranges)).reshape((1,95,1))
                q_control = model.predict(q_vec)
                best_act = np.argmax(q_control)
                v_app, phi_app = swap_nat_get_control_label(best_act)
                if v_app < .05:
                    v_app = .05
                    print("Q-Net Actions: ", v_app, phi_app)
                # log states, controls, action decision
                t_stats.add_state_control(xk.reshape(-1), np.array([v_app,phi_app]), is_q_lqr=True)
                
                # Send Ackerman control off to ros
                ack_msg = AckermannDriveStamped()
                ack_msg.header.frame_id = "base_link"
                ack_msg.header.stamp = rospy.Time.now()
                ack_msg.drive.speed = v_app #uo[0] #u_app[0]
                ack_msg.drive.steering_angle = phi_app #uo[1] #u_app[1]
                cmd_pub.publish(ack_msg)
                # Sleep for duration -- Enter Obstacle avoidance pipeline
                t2 = rospy.get_time()
                if not time_xk + (t2 - t1) > DT:
                    rospy.sleep(DT - (t2 - t1) - time_xk)
                    print("Slept For Time: ", DT - (t2 - t1) - time_xk)
                # Get new current position
                xk, time_xk = get_current_pose(listener, DT)
                cl_indx, path_error = find_closest_nominal_pose(xk.reshape(-1), x_os[:,0:2])
                path_chunk = get_lookahead_window(15, cl_indx, x_os[:,0:2])
                path_chunk_no_flat = get_lookahead_window_no_flat(15, cl_indx, x_os[:,0:2])
                xo = x_os[cl_indx]
            counter += 1
            t_stats.set_trajectory_stats()
            # Make sure driving system is off at end of trajectory
            print("Finished Path Segment ", counter, " / ", len(paths_data))
            if with_pause_between_trajectories:
                ack_msg = AckermannDriveStamped()
                ack_msg.header.frame_id = "base_link"
                ack_msg.header.stamp = rospy.Time.now()
                ack_msg.drive.speed = 0
                ack_msg.drive.steering_angle = 0
                cmd_pub.publish(ack_msg)
                rospy.sleep(DT)
        ack_msg = AckermannDriveStamped()
        ack_msg.header.frame_id = "base_link"
        ack_msg.header.stamp = rospy.Time.now()
        ack_msg.drive.speed = 0
        ack_msg.drive.steering_angle = 0
        cmd_pub.publish(ack_msg)
        t_stats.save_data(drive_stats_path)
    except Exception:
        ack_msg = AckermannDriveStamped()
        ack_msg.header.frame_id = "base_link"
        ack_msg.header.stamp = rospy.Time.now()
        ack_msg.drive.speed = 0
        ack_msg.drive.steering_angle = 0
        cmd_pub.publish(ack_msg)
        t_stats.traj_packets.append(t_stats.total_num_paths)
        t_stats.save_data(drive_stats_path)
        print("Saved Data to file!")

def pure_lqr_drive(path_file_name = "self_drive_3_37"):
    rospy.sleep(4)
    HZ = 15
    dur = rospy.Rate(HZ)
    cmd_pub = rospy.Publisher("/ackermann_cmd", AckermannDriveStamped, queue_size = 2)
    path_pub = rospy.Publisher("/tugboat/path/plan", Path, queue_size = 1)
    listener = tf.TransformListener()

    trajectories_dir = "/home/natsubuntu/catkin_ws/src/nesl_bot/Data/warehouse_trajectories/self_drive_no_obstacles/"
    trajectories_file = path_file_name
    paths_file = open(trajectories_dir + trajectories_file, 'rb')
    paths_data = pickle.load(paths_file) #, encoding='iso-8859-1')
    
    # logger 
    drive_stats_path = "/home/natsubuntu/catkin_ws/src/nesl_bot/scripts/self_driving/ackbot_drl/drive_stats/drive_stats1_pure_lqr_" + trajectories_file
    t_stats = TrajectoryStats(len(paths_data), is_q_lqr_compare=False)
    # Create Mega Path and Publish out for visualization
    mega_path = np.vstack( [path[2][:,0:3] for path in paths_data] )
    ros_mega_path = numpy_xyt_array_to_ros_path(mega_path)
    # Make sure the global path actually shows up
    for _ in range(5):
        path_pub.publish(ros_mega_path)
        dur.sleep()
    print("Published Full Path!")
    with_pause_between_trajectories = False
    try:
        # Run Self Driving Loop
        rospy.sleep(1)
        print("Start Self Drive!")
        MAX_SPEED = 1.25 
        MAX_ANGLE = np.pi / 5.9
        #HZ = 15
        DT = 1.0 / HZ
        counter = 0
        for traj_data in paths_data:
            # Unpack start, goal, path, gains, time start / end
            #start_state = traj_data[0]
            #goal_state = traj_data[1]
            path_to_follow = traj_data[2]
            Ks = traj_data[3]
            #times = traj_data[4]
            x_os = path_to_follow[:,0:3]
            u_os = path_to_follow[:,3:5]
            times = traj_data[4]
            print("Path Start / End Times: ", times)
            # Track Path via LQR
            for xo, uo, K in zip(x_os, u_os, Ks):
                t1 = rospy.get_time()
                # Get current position
                xk, time_xk = get_current_pose(listener, DT)
                # Solve control
                if abs(xk[2] - xo[2]) > abs(xk[2] - xo[2] - 2*np.pi):
                    #print("QUATERNION SHIFT-> REAJUST!")
                    xk[2] -= 2*np.pi
                elif abs(xk[2] - xo[2] ) > abs(xk[2] - xo[2] + 2*np.pi):
                    #print("QUATERNION SHIFT-> REAJUST")
                    xk[2] += 2*np.pi
                ek = xk - xo
                #print("State Error is: ", ek)
                u_ek = np.matmul(K, ek)
                u_app = u_ek + uo
                if u_app[0] > MAX_SPEED + .0825:
                    u_app[0] = MAX_SPEED
                    #print("Clipped u_app speed!")
                if u_app[1] < -MAX_ANGLE:
                    u_app[1] = -MAX_ANGLE
                    #print("Clipped u_app! angle")
                elif u_app[1] > MAX_ANGLE:
                    u_app[1] = MAX_ANGLE
                    #print("Clipped u_app! angle")
                # Send Ackerman control off to ros
                ack_msg = AckermannDriveStamped()
                ack_msg.header.frame_id = "base_link"
                ack_msg.header.stamp = rospy.Time.now()
                ack_msg.drive.speed = u_app[0] #uo[0] #u_app[0]
                ack_msg.drive.steering_angle = u_app[1] #uo[1] #u_app[1]
                cmd_pub.publish(ack_msg)
                t_stats.add_state_control(xk.reshape(-1), u_app.reshape(-1))
                # Sleep for duration -- Enter Obstacle avoidance pipeline
                #print("Published Control: ", u_app)
                t2 = rospy.get_time()
                if not time_xk + (t2 - t1) > DT:
                    rospy.sleep(DT - (t2 - t1) - time_xk)
                    print("Slept For Time: ", DT - (t2 - t1) - time_xk)
            counter += 1
            t_stats.set_trajectory_stats()
            # Make sure driving system is off at end of trajectory
            print("Finished Path Segment ", counter, " / ", len(paths_data))
            if with_pause_between_trajectories:
                ack_msg = AckermannDriveStamped()
                ack_msg.header.frame_id = "base_link"
                ack_msg.header.stamp = rospy.Time.now()
                ack_msg.drive.speed = 0
                ack_msg.drive.steering_angle = 0
                cmd_pub.publish(ack_msg)
                rospy.sleep(DT)

        ack_msg = AckermannDriveStamped()
        ack_msg.header.frame_id = "base_link"
        ack_msg.header.stamp = rospy.Time.now()
        ack_msg.drive.speed = 0
        ack_msg.drive.steering_angle = 0
        cmd_pub.publish(ack_msg)
        t_stats.save_data(drive_stats_path)
        print("Saved Drive Stats to file!")
    except Exception:
        ack_msg = AckermannDriveStamped()
        ack_msg.header.frame_id = "base_link"
        ack_msg.header.stamp = rospy.Time.now()
        ack_msg.drive.speed = 0
        ack_msg.drive.steering_angle = 0
        cmd_pub.publish(ack_msg)
        t_stats.traj_packets.append(t_stats.total_num_paths)
        t_stats.save_data(drive_stats_path)
        print("Saved Drive Stats to file!")

def load_path_to_rviz(path_pub, path_file, attempts = 6):
    #trajectories_dir = "/home/natsubuntu/catkin_ws/src/nesl_bot/Data/warehouse_trajectories/self_drive_obstacles"
    #trajectories_file = path_file_name
    paths_file = open(path_file, 'rb')
    paths_data = pickle.load(paths_file) #, encoding='iso-8859-1')
    paths_file.close()

    # Create Mega Path and Publish out for visualization
    HZ = 15
    dur = rospy.Rate(HZ)
    mega_path = np.vstack( [path[2][:,0:3] for path in paths_data] )
    goal_points = [ path[2][-1,0:2] for path in paths_data]
    goal_lines = [ get_normal_line( path[2][-2,0], path[2][-2,1], 
                                    path[2][-1,0], path[2][-1,1] ) for path in paths_data ]
    start_signs = [get_sign_of_point_wrt_line(Ab[0],Ab[1], path[2][-2,0:2]) for Ab, path in zip(goal_lines, paths_data)]
    ros_mega_path = numpy_xyt_array_to_ros_path(mega_path)
    # Make sure the global path actually shows up
    for _ in range(attempts):
        path_pub.publish(ros_mega_path)
        dur.sleep()
    print("Published Full Path!")
    return goal_points, goal_lines, start_signs, paths_data

def publish_goal_point_markers(marker_pub, goal_points, attempts = 3):
    marker = Marker()
    obj_markers = MarkerArray()
    marker_count = 0
    for goal_point in goal_points:
        # Create Goal Point marker
        marker = Marker()
        marker.header.frame_id = '/map'
        marker.header.stamp = rospy.Time.now()
        marker.type = marker.CYLINDER
        marker.id = marker_count + 1
        marker.action = marker.ADD
        marker.scale.x = 0.2 
        marker.scale.y = 0.2 
        marker.scale.z = 0.2 
        marker.color.a = 1.0 
        marker.color.r = 0.0 
        marker.color.g = 1.0 
        marker.color.b = 0.0 
        marker.pose.orientation.w = 1.0 
        marker.pose.position.x = goal_point[0] 
        marker.pose.position.y = goal_point[1]
        marker.pose.position.z = 0.10
        obj_markers.markers.append(marker)
        marker_count += 1

    # may need effort attempts here
    #dur = rospy.Rate(15)
    for _ in range(attempts):
        marker_pub.publish(obj_markers)
        rospy.sleep(.002)
        #dur.sleep()
    print("Published Goal Point Markers")


def test_q_drive_with_joy(load_driving_path = "self_drive_3_37"):
    rospy.sleep(4)
    HZ = 15
    DT = 1.0 / HZ
    dur = rospy.Rate(HZ)
    joy_sub = rospy.Subscriber("/joy", Joy, joy_callback, queue_size = 2)
    cmd_pub = rospy.Publisher("/ackermann_cmd", AckermannDriveStamped, queue_size = 2)
    path_pub = rospy.Publisher("/tugboat/path/plan", Path, queue_size = 1)
    marker_array_pub = rospy.Publisher("/tugboat/goal_point/markers", MarkerArray, queue_size=10)
    listener = tf.TransformListener()
    obstacle_dir = "/home/natsubuntu/catkin_ws/src/nesl_bot/Data/warehouse_trajectories/self_drive_obstacles/"
    self_drive_path_dir = "/home/natsubuntu/catkin_ws/src/nesl_bot/Data/warehouse_trajectories/self_drive_no_obstacles/"
    self_drive_path_dir += load_driving_path
    # Load Path loop to rviz for vizualization
    goal_points, goal_lines, start_signs, paths_data = load_path_to_rviz(path_pub, path_file = self_drive_path_dir)
    # Use Markers to indicate goal points
    #publish_goal_point_markers(marker_array_pub, goal_points)
    # Goal lines
    # After publishing out nominal path, now need to do the following
    # 1) load virtual object manager that goes with path seperately, assume objects static for now
    # 2) attempt each end point, when dist to next path is closer than current path, end 'path', start new goal
    # 3) log joy, state; retroactively (with dist check), create path, time to go, 
    MODEL_FILEPATH = "/home/natsubuntu/catkin_ws/src/nesl_bot/scripts/self_driving/ackbot_drl/models/cnn/model_307.h5"
    MODEL_TYPE = "cnn"

    # Initialize the RL model
    dev_boi = Delivery_boi(state_vector_shape, action_vector_shape, MODEL_TYPE)

    # Load the model
    dev_boi.model.load_weights(MODEL_FILEPATH)
    print("Model Loaded!")

    #lock = Lock()
    # Wait for user to press the 'a' button to begin collecting data
    print("Waiting for Drive!")
    while not start_log:
        dur.sleep()

    global controls, pause_between_traj, delete_path_interval
    print("Start Self Drive!")
    #new_paths_data = []
    for i in range(len(goal_points)):
        # Publish out next three goal positions
        if i + 3 >= len(goal_points):
            publish_goal_point_markers(marker_array_pub, goal_points[i:])
        else:
            publish_goal_point_markers(marker_array_pub, goal_points[i:i+3])
        
        # Check to see if the user has requested to pause between this and the next trajectory
        if pause_between_traj:
            print("Pausing!")
        while pause_between_traj:
            dur.sleep()
        # While we havent crossed the goal point's finish line, continue driving and logging
        print("Start New Path ", i + 1)
        tic = rospy.get_time()
        #path_packet = []
        l2_norm_min = 0.90
        x, tl = get_current_pose(listener, DT)
        #path_packet.append(x)
        goal_state = paths_data[i][1]
        path_to_follow = paths_data[i][2]
        #path = []
        #joy_controls = []
        #states = []
        while  not ( (np.linalg.norm(goal_points[i] - x[0:2]) < l2_norm_min) and (get_sign_of_point_wrt_line(goal_lines[i][0], goal_lines[i][1], x[0:2]) != start_signs[i]) ):
            #print("Condition Not Met")
            #print( "Sign: ", get_sign_of_point_wrt_line(goal_lines[i][0], goal_lines[i][1], x[0:2]) )
            #print("L2: ", np.linalg.norm(goal_points[i] - x[0:2]) )
            # publish joy action
            inner_tic = rospy.get_time()
            ack_msg = AckermannDriveStamped()
            ack_msg.header.frame_id = "base_link"
            ack_msg.header.stamp = rospy.Time.now()
            #lock.acquire()
            # Need to lock controls temporarily
            ctrl = copy.deepcopy(controls)
            # get state, goal point, look ahead path, lidar pruned
            cl_indx,_ = find_closest_nominal_pose(x, path_to_follow)
            path_chunk = get_lookahead_window(15, cl_indx, path_to_follow)
            q_vec = np.concatenate((goal_state[0:2], x, path_chunk, lidar_ranges)).reshape((1,95,1))
            q_control = dev_boi.model.predict(q_vec)
            best_act = np.argmax(q_control.flatten(0))
            v_app, phi_app = get_controls_from_q(best_act)
            print("Q-Net Controls: ", v_app, phi_app)
            #lock.release()
            ack_msg.drive.speed = ctrl[0] #uo[0] #u_app[0]
            ack_msg.drive.steering_angle = ctrl[1] #uo[1] #u_app[1]
            cmd_pub.publish(ack_msg)
            #states.append(x)
            #path.append(np.concatenate((x,ctrl)))
            #joy_controls.append(ctrl)
            inner_toc = rospy.get_time()
            # sleep for DT - loop time taken
            if DT - tl - (inner_toc - inner_tic) > 0:
                rospy.sleep(DT - tl - (inner_toc - inner_tic))
            # Get new state after applying control action
            xl = copy.deepcopy(x)
            x, tl = get_current_pose(listener, DT)
            # assert theta is between -pi and pi
            if abs(x[2] - xl[2]) > abs(x[2] - xl[2] - 2*np.pi):
                #print("QUATERNION SHIFT-> REAJUST!")
                x[2] -= 2*np.pi
            elif abs(x[2] - xl[2] ) > abs(x[2] - xl[2] + 2*np.pi):
                #print("QUATERNION SHIFT-> REAJUST")
                x[2] += 2*np.pi
            
            
        # Once we are done logging the data, create path
        print("CONDITION_MET")
        print("Goal State is: ", goal_points[i], "We hit: ", x)
        #print("Goal Normal is: ", goal_lines[i])
        toc = rospy.get_time()
        #np_path = np.array(path)
        #path_packet.append(paths_data[i][2])
        #path_packet.append(None) # control gains
        #path_packet.append([tic, toc])
        #path_packet.append(np.array(joy_controls))
        #path_packet.append(np.array(states))
        #if delete_path_interval:
        #    delete_path_interval = False
        #    print("Not including bad path segment ", i + 1)
        #else:
        #    new_paths_data.append(path_packet)
        #    print("End Path ", i + 1)
        #print("Shape of Path is: ", np_path.shape)
        #print("Shape of State is: ", np.array(states).shape)
        #print("Shape of Controls is: ", np.array(joy_controls).shape)

    # Bring car to a hault
    ack_msg = AckermannDriveStamped()
    ack_msg.header.frame_id = "base_link"
    ack_msg.header.stamp = rospy.Time.now()
    ack_msg.drive.speed = 0
    ack_msg.drive.steering_angle = 0
    cmd_pub.publish(ack_msg)

    # Once done full loop, log new_paths_data
    #pieces = load_driving_path.split("_")
    #now = datetime.datetime.now()
    #file_name = "obstacle_drive_" + pieces[2] + "_" + pieces[3] + "_logged_" + str(now.hour) + "_" + str(now.minute)
    #trajectories_file = open(obstacle_dir + file_name,'wb')
    #pickle.dump(new_paths_data, trajectories_file)
    #print("Saved Immitation Learning Data!")


if __name__ == "__main__":
    rospy.init_node("path_drive")
    rospy.sleep(1)
    self_drive_path = rospy.get_param("/self_drive_path_file")
    laser_sub = rospy.Subscriber("/scan", LaserScan, laser_callback,queue_size=2)
    print("Testing Self Drive!")
    hybrid_q_self_drive(path_file_name=self_drive_path)
    #pure_q_self_drive(path_file_name=self_drive_path)
    #pure_lqr_drive(path_file_name=self_drive_path)
    #test_q_drive_with_joy(load_driving_path=self_drive_path)
