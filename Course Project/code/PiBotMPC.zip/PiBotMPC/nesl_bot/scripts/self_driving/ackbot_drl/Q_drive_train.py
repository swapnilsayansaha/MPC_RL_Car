#!/usr/bin/env python3
import numpy as np
#import rospy
import pickle
import sys, os 
#from nav_msgs.msg import Path
#from geometry_msgs.msg import PoseStamped
import copy
from sensor_msgs.msg import LaserScan
from data_extractor import get_most_significant_lidar_points, get_rosbag_data
from data_generator import get_all_possible_paths, get_np_data_from_file, get_lookahead_window, get_controls_from_q, find_closest_nominal_pose
#from model import Delivery_boi
import numpy as np
import random
import keras
#from sensor_msgs.msg import Joy
from keras.utils import to_categorical
from keras.models import Sequential, Model
from keras.callbacks import ModelCheckpoint
from keras.layers import Dense, Activation, Flatten, BatchNormalization, Conv1D, MaxPool1D, LSTM, Input, Concatenate, Lambda, Dropout
from keras.optimizers import Adam, RMSprop
from keras.initializers import RandomUniform
from keras.models import load_model
from tensorboard import ModifiedTensorBoard


state_vector_shape = (95,1)
action_vector_shape = 146



def pickle_2_train_data(pickle_path, lidar_path):
    fp = open(pickle_path, 'rb')
    path_data = pickle.load(fp, encoding='iso-8859-1')
    lidar_hist = get_rosbag_data(lidar_path)
    lidar_hist_times = lidar_hist[:,0]
    #lidar_paths = []
    q_vectors_whole_path = []
    control_list = []
    for path in path_data:
        # get state vec
        # get goal point 
        # get labels 
        # get look ahead path 
        # get pruned lidar vector 
        goal_point = path[1]
        controls = path[5] # check
        control_list.append(controls)
        nom_path = path[2][:,0:2]
        state_hist = path[6]
        run_tic = path[4][0] # start time, end time
        DT = 1.0 / 15.0 
        #lidar_path = []
        #q_vector_path_seg = []
        for sh in state_hist:
            # get look ahead path 
            cl_indx, _ = find_closest_nominal_pose(sh.reshape(-1), nom_path)
            path_chunk = get_lookahead_window(15, cl_indx, nom_path)
            # match lidar to sh
            arg_lid = np.argmin(np.abs(lidar_hist_times - run_tic))
            lid_chunk = lidar_hist[arg_lid]
            q_vec = np.concatenate((goal_point[0:2], sh, path_chunk, lid_chunk[1:]))
            q_vec = q_vec.astype(np.float64)
            #q_vector_path_seg.append(q_vec)
            run_tic += DT
            q_vectors_whole_path.append(q_vec)
        

    return np.array(q_vectors_whole_path, dtype = np.float64), np.vstack(control_list)


def get_paths_labels_no_obstacles():
    pickle_path = "/home/natsubuntu/catkin_ws/src/nesl_bot/Data/warehouse_trajectories/self_drive_no_obstacles/"
    lidar_path = "/home/natsubuntu/catkin_ws/src/nesl_bot/Data/warehouse_trajectories/self_drive_no_obstacles/"
    
    drive_files = ["self_drive_0_26", "self_drive_1_41", "self_drive_14_55",
                   "self_drive_1_7", "self_drive_21_26", "self_drive_2_39",
                   "self_drive_2_59", "self_drive_3_37"]
    drive_file_lidars = ["self_drive_0_26_lidar.bag", "self_drive_1_41_lidar.bag", "self_drive_14_55_lidar.bag",
                   "self_drive_1_7_lidar.bag", "self_drive_21_26_lidar.bag", "self_drive_2_39_lidar.bag",
                   "self_drive_2_59_lidar.bag", "self_drive_3_37_lidar.bag"]
    
    #drive_file = "self_drive_0_26"
    #drive_file_lidar = "self_drive_0_26_lidar.bag"
    q_states = []
    q_controls = []
    for drive_file, dive_file_lidar in zip(drive_files, drive_file_lidars):
        state_arr, control_arr = pickle_2_train_data(pickle_path + drive_file, lidar_path + dive_file_lidar)
        q_controls.append(control_arr)
        q_states.append(state_arr)
    q_states = np.vstack(q_states)
    q_controls = np.vstack(q_controls)
    # quantize controls and assign action value
    phi_bins = np.linspace(start = -np.pi / 6, stop = np.pi / 6, num = 21 )
    vel_bins = np.array([-0.25, 0.0, 0.25, 0.50, 0.75, 1.0, 1.25])
    q_controls_new = []
    for qc in q_controls:
        v = qc[0]
        p = qc[1]
        v_con = vel_bins[np.argmin(np.abs(v - vel_bins))]
        p_con = phi_bins[np.argmin(np.abs(p - phi_bins))]
        q_controls_new.append(np.array([v_con, p_con]))
    q_controls_new = np.array(q_controls_new)
    control_indxs = np.array([[v,p] for p in phi_bins for v in vel_bins ])
    control_labels = []
    for qcn in q_controls_new:
        ctrl_amin = np.argmin( np.linalg.norm(np.abs(qcn.reshape((1,2)) - control_indxs ), axis = 1) )
        control_labels.append(ctrl_amin)
    control_labels = np.array(control_labels)
    train_labels = to_categorical(control_labels)
    print("Q STATE AND TRAIN LABELS")
    print(q_states.shape, train_labels.shape)
    return q_states, train_labels


    # For each file, get 1 second chunks from the table

def get_paths_labels_obstacles():
    pickle_path1 = "/home/natsubuntu/catkin_ws/src/nesl_bot/Data/warehouse_trajectories/self_drive_obstacles/imitation_data/golden_imit_data/"
    lidar_path1 = "/home/natsubuntu/catkin_ws/src/nesl_bot/Data/warehouse_trajectories/self_drive_obstacles/imitation_data/golden_imit_data/"

    pickle_path2 = "/home/natsubuntu/catkin_ws/src/nesl_bot/Data/warehouse_trajectories/self_drive_obstacles/imitation_data/good_imit_data/"
    lidar_path2 = "/home/natsubuntu/catkin_ws/src/nesl_bot/Data/warehouse_trajectories/self_drive_obstacles/imitation_data/good_imit_data/"
    
    # golden data files
    drive_files1 = ["obstacle_drive_0_26_logged_16_29", "obstacle_drive_0_26_logged_16_43", "obstacle_drive_0_26_logged_16_50",
                   "obstacle_drive_1_41_logged_17_15", "obstacle_drive_1_41_logged_17_24", "obstacle_drive_1_41_logged_17_28",
                   "obstacle_drive_14_55_logged_17_48", "obstacle_drive_14_55_logged_17_50", "obstacle_drive_2_39_logged_12_15",
                   "obstacle_drive_2_39_logged_12_22", "obstacle_drive_2_39_logged_12_29", "obstacle_drive_2_59_logged_12_55",
                   "obstacle_drive_2_59_logged_13_3","obstacle_drive_2_59_logged_13_8","obstacle_drive_3_37_logged_15_20",
                   "obstacle_drive_3_37_logged_15_28","obstacle_drive_3_37_logged_15_34", "obstacle_drive_3_37_logged_15_44",
                   "obstacle_drive_3_37_logged_16_20"]
    
    drive_file_lidars1 = ["obstacle_drive_0_26_logged_16_29_lidar.bag", "obstacle_drive_0_26_logged_16_43_lidar.bag", "obstacle_drive_0_26_logged_16_50_lidar.bag",
                   "obstacle_drive_1_41_logged_17_15_lidar.bag", "obstacle_drive_1_41_logged_17_24_lidar.bag", "obstacle_drive_1_41_logged_17_28_lidar.bag",
                   "obstacle_drive_14_55_logged_17_48_lidar.bag", "obstacle_drive_14_55_logged_17_50_lidar.bag", "obstacle_drive_2_39_logged_12_15_lidar.bag",
                   "obstacle_drive_2_39_logged_12_22_lidar.bag", "obstacle_drive_2_39_logged_12_29_lidar.bag", "obstacle_drive_2_59_logged_12_55_lidar.bag",
                   "obstacle_drive_2_59_logged_13_3_lidar.bag","obstacle_drive_2_59_logged_13_8_lidar.bag","obstacle_drive_3_37_logged_15_20_lidar.bag",
                   "obstacle_drive_3_37_logged_15_28_lidar.bag","obstacle_drive_3_37_logged_15_34_lidar.bag", "obstacle_drive_3_37_logged_15_44_lidar.bag",
                   "obstacle_drive_3_37_logged_16_20_lidar.bag"]
    # good data files

    """ drive_files2 = ["obstacle_drive_0_26_logged_16_33", "obstacle_drive_0_26_logged_16_46", "obstacle_drive_1_41_logged_17_6",
                   "obstacle_drive_14_55_logged_17_51", "obstacle_drive_14_55_logged_2_39", "obstacle_drive_14_55_logged_2_45",
                   "obstacle_drive_1_7_logged_3_51", "obstacle_drive_1_7_logged_3_58", 
                   "obstacle_drive_21_26_logged_12_0", "obstacle_drive_3_37_logged_16_6"]

    drive_file_lidars2 = ["obstacle_drive_0_26_logged_16_33_lidar.bag", "obstacle_drive_0_26_logged_16_46_lidar.bag", "obstacle_drive_1_41_logged_17_6_lidar.bag",
                   "obstacle_drive_14_55_logged_17_51_lidar.bag", "obstacle_drive_14_55_logged_2_39_lidar.bag", "obstacle_drive_14_55_logged_2_45_lidar.bag",
                   "obstacle_drive_1_7_logged_3_51_lidar.bag", "obstacle_drive_1_7_logged_3_58_lidar.bag", 
                   "obstacle_drive_21_26_logged_12_0_lidar.bag", "obstacle_drive_3_37_logged_16_6_lidar.bag"]
    """
    # Adding Golden Data
    q_states = []
    q_controls = []
    for drive_file, drive_file_lidar in zip(drive_files1, drive_file_lidars1):
        state_arr, control_arr = pickle_2_train_data(pickle_path1 + drive_file, lidar_path1 + drive_file_lidar)
        print(state_arr.shape, control_arr.shape)
        q_controls.append(control_arr)
        q_states.append(state_arr)
    
    # Adding Good Data
    #for drive_file, drive_file_lidar in zip(drive_files2, drive_file_lidars2):
    #    state_arr, control_arr = pickle_2_train_data(pickle_path2 + drive_file, lidar_path2 + drive_file_lidar)
    #    print(state_arr.shape, control_arr.shape)
    #    q_controls.append(control_arr)
    #    q_states.append(state_arr)

    # Stacking Golden with Good
    q_states = np.vstack(q_states)
    q_controls = np.vstack(q_controls)
    print("Q SHAPES AND CONTROLS")
    print(q_states.shape, q_controls.shape)
    # quantize controls and assign action value
    phi_bins = np.linspace(start = -np.pi / 6, stop = np.pi / 6, num = 21 )
    vel_bins = np.array([-0.25, 0.0, 0.25, 0.50, 0.75, 1.0, 1.25])
    q_controls_new = []
    for qc in q_controls:
        v = qc[0]
        p = qc[1]
        v_con = vel_bins[np.argmin(np.abs(v - vel_bins))]
        p_con = phi_bins[np.argmin(np.abs(p - phi_bins))]
        q_controls_new.append(np.array([v_con, p_con]))
    
    q_controls_new = np.array(q_controls_new)
    control_indxs = np.array([[v,p] for p in phi_bins for v in vel_bins ])
    control_labels = []
    for qcn in q_controls_new:
        ctrl_amin = np.argmin( np.linalg.norm(np.abs(qcn.reshape((1,2)) - control_indxs ), axis = 1) )
        control_labels.append(ctrl_amin)
    control_labels = np.array(control_labels)
    train_labels = to_categorical(control_labels) 
    print("Q STATE AND TRAIN LABELS")
    print(q_states.shape, train_labels.shape)
    return q_states, train_labels


    # For each file, get 1 second chunks from the table


# Model for a network with purely just cnn layers
def pure_cnn(state_size, num_actions):

    model = Sequential()

    model.add(Conv1D(128, 3, activation='relu', input_shape=state_size))
    #model.add(Conv1D(128, 3, activation='relu', input_shape=state_size))
    #model.add(MaxPool1D(pool_size=2))
    model.add(BatchNormalization())
    model.add(Dropout(0.25))

    model.add(Conv1D(128, 3, activation='relu', input_shape=state_size))
    #model.add(Conv1D(128, 3, activation='relu', input_shape=state_size))
    #model.add(MaxPool1D(pool_size=2))
    model.add(BatchNormalization())
    #model.add(MaxPool1D(pool_size=2))
    model.add(Dropout(0.25))

    model.add(Conv1D(128, 3, activation='relu', input_shape=state_size))
    #model.add(Conv1D(128, 3, activation='relu', input_shape=state_size))
    #model.add(MaxPool1D(pool_size=2))
    model.add(BatchNormalization())
    #model.add(MaxPool1D(pool_size=2))
    model.add(Dropout(0.25))
    #model.add(Conv1D(128, 3, activation='relu', input_shape=state_size))
    #model.add(MaxPool1D(pool_size=2))

    #model.add(Conv1D(256, 3, activation='relu'))
    #model.add(MaxPool1D(pool_size=2))
    #model.add(BatchNormalization())
    #model.add(Dropout(0.25))

    #model.add(Conv1D(256, 3, activation='relu'))
    #model.add(MaxPool1D(pool_size=4))
    #model.add(BatchNormalization())
    #model.add(Dropout(0.25))

    model.add(Flatten())

    #model.add(Dense(1024, activation='relu'))
    #model.add(Dense(256, activation='relu'))

    #model.add(Dense(num_actions, activation='relu'))
    #model.add(BatchNormalization())
    #model.add(Dropout(0.25))
    model.add(Dense(num_actions, activation='softmax'))
    
    return model

def cnn_lstm(state_size, num_actions):
	
	# Set up model weight initializers
	#init = RandomUniform(minval=0.,maxval=0.5)

	model = Sequential()

	model.add(Conv1D(128, 3, activation='relu', input_shape=state_size))
	model.add(MaxPool1D(pool_size=2))
	model.add(BatchNormalization())

	model.add(Conv1D(64, 3, activation='relu'))
	model.add(MaxPool1D(pool_size=2))
	model.add(BatchNormalization())

	model.add(Conv1D(32, 3, activation='relu'))
	model.add(MaxPool1D(pool_size=2))
	model.add(BatchNormalization())

	# Add an lstm layer
	model.add(LSTM(256, batch_input_shape=(None, 137,32))) # Reduce the values to a 256 element vector

	model.add(Dense(num_actions, activation='linear')) # softmax could work too

	return model


def createModel(state_size, num_actions):
    model = pure_cnn(state_size, num_actions)
    #model = cnn_lstm(state_size, num_actions)
    model.compile(loss=keras.losses.categorical_crossentropy, optimizer='adam', metrics=['accuracy'])     
    #model.compile(loss="mse", optimizer=RMSprop(lr=0.000001, clipnorm=1.0), metrics=['mse'])
    return model

def train(X,Y, model):	
    # Get minibatch of data
    #self.model.fit(np.array(X), np.array(y), batch_size=self.MINIBATCH_SIZE, verbose=0, shuffle=False)
    #tensorboard = ModifiedTensorBoard(log_dir="logs/{}".format("Swap_Nat_RL"))
    filepath="models/cnn/foo.hdf5"
    checkpoint = ModelCheckpoint(filepath, monitor='acc', verbose=1, save_best_only=True, mode='max')
    callbacks_list = [checkpoint]
    model.fit(X, Y, batch_size= 64, verbose=1, 
        shuffle=False, epochs = 300, callbacks= callbacks_list )
    return model
    


def train_network_no_obstacles():
    X, Y = get_paths_labels_no_obstacles()
    model = createModel((95,1), action_vector_shape)
    model.summary()
    X = X.reshape((X.shape[0], X.shape[1],1))
    model = train(X,Y, model)

def train_network_obstacles():
    X, Y = get_paths_labels_obstacles()
    model = createModel((95,1), action_vector_shape)
    model.summary()
    X = X.reshape((X.shape[0], X.shape[1],1))
    model = train(X,Y, model)
    







if __name__ == "__main__":
    #train_network_no_obstacles()
    train_network_obstacles()
