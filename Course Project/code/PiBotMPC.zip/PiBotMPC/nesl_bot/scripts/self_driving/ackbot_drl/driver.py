import numpy as np
import random

from model import Delivery_boi
from data_generator import get_all_possible_paths, get_transition_list, get_np_data_from_file
#from model_optimizer import create_pruned_model


# IMPORTANT VARIABLES *****
TOTAL_EPISODES = 30
TOTAL_PRUNE_EPISODES = 1
STEP_LIMIT = 500  # Allowed to perform this many steps before we stop an episode

TITLES_NO_OBSTACLES = ["no_obstacles"]  # For no obstacles
TITLES_WITH_OBSTACLES = ["golden_imit", "good_imit", "okay_imit"] # for obstacles

# New state vector shape, determined by 2 (goal pose) + 3 ( current pose) + (15*2) future windows + 60 lidar
state_vector_shape = (95, 1)

action_vector_shape = 140 # Determined by data_generator/discretize_lqr

# Possible models - "cnn", "cnn-lstm", "hybrid"
#MODEL_TYPES = ["cnn", "cnn-lstm", "hybrid"]
MODEL_TYPES = ["cnn"]
DATA_TYPES = [TITLES_NO_OBSTACLES, TITLES_WITH_OBSTACLES]
#DATA_TYPES = [TITLES_WITH_OBSTACLES]

# Check if the current episode is within the step limit
def under_step_limit(step_count):

	under_step_limit = True

	if step_count > STEP_LIMIT:
		under_step_limit = False

	return under_step_limit 



# Training function
def train_models(dev_boi, episodes, training_paths, training_type, update_tb=True):

	# Train the model 
	for episode in range(0, episodes):

		done = False
		step_count = 0

		print("EPISODE : " + str(episode))

		while not done and under_step_limit(step_count):
			
			# Pick a random file
			random_file = np.random.choice(training_paths, 1)
			full_np_data = get_np_data_from_file(random_file[0])
			# Get a random index from the paths
			random_state_index = random.randint(0, full_np_data[0].shape[0]-1) 

			# Get the transition data from random index in random file
			transition_list = get_transition_list(random_state_index, full_np_data)

			# Add the random transition into the replay memory
			# Then train the agent (if there are enough items in memory)
			dev_boi.update_replay_memory(transition_list)
			dev_boi.train()
			
			step_count += 1
			

		# Save the model every episode
		model_save_path = dev_boi.save_models(training_type)

		average_q_mae = dev_boi.get_average_q_mae()
		print("COMPLETE EPISODE " + str(episode))
		
		if average_q_mae == -1:
			print("No training has occurred - only appended to replay memory")
		else:
			print("EPISODE Q MAE: " + str(average_q_mae))
		
			if update_tb:
				# Every time we finish an episode, we step forward in the tensoboard
				dev_boi.tensorboard.step = episode
				dev_boi.tensorboard.update_stats(average_q_mae=average_q_mae)
		
		


# Iterate through each type of data (i.e. obstacle/no-obstacle) and type of model (cnn, hybrid, etc)
for data_type in DATA_TYPES:

	for MODEL_TYPE in MODEL_TYPES:
	
		print(" **** BEGIN **** ")
		print("Using data: " + str(data_type) )

		# First thing is to find all the training data.
		#  Remember, get_all_possible_paths returns a bunch of filepaths
		#  where each filepath is list of path poses, goal pose, lqr poses for a single path
		training_paths = get_all_possible_paths(data_type)

		# Initialize the RL model
		dev_boi = Delivery_boi(state_vector_shape, action_vector_shape, MODEL_TYPE)

		# Train the RL model
		train_models(dev_boi, TOTAL_EPISODES, training_paths, "model", update_tb=True)


		####### MODEL OPTIMIZATION AND TESTING ########

		# Initialize the pruned model - set the dev_boi model to this new pruned model
		#dev_boi.model = create_pruned_model(dev_boi.model, TOTAL_PRUNE_EPISODES)

		# Prune and retrain the completed model
		#train_models(dev_boi, TOTAL_PRUNE_EPISODES, training_paths, "pruned_model", update_tb=False)

		# Get the model path of the last saved model (which is the latest pruned model if that was made.)
		model_save_path = dev_boi.recent_save_path
				
		# Run prediction on the final model
		# Reloads a model, picks a random item to run prediction on, and checks the latency of it.
		# We reload the model because a compiled model during training performs slower than a non-compiled test model.
		dev_boi.test_prediction(dev_boi.model, model_save_path)

		# Log some output regarding the model itself
		print(dev_boi.MODEL_NAME)
		print(dev_boi.recent_save_path)
		print( " ***** END *****" )



