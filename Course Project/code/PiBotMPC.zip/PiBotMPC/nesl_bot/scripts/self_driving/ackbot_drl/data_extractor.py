import os
import pickle
import rosbag
import numpy as np
from std_msgs.msg import Int32, String


# Takes the num most significant lidar points
#  lidar_values is a 1d array consisting of all lidar values (i.e. 1080)
#  Significance is determined by the 
def get_most_significant_lidar_points(lidar_values, num=60):
    most_significant_lidar_points = []

    total_values = lidar_values.shape[0]
    increment = int(total_values/num)
    # Assuming there are 1081 lidar values, slide a window over 1081/60 points
    # and save only the most significant point out of that window.
    for i in range(0, total_values, increment):
        most_significant_lidar_points.append( np.amin(lidar_values[i:i+increment]) )

    # Return the most num significant lidar points
    mslp = np.array(most_significant_lidar_points)
    mslp[mslp > 30.01] = 30.0
    return mslp

# Gets data from the rosbag filepath, puts into an ndarray of values
#  The first column is the timestamps, rest is the lidar (1x1080)
def get_rosbag_data(filepath):

    bag = rosbag.Bag(filepath)
    rosbag_values = []

    # The ids of interest are:
    #  msg.header.stamp - gives you the timestamp of this lidar set
    #    there is also a secs and nsecs field.
    #  msg.ranges - gives you the lidar values for this timestamp
    for topic, msg, t in bag.read_messages():

        lidar_values = np.array(msg.ranges)
        lidar_values = get_most_significant_lidar_points(lidar_values)
        current_entry = np.insert(lidar_values, 0, msg.header.stamp.to_sec(), axis=0)
        rosbag_values.append(current_entry)

    bag.close()

    # Stack the arrays so we get a 2d array
    rosbag_values = np.vstack(rosbag_values)
    print(rosbag_values.shape)
    return rosbag_values





# Get the pickled object data
# Data is a list of paths, and each path is a list of tuples consisting of
#  x,y,theta, v, phi
def get_pickle_data(filepath):

    with open(filepath, 'rb') as pickled_data:
        # Load the pickle data - also, reading in python3 requires different encoding
        data = pickle.load(pickled_data, encoding='latin1')
        return data

# Get the path packet from the pickled data
#  Important info regarding packet structure:
#  It consists of 5 elements: start pose (1x5), goal pose (1x5),
#    robot path (some Z x 5), control gains (same Z x 5), and path times (1x2)
#     for start and end times
def get_pickle_path_packet(pickled_data, path_num):

    return pickled_data[path_num]

# Create num_states timestamps between time_start and time_end, inclusive
#  inclusive meaning it always includes the time_start/time_end as timestamps
#  Basically, creates a list of timestamps.
def interpolate_path_timestamps(time_start, time_end, num_states):
    interval = (time_end - time_start)/(num_states-1)
    timestamps = [i*interval+time_start for i in range(num_states)]
    return timestamps

# Given a path packet, get the start pose of the path
#  Sometimes the start pose is just 3 elements, we have to fill to 5
def get_start_pose_from_packet(path_packet):
    start_pose = np.zeros(5)
    start_pose[:path_packet[0].shape[0]] = path_packet[0][:]
    return start_pose

# Given a path packet, get the goal pose
def get_goal_pose_from_packet(path_packet):
    return path_packet[1]

# Given a path_packet, get the robot_paths (Z x 5)
#  Actually, this should be a Zx3 state history path
def get_paths_from_packet(path_packet):
    return path_packet[2]

# Given a path packet, get the time interval it occurs in (1x2)
def get_path_timestamps(path_packet):
    return path_packet[4][0], path_packet[4][1]

# Given a path packet, get the LQR controls
def get_lqr_controls(path_packet):
	return path_packet[5]

# Given a path packet, get the state history
def get_state_history(path_packet):
	#print("HELLO: " + str(path_packet[6].shape))
	return path_packet[6]

# Given a path_packet, we find attach all the necessary timestamps
#  We then return the start pose, path data and timestamps attached to them.
#  More specifically, we add a dimensions to the np array, along the variable axis.
def attach_timestamps_to_path_data(path_packet):

    # Get path data (start pose included)
    path_data = get_state_history(path_packet)
    #print(path_data.shape)
    #path_data = np.insert(path_data, 0, get_start_pose_from_packet(path_packet), axis=0)
    num_paths = len(path_data)

    # Get time interval
    ts_start, ts_end = get_path_timestamps(path_packet)
    timestamps = interpolate_path_timestamps(ts_start, ts_end, num_paths)

    # Insert the timestamps along the variable dimension of the path_data
    path_data = np.insert(path_data, 0, timestamps, axis=1)

    return path_data

# Takes the timestamps from the rosbag data, and creates an
#  np array of the same shape, with all values being the path timestamp.
#  We subtract these two np arrays, take the absolute value, and find
#  the minimum.  If the minimum difference is > time_boundary, we exit.
#  Otherwise, we return the corresponding value.
def find_closest_lidar_time(rosbag_data, rosbag_lidar_index, path_timestamp,
    time_boundary):

    # Get the timestamps
    rosbag_timestamps = rosbag_data[:,0]
    #Copy the same array shape and fill it with the path_timestamp
    path_timestamps = np.full(rosbag_timestamps.shape, path_timestamp)

    # Take the difference and absolute value
    difference_arr = np.absolute(rosbag_timestamps - path_timestamps)
    # Find the minimum element, get the index
    new_lidar_index = np.argmin(difference_arr)
    minimum_difference = difference_arr[new_lidar_index]

    #print("R: " + str(rosbag_timestamps[new_lidar_index]) + " P:" + str(path_timestamp))

    # Bad status - return -1
    if minimum_difference > time_boundary:
        return -1
    else:
        return new_lidar_index





# Gets a set of aligned values for a pickle and rosbag file
#  The aligned values are (Z x N x D),
#   where Z is the number of path packets
#   N is the number of path items in that packet
#  and D is the dimensionality of the pose combined with lidar
#  D = 1 + 5 + 1081 (timestamp + pose values + lidar)
def get_aligned_values(pickle_path, rosbag_path):

    # Load in the files
    pickle_data = get_pickle_data(pickle_path)
    rosbag_data = get_rosbag_data(rosbag_path)
    # Remove all NaNs and Infs
    pickle_data = np.nan_to_num(pickle_data)
    rosbag_data = np.nan_to_num(rosbag_data)

    file_aligned_values = [] # saves pairs of data, label (label is goal pose - 5 elements)

    rosbag_lidar_index = 0 # Start lidar index at zero. Used for timestamp comparisons.
    time_boundary = 1/15  #Make sure timestamps being compared are within these bounds

    for path_packet in pickle_data:


        # 2d array of timestamped path positions
        timestamped_paths = attach_timestamps_to_path_data(path_packet)

        # list aligned timestamps and values (determined by path timestamp)
        aligned_values = []

        # Iterate through each timestamped row
        for row in timestamped_paths:
            path_timestamp = row[0]

            closest_index = find_closest_lidar_time(rosbag_data,
                rosbag_lidar_index,path_timestamp, time_boundary)

            # We found a closest pair!
            if closest_index != -1:
                rosbag_lidar_index = closest_index
                # Now we combine the path data and the lidar data
                #   for the aligned timestamp
                # The reason why we take the closest index [1:] is because we don't need to save the timestamp
                aligned_entry = np.concatenate((row, rosbag_data[closest_index][1:]))
                aligned_values.append(aligned_entry)

                print(aligned_entry.shape)

        # Stack the arrays so we get a 2d array
        aligned_values = np.vstack(aligned_values)
        #print(aligned_values.shape) #Get the final shape of the object
        
        # Get final goal pose
        goal_pose = get_goal_pose_from_packet(path_packet)
        # Get LQR controls
        LQR_controls = get_lqr_controls(path_packet)
        # Get path poses
        path_poses = get_paths_from_packet(path_packet)
	
        file_aligned_values.append([aligned_values, goal_pose, LQR_controls, path_poses]) # Saves pairs of data and labels
    return file_aligned_values

# Example paths
#pickle_path = "../data/self_drive_no_obstacles/self_drive_0_26"
#rosbag_path = "../data/self_drive_no_obstacles/self_drive_0_26_lidar.bag"
# Go through the file directory for data and retrieve all the pickle/rosbag files
def get_filepaths(data_dir):
    
    # We need to save the pairs of picklepaths and rosbag paths
    # I do this by ignoring all rosbag dirs, using the names of the picklpaths, and recreating
    #  the lidar pathfiles.
    pickle_filenames = [x for x in os.listdir(data_dir) if ".bag" not in x]
    rosbag_filenames = [x + "_lidar.bag" for x in pickle_filenames]
    file_pairs = [[pickle_filenames[i], rosbag_filenames[i]] for i in range(0, len(pickle_filenames))]
    return file_pairs
    



 # Gets the aligned data for all paths/lidars and saves each path packet to a file
def extract_paths_and_save_data(data_dir, title):
    file_pairs = get_filepaths(data_dir)
    start_path = "/home/natsubuntu/catkin_ws/src/nesl_bot/scripts/self_driving"
    save_dir = start_path + "/generated/"
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)

    for pair in file_pairs:  #Get the aligned values for each pickle and rosbag file	
        aligned_values = get_aligned_values(data_dir + "/" + pair[0], data_dir + "/" + pair[1])
        # returns a list of (path and lidar packet), and for each packet there is a 5vec label
        #(basically a list of pairs, the second column being the goal pose)
        print("Saving aligned values for " + pair[0] + " under " + title)
        # for each pair of (path data, label) in the aligned values, save it to a file.
        # The filename is under the data directory,with each inner folder named after the 
        # pickle file.  Finally, each path is saved as a separate npy file consisting of
        # a list of aligned values, and the goal pose.
        for path_index, path_data in enumerate(aligned_values):
            save_folder = save_dir + pair[0] + "_" + title + "/"
            save_filepath = save_folder + str(path_index) + ".npy"
            # If the directory does not already exist, create it.
            if not os.path.exists(save_folder):
                os.makedirs(save_folder)
            #np.save(save_filepath, path_data, fix_imports=True)
            sf = open(save_filepath, 'wb')
            pickle.dump(path_data, sf,protocol=2)
            print("Saving aligned path of data: " + str(path_data[0].shape) + " and labels: " + str(path_data[1].shape))

#  Load the data and labels from a filepath
def load_data_and_labels_from_path(filepath):
    loaded_data = np.load(filepath, allow_pickle=True)
    return loaded_data[0], loaded_data[1]




if __name__ == "__main__":

	# Some example code
    start_path = "/home/natsubuntu/catkin_ws/src/nesl_bot/scripts/self_driving"
    data_dirs = [start_path + "/data/self_drive_no_obstacles", start_path + "/data/imitation_data/golden_imit_data", 
			start_path + "/data/imitation_data/good_imit_data", start_path + "/data/imitation_data/okay_imit_data"]
	#NOTE - THESE MUST BE CONSISTENT WITH THE TITLES USED IN driver.py
	#  If you change these, look at the get_all_possible_paths call in driver.py
    titles = ["no_obstacles", "golden_imit", "good_imit", "okay_imit"]

    for i, data_dir in enumerate(data_dirs):
        extract_paths_and_save_data(data_dir, titles[i])


#TODOs:
# - not sure if robot start and end pose should be included as timestamps.
#    for now, I'll include only the start pose as part of the data.

