from data_extractor import get_most_significant_lidar_points
from data_generator import get_all_possible_paths, get_np_data_from_file, get_lookahead_window, get_controls_from_q, find_closest_nominal_pose
from model import Delivery_boi
import numpy as np
import random





# Tester file for loading a model and running prediction on it.



#A state vector (in this exact order) consists of:
# 2 (goal pose) + 3 (current pose) + 15*2 (future poses) + 60 (lidar) = 100.
state_vector_shape = (95,1)
action_vector_shape = 140

# NOTE: these two should be the same type of model
MODEL_FILEPATH = "models/cnn/model_277.h5"
MODEL_TYPE = "cnn"

# Initialize the RL model
dev_boi = Delivery_boi(state_vector_shape, action_vector_shape, MODEL_TYPE)

# Load the model
dev_boi.model.load_weights(MODEL_FILEPATH)

# Place your rosbag data here or where ever you plan to get it from
# Should be something like (1080,)
ROSBAG_LIDAR_DATA = np.zeros(1080)

# Get the most significant lidar points (here I get 60 points)
ROSBAG_LIDAR_DATA_SIGNIFICANT = get_most_significant_lidar_points(ROSBAG_LIDAR_DATA, num=60)

# Place your goal pose and current pose data here
# Goal should just be the x,y value (2,) and current pose should include heading (3,)
PATH_GOAL = np.zeros(2)
PATH_CURRENT = np.zeros(3)

# Hard part - you somehow have to get a lookahead window.
#  I've included a very brute force solution that samples through all data files of a chosen
#   path under 'generated' and finds the closest point to your current point.
#  From there, it returns the lookahead window for the closest point.
DESIRED_TITLES = ["no_obstacles", "golden_imit", "good_imit", "okay_imit"]
data_files = get_all_possible_paths(DESIRED_TITLES)
PATH_NAME = "3_37"  #"1_41" # I want to do path 1_41
data_files = [x for x in data_files if PATH_NAME in x] # Keep only the files for this path

top_min_file = ""
top_min_index = 0
top_min_value = 420 # Something dumb to start with

for data_file in data_files:
	
	# Get the nominal pose data
	nominal_pose_path = get_np_data_from_file(data_file)[3]

	# Get the index and value of the smallest absolute difference
	current_min_index, current_min_value = find_closest_nominal_pose(PATH_CURRENT, nominal_pose_path)

	if current_min_value < top_min_value:
		top_min_value = current_min_value
		top_min_index = current_min_index
		top_min_file = data_file


# Now we grab the lookahead window for the minimum difference
path_pose_data = get_np_data_from_file(top_min_file)[3]
# the get_lookahead_window takes in a 2d array of Z x 5, where Z is the length of the path
#  The result is a flattened vector of window_size * 2
lookahead_window = get_lookahead_window(15, top_min_index, path_pose_data)

# So now we have to concatenate this state vector
state_vector = np.hstack([PATH_GOAL, PATH_CURRENT, lookahead_window, ROSBAG_LIDAR_DATA_SIGNIFICANT])
# Now we have to reshape this state vector to fit in the model
state_vector = np.expand_dims(state_vector, axis=-1)
state_vector = np.expand_dims(state_vector, axis=0)


# Run prediction
print("STATE VEC SHAPE: ", state_vector.shape)
prediction = dev_boi.model.predict(state_vector).flatten()
# Get the best action to take, and print out the v,phi values
best_action = np.argmax(prediction)
print(best_action)
v, phi = get_controls_from_q(best_action)
print(" Action: velocity=" + str(v) + " with angle=" + str(phi))
