import numpy as np
#import tensorflow
from tensorflow_model_optimization.sparsity import keras as sparsity

# Initialize a pruned model from a non-pruned model
def create_pruned_model(model, pruning_epochs):


	# Basically says we should start at 50% sparsity and reach 90% sparsity
	# Only prune every 100 steps
	new_pruning_params = {
		'pruning_schedule': sparsity.PolynomialDecay(initial_sparsity=0.50,
		final_sparsity=0.90,
		begin_step=0,
		end_step=pruning_epochs,
		frequency=100)
	}

	new_pruned_model = sparsity.prune_low_magnitude(model, **new_pruning_params)
	new_pruned_model.summary()

	# Same as the original optimizer and loss
	new_pruned_model.compile(loss="mse", optimizer=RMSprop(lr=0.000001), metrics=['mse'])
	
	return new_pruned_model
