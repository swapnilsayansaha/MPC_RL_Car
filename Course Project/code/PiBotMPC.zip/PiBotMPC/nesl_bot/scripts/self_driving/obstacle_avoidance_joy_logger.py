#!/usr/bin/env python
import numpy as np
import rospy
from ackermann_msgs.msg import AckermannDriveStamped
import pickle
import sys, os 
from nav_msgs.msg import Path
from geometry_msgs.msg import PoseStamped
import tf
import copy
from sensor_msgs.msg import Joy
from visualization_msgs.msg import Marker
from visualization_msgs.msg import MarkerArray
from geometry_msgs.msg import Point
import datetime
from threading import Lock
import matplotlib.pyplot as plt 

controls = np.zeros(2)
start_log = False
pause_between_traj = False
delete_path_interval = False

# use TF to find most recent pose of the robot on the fly
def get_current_pose(listener, dt):
    #global dt
    tic = rospy.get_time()
    gate = True
    time_list = 0.0
    while gate:
        try:
            t,q = listener.lookupTransform('/odom', '/base_link', rospy.Time(0))
            time_list = rospy.get_time() - tic
            gate = False
            #print(t,r)
        except:
            rospy.sleep(.001) #1ms sleep
    rpy = tf.transformations.euler_from_quaternion(q)
    if time_list > dt:
        print("Transform Listener Took over DT!")
    #print("Pose is: ", t[0], t[1], rpy[2])
    #print("Time to get Pose: ", time_list)
    return np.array([ t[0], t[1], rpy[2] ]), time_list
 
#bring in columnwise numpy array of x,y,theta, outputs publishable path to ROS
def numpy_xyt_array_to_ros_path(np_array):
    # Now Republish the path to ROS for visualization
    path = Path()
    path.header.frame_id = "/map"
    #path.header.stamp = rospy.Time.now()
    x_os = np_array[:,0:3]
    for x in x_os:
        geom_msg = PoseStamped()
        geom_msg.header.frame_id = "/map"
        geom_msg.pose.position.x = x[0]
        geom_msg.pose.position.y = x[1]
        geom_msg.pose.position.z = 0
        #q = tf.transformations.quaternion_from_euler(0,0,x[2])
        #geom_msg.pose.orientation.x = q[0]
        #geom_msg.pose.orientation.y = q[1]
        #geom_msg.pose.orientation.z = q[2]
        #geom_msg.pose.orientation.w = q[3]
        path.poses.append(geom_msg)
    return path

def joy_callback(msg):
    global controls, start_log, pause_between_traj, delete_path_interval
    # Need to lock controls temporarily
    controls[0] = msg.axes[1] * 1.00
    controls[1] = msg.axes[3] * np.pi / 6.0
    if msg.buttons[0]:
        start_log = True
    # If right button was pressed, pause after next waypoint
    if msg.buttons[5]:
        print("Requested pause between paths")
        pause_between_traj = True
    # If left trigger is presed, resume
    if msg.buttons[4]:
        pause_between_traj = False
    if msg.buttons[1]:
        delete_path_interval = True

def get_normal_line(x1, y1, x2, y2):
    #if np.abs(x2 - x1) < 1e-12:
    #    delt_x = 1e-12
    #if y2 - y1 
    m = (y2 - y1) / (x2 - x1) 
    #b = y2 - m * x2 
    m2 = -1.0 / m 
    b2 = y2 - m2 * x2 
    return (np.array([-m2, 1.0]), b2)

def get_sign_of_point_wrt_line(A, b, x):
    return np.sign( np.dot(A,x) - b)

def publish_goal_point_markers(marker_pub, goal_points, attempts = 3):
    marker = Marker()
    obj_markers = MarkerArray()
    marker_count = 0
    for goal_point in goal_points:
        # Create Goal Point marker
        marker = Marker()
        marker.header.frame_id = '/map'
        marker.header.stamp = rospy.Time.now()
        marker.type = marker.CYLINDER
        marker.id = marker_count + 1
        marker.action = marker.ADD
        marker.scale.x = 0.2 
        marker.scale.y = 0.2 
        marker.scale.z = 0.2 
        marker.color.a = 1.0 
        marker.color.r = 0.0 
        marker.color.g = 1.0 
        marker.color.b = 0.0 
        marker.pose.orientation.w = 1.0 
        marker.pose.position.x = goal_point[0] 
        marker.pose.position.y = goal_point[1]
        marker.pose.position.z = 0.10
        obj_markers.markers.append(marker)
        marker_count += 1

    # may need effort attempts here
    #dur = rospy.Rate(15)
    for _ in range(attempts):
        marker_pub.publish(obj_markers)
        rospy.sleep(.002)
        #dur.sleep()
    print("Published Goal Point Markers")

def load_path_to_rviz(path_pub, path_file, attempts = 6):
    #trajectories_dir = "/home/natsubuntu/catkin_ws/src/nesl_bot/Data/warehouse_trajectories/self_drive_obstacles"
    #trajectories_file = path_file_name
    paths_file = open(path_file, 'rb')
    paths_data = pickle.load(paths_file) #, encoding='iso-8859-1')
    paths_file.close()

    # Create Mega Path and Publish out for visualization
    HZ = 15
    dur = rospy.Rate(HZ)
    mega_path = np.vstack( [path[2][:,0:3] for path in paths_data] )
    goal_points = [ path[2][-1,0:2] for path in paths_data]
    goal_lines = [ get_normal_line( path[2][-2,0], path[2][-2,1], 
                                    path[2][-1,0], path[2][-1,1] ) for path in paths_data ]
    start_signs = [get_sign_of_point_wrt_line(Ab[0],Ab[1], path[2][-2,0:2]) for Ab, path in zip(goal_lines, paths_data)]
    ros_mega_path = numpy_xyt_array_to_ros_path(mega_path)
    # Make sure the global path actually shows up
    for _ in range(attempts):
        path_pub.publish(ros_mega_path)
        dur.sleep()
    print("Published Full Path!")
    return goal_points, goal_lines, start_signs, paths_data


def create_obstacle_immitation_data_joy(load_driving_path = "self_drive_3_37"):
    rospy.sleep(4)
    HZ = 15
    DT = 1.0 / HZ
    dur = rospy.Rate(HZ)
    joy_sub = rospy.Subscriber("/joy", Joy, joy_callback, queue_size = 2)
    cmd_pub = rospy.Publisher("/ackermann_cmd", AckermannDriveStamped, queue_size = 2)
    path_pub = rospy.Publisher("/tugboat/path/plan", Path, queue_size = 1)
    marker_array_pub = rospy.Publisher("/tugboat/goal_point/markers", MarkerArray, queue_size=10)
    listener = tf.TransformListener()
    obstacle_dir = "/home/natsubuntu/catkin_ws/src/nesl_bot/Data/warehouse_trajectories/self_drive_obstacles/"
    self_drive_path_dir = "/home/natsubuntu/catkin_ws/src/nesl_bot/Data/warehouse_trajectories/self_drive_no_obstacles/"
    self_drive_path_dir += load_driving_path
    # Load Path loop to rviz for vizualization
    goal_points, goal_lines, start_signs, paths_data = load_path_to_rviz(path_pub, path_file = self_drive_path_dir)
    # Use Markers to indicate goal points
    #publish_goal_point_markers(marker_array_pub, goal_points)
    # Goal lines
    # After publishing out nominal path, now need to do the following
    # 1) load virtual object manager that goes with path seperately, assume objects static for now
    # 2) attempt each end point, when dist to next path is closer than current path, end 'path', start new goal
    # 3) log joy, state; retroactively (with dist check), create path, time to go, 
    
    #lock = Lock()
    # Wait for user to press the 'a' button to begin collecting data
    print("Waiting for Drive!")
    while not start_log:
        dur.sleep()

    global controls, pause_between_traj, delete_path_interval
    print("Start Self Drive!")
    new_paths_data = []
    for i in range(len(goal_points)):
        # Publish out next three goal positions
        if i + 3 >= len(goal_points):
            publish_goal_point_markers(marker_array_pub, goal_points[i:])
        else:
            publish_goal_point_markers(marker_array_pub, goal_points[i:i+3])
        
        # Check to see if the user has requested to pause between this and the next trajectory
        if pause_between_traj:
            print("Pausing!")
        while pause_between_traj:
            dur.sleep()
        # While we havent crossed the goal point's finish line, continue driving and logging
        print("Start New Path ", i + 1)
        tic = rospy.get_time()
        path_packet = []
        l2_norm_min = 0.90
        x, tl = get_current_pose(listener, DT)
        path_packet.append(x)
        path_packet.append(paths_data[i][1])
        #path = []
        joy_controls = []
        states = []
        while  not ( (np.linalg.norm(goal_points[i] - x[0:2]) < l2_norm_min) and (get_sign_of_point_wrt_line(goal_lines[i][0], goal_lines[i][1], x[0:2]) != start_signs[i]) ):
            #print("Condition Not Met")
            #print( "Sign: ", get_sign_of_point_wrt_line(goal_lines[i][0], goal_lines[i][1], x[0:2]) )
            #print("L2: ", np.linalg.norm(goal_points[i] - x[0:2]) )
            # publish joy action
            inner_tic = rospy.get_time()
            ack_msg = AckermannDriveStamped()
            ack_msg.header.frame_id = "base_link"
            ack_msg.header.stamp = rospy.Time.now()
            #lock.acquire()
            # Need to lock controls temporarily
            ctrl = copy.deepcopy(controls)
            #lock.release()
            ack_msg.drive.speed = ctrl[0] #uo[0] #u_app[0]
            ack_msg.drive.steering_angle = ctrl[1] #uo[1] #u_app[1]
            cmd_pub.publish(ack_msg)
            states.append(x)
            #path.append(np.concatenate((x,ctrl)))
            joy_controls.append(ctrl)
            inner_toc = rospy.get_time()
            # sleep for DT - loop time taken
            if DT - tl - (inner_toc - inner_tic) > 0:
                rospy.sleep(DT - tl - (inner_toc - inner_tic))
            # Get new state after applying control action
            xl = copy.deepcopy(x)
            x, tl = get_current_pose(listener, DT)
            # assert theta is between -pi and pi
            if abs(x[2] - xl[2]) > abs(x[2] - xl[2] - 2*np.pi):
                #print("QUATERNION SHIFT-> REAJUST!")
                x[2] -= 2*np.pi
            elif abs(x[2] - xl[2] ) > abs(x[2] - xl[2] + 2*np.pi):
                #print("QUATERNION SHIFT-> REAJUST")
                x[2] += 2*np.pi
            
            
        # Once we are done logging the data, create path
        print("CONDITION_MET")
        print("Goal State is: ", goal_points[i], "We hit: ", x)
        #print("Goal Normal is: ", goal_lines[i])
        toc = rospy.get_time()
        #np_path = np.array(path)
        path_packet.append(paths_data[i][2])
        path_packet.append(None) # control gains
        path_packet.append([tic, toc])
        path_packet.append(np.array(joy_controls))
        path_packet.append(np.array(states))
        if delete_path_interval:
            delete_path_interval = False
            print("Not including bad path segment ", i + 1)
        else:
            new_paths_data.append(path_packet)
            print("End Path ", i + 1)
        #print("Shape of Path is: ", np_path.shape)
        #print("Shape of State is: ", np.array(states).shape)
        #print("Shape of Controls is: ", np.array(joy_controls).shape)

    # Bring car to a hault
    ack_msg = AckermannDriveStamped()
    ack_msg.header.frame_id = "base_link"
    ack_msg.header.stamp = rospy.Time.now()
    ack_msg.drive.speed = 0
    ack_msg.drive.steering_angle = 0
    cmd_pub.publish(ack_msg)

    # Once done full loop, log new_paths_data
    pieces = load_driving_path.split("_")
    now = datetime.datetime.now()
    file_name = "obstacle_drive_" + pieces[2] + "_" + pieces[3] + "_logged_" + str(now.hour) + "_" + str(now.minute)
    trajectories_file = open(obstacle_dir + file_name,'wb')
    pickle.dump(new_paths_data, trajectories_file)
    print("Saved Immitation Learning Data!")


# Idea
# 1) Load the nominal course you'd like to run
# 2) Load markers at the boundary of each path, construct finish line 
# 3) Load obstacles using obstacle centers list
# 4) Drive from goal point to goal point avoiding obstacles along the way
# 5) Test for goal point finish, when we have crossed the line, save counter
# 6) Using last count and new count, create joy-path, then log start, goal, joy-path, (tic,toc), controls, states
# 7) Once done loop, save data to obstacle self driving data folder 
if __name__ == "__main__":
    rospy.init_node("path_drive")
    rospy.sleep(1)
    self_drive_path = rospy.get_param("/self_drive_path_file")
    create_obstacle_immitation_data_joy(load_driving_path=self_drive_path)