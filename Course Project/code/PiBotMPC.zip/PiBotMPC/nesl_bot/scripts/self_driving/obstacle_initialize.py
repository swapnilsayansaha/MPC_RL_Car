#!/usr/bin/env python
import numpy as np
import rospy
from ackermann_msgs.msg import AckermannDriveStamped
import pickle
import sys, os 
from nav_msgs.msg import Path
from geometry_msgs.msg import PoseStamped
from geometry_msgs.msg import PointStamped
import tf
import copy
from visualization_msgs.msg import Marker
from visualization_msgs.msg import MarkerArray

MARKERS_MAX = 200
marker_count = 0
obj_markers = MarkerArray()

# use TF to find most recent pose of the robot on the fly
def get_current_pose(listener, dt):
    #global dt
    tic = rospy.get_time()
    gate = True
    time_list = 0.0
    while gate:
        try:
            t,q = listener.lookupTransform('/odom', '/base_link', rospy.Time(0))
            time_list = rospy.get_time() - tic
            gate = False
            #print(t,r)
        except:
            rospy.sleep(.001) #1ms sleep
    rpy = tf.transformations.euler_from_quaternion(q)
    if time_list > dt:
        print("Transform Listener Took over DT!")
    #print("Pose is: ", t[0], t[1], rpy[2])
    #print("Time to get Pose: ", time_list)
    return np.array([ t[0], t[1], rpy[2] ]), time_list
 
#bring in columnwise numpy array of x,y,theta, outputs publishable path to ROS
def numpy_xyt_array_to_ros_path(np_array):
    # Now Republish the path to ROS for visualization
    path = Path()
    path.header.frame_id = "/map"
    #path.header.stamp = rospy.Time.now()
    x_os = np_array[:,0:3]
    for x in x_os:
        geom_msg = PoseStamped()
        geom_msg.header.frame_id = "/map"
        geom_msg.pose.position.x = x[0]
        geom_msg.pose.position.y = x[1]
        geom_msg.pose.position.z = 0
        #q = tf.transformations.quaternion_from_euler(0,0,x[2])
        #geom_msg.pose.orientation.x = q[0]
        #geom_msg.pose.orientation.y = q[1]
        #geom_msg.pose.orientation.z = q[2]
        #geom_msg.pose.orientation.w = q[3]
        path.poses.append(geom_msg)
    return path

# load full loop path and publish out the mega path
def visualize_path(path_file_name = "self_drive_3_37"):
    #rospy.init_node("path_drive")
    rospy.sleep(3)
    HZ = 15
    dur = rospy.Rate(HZ)
    #cmd_pub = rospy.Publisher("/ackermann_cmd", AckermannDriveStamped, queue_size = 2)
    path_pub = rospy.Publisher("/tugboat/path/plan", Path, queue_size = 1)
    #listener = tf.TransformListener()

    trajectories_dir = "/home/natsubuntu/catkin_ws/src/nesl_bot/Data/warehouse_trajectories/self_drive_no_obstacles/"
    trajectories_file = path_file_name
    paths_file = open(trajectories_dir + trajectories_file, 'rb')
    paths_data = pickle.load(paths_file) #, encoding='iso-8859-1')


    # Create Mega Path and Publish out for visualization
    mega_path = np.vstack( [path[2][:,0:3] for path in paths_data] )
    ros_mega_path = numpy_xyt_array_to_ros_path(mega_path)
    # Make sure the global path actually shows up
    for _ in range(10):
        path_pub.publish(ros_mega_path)
        dur.sleep()
    print("Published Full Path!")
      
def clicked_point_callback(msg):
    global object_pose_list, marker_count, marker_pub, obj_markers, MARKERS_MAX
    print("Appended Marker Point", (msg.point.x, msg.point.y), " to list")
    object_pose_list.append([msg.point.x, msg.point.y])
    marker = Marker()
    marker.header.frame_id = '/map'
    marker.header.stamp = rospy.Time.now()
    marker.type = marker.CYLINDER
    marker.id = marker_count + 1
    marker.action = marker.ADD
    marker.scale.x = 0.2 
    marker.scale.y = 0.2 
    marker.scale.z = 0.2 
    marker.color.a = 1.0 
    marker.color.r = 0.0 
    marker.color.g = 1.0 
    marker.color.b = 0.0 
    marker.pose.orientation.w = 1.0 
    marker.pose.position.x = msg.point.x 
    marker.pose.position.y = msg.point.y 
    marker.pose.position.z = 0.0
    obj_markers.markers.append(marker)
    if marker_count < MARKERS_MAX:
        marker_pub.publish(obj_markers)
        print("Published Marker Point")
        marker_count += 1
        print("Length Obj Markers: ", len(obj_markers.markers))


print("Hello from obstacle initialize")
rospy.init_node("path_drive")
rospy.sleep(1)
object_pose_list = []
marker_pub = rospy.Publisher("/tugboat/obstacle/markers", MarkerArray, queue_size=10)
clicked_point_sub = rospy.Subscriber('/clicked_point', PointStamped, callback=clicked_point_callback)

if __name__ == "__main__":
    path_file_name = rospy.get_param("/self_drive_path_file") #"self_drive_2_59"
    visualize_path(path_file_name=path_file_name)
    path_to_self_drive_obj_file = "/home/natsubuntu/catkin_ws/src/nesl_bot/Data/warehouse_trajectories/self_drive_obstacles/obstacle_placements/" + path_file_name + "_obj_centers"
    try:
        dur = rospy.Rate(20)
        while not rospy.is_shutdown():
            dur.sleep()
    except Exception:
        if len(object_pose_list) > 5:
            obj_file = open(path_to_self_drive_obj_file, 'wb')
            pickle.dump(object_pose_list, obj_file)
            print("Wrote path objects to file")
            obj_file.close()
        else:
            print("Not enough objects to log")