#!/usr/bin/env python
from gekko import GEKKO
import numpy as np
import math 
import matplotlib.pyplot as plt 
from mpl_toolkits import mplot3d
from matplotlib import cm
import rospy 
from nav_msgs.msg import Path
from geometry_msgs.msg import PoseStamped
import tf
from ackermann_msgs.msg import AckermannDriveStamped
from scipy import interpolate
import pickle
import datetime

# order of the log is start_state, goal_state, path, LQR Gains, sys time start to sys time end for the trajectory
full_path_log = []

# Uses IPOPT to convert a dijkstra differential drive path to one for an ackermann robot, 
# uses a discrete time finite horizon error tracking LQR to track the path in real time, via dynamic programming
class AckermannReferenceTrajectoryController:

    def __init__(self, dt):
        self.state_ic = None
        self.control_ic = None
        self.set_point_reference = None
        self.ref_trajectory = None
        self.way_points_bvs = None 
        self.TF = None
        self.dt = dt
        self.length = 0.36
        self.HORIZON_STEPS = None
        self.mpc_objectives = ["L2_terminal_cost_lagrange_control", 
                                "L2_terminal_cost_lagrange_trajectory_control",
                                "L1_terminal_cost_lagrange_control",
                                "L1_terminal_cost_lagrange_trajectory_control"]
        self.mpc_modes = ["ref_state_bvp", "ref_traj_bvp", "way_point_list"]
        self.gek_R = np.eye(2)

    # Defualt mode is move to reference point using L2
    def set_mpc_mode_objective(self, mpc_mode = 0, mpc_objective = 0):
        self.mpc_mode = self.mpc_modes[mpc_mode]
        self.mpc_objective = self.mpc_objectives[mpc_objective]

    # for mode (0,0) ics is a tuple of arrays (x0,u0), bv_state is vector of length 5 indicating Final BV (No BV if None entered)
    def set_ics_ref_objective(self, ics = (np.zeros(3), np.zeros(2)), bv_state = None, tf = None, trajectory = None, ref_state_list = None):
        self.state_ic = ics[0]
        self.control_ic = ics[1]

        # If mode is reference state
        if self.mpc_mode == self.mpc_modes[0]:
            assert type(bv_state) == type(np.array([]))
            assert bv_state.size >= 4 and tf is not None 
            self.TF = tf
            self.set_point_reference = bv_state
            self.HORIZON_STEPS = int(tf / self.dt + 1)

        # If mode is trajectory
        if self.mpc_mode == self.mpc_modes[1]:
            assert type(trajectory) == type(np.array([]))
            assert type(bv_state) == type(np.array([]))
            assert tf is not None and bv_state.size >= 4 and trajectory is not None
            self.set_point_reference = bv_state #overloading 
            self.TF = tf
            self.HORIZON_STEPS = int(tf / self.dt + 1)
            self.ref_trajectory = trajectory

        # If mode is list of weight points and boundary values
        if self.mpc_mode == self.mpc_modes[2]:
            pass

    def _set_mpc_constraints_objective_ics(self, x, u, xu_ref, t_now, dt, t_f):
        self.m = GEKKO()		
        self.intervals = self.HORIZON_STEPS
        self.m.time = np.linspace(t_now,t_f,self.intervals)

        # Controls
        self.v = self.m.MV(value = u[0], lb= -.25, ub=1.25) #m/s
        self.phi = self.m.MV(value = u[1],lb = -3.14 / 6, ub = 3.14 / 6)
        self.v.STATUS = 1 
        self.v.DCOST = .005
        self.phi.STATUS = 1 
        self.phi.DCOST = .0005
        # States 
        self.x1 = self.m.Var(value=x[0])
        self.x2 = self.m.Var(value=x[1])
        self.x3 = self.m.Var(value= x[2])
        #self.x4 = self.m.Var(value= 0.0) # energy state of Lagrangian x.T @ Q @ x
        self.x5 = self.m.Var(value= 0.0) # energy state of Lagrangian u.T @ R @ u
        #Dynamics Equations (Equality Constraints)
        self.m.Equation(self.x1.dt() == self.v*self.m.cos(self.x3))
        self.m.Equation(self.x2.dt() == self.v*self.m.sin(self.x3))
        self.m.Equation(self.x3.dt() == self.v / self.length * self.m.tan(self.phi))
        #self.m.Equation(self.x4.dt() == 0.5 * self.gek_state @ self.gek_Q @ self.gek_state ) # Lagrangian pt 1
        self.m.Equation(self.x5.dt() == 0.5 * self.v**2 * self.gek_R[0,0]  + 0.5 * self.phi**2 * self.gek_R[1,1]  ) # Lagrangian pt 2

        self.params = np.zeros(self.intervals)
        self.params[-1] = 1
        self.final = self.m.Param(value=self.params)
        if self.mpc_mode == "ref_state_bvp":
            if self.mpc_objective == "L2_terminal_cost_lagrange_control":
                self.m.Obj( 5.0*(self.final*xu_ref[0] - self.final*self.x1)**2 + 5.0*(self.final*xu_ref[1] -self.final*self.x2)**2 + 5.0*(self.final*xu_ref[2] - self.final*self.x3)**2 + 5.0*(self.final*xu_ref[3] - self.final*self.v)**2 + 1.0*self.final*self.x5)
            elif self.mpc_objective == "L1_terminal_cost_lagrange_control":
                self.m.Obj( 1.0*self.m.abs2(self.final*xu_ref[0] - self.final*self.x1) + 1.0*self.m.abs2(self.final*xu_ref[1] -self.final*self.x2) + 1.0*self.m.abs2(self.final*xu_ref[2] - self.final*self.x3) + 1.0*self.m.abs2(self.final*xu_ref[3] - self.final*self.v) + 1.0*self.final*self.x5)
            else:
                print("ERROR IN YOUR MPC INIT!")
                exit(1)
        elif self.mpc_mode == "ref_traj_bvp":
            print("Intervals: ", self.intervals)
            assert self.ref_trajectory.shape[0] == self.intervals
            self.running1 = self.m.Param(value=self.ref_trajectory[:,0])
            self.running2 = self.m.Param(value=self.ref_trajectory[:,1])
            #self.running3 = self.m.Param(value=self.ref_trajectory[:,2])
            assert self.mpc_objective != self.mpc_modes[0] and self.mpc_objective != self.mpc_modes[2]
            if self.mpc_objective == "L2_terminal_cost_lagrange_trajectory_control":
                #Term_cost = self.m.Obj( 5.0*(self.final*xu_ref[0] - self.final*self.x1)**2 + 5.0*(self.final*xu_ref[1] -self.final*self.x2)**2 + 5.0*(self.final*xu_ref[2] - self.final*self.x3)**2 + 5.0*(self.final*xu_ref[3] - self.final*self.v)**2
                self.m.Obj(5.0*(self.final*xu_ref[0] - self.final*self.x1)**2 + 5.0*(self.final*xu_ref[1] -self.final*self.x2)**2 + 5.0*(self.final*xu_ref[2] - self.final*self.x3)**2 + 5.0*(self.final*xu_ref[3] - self.final*self.v)**2 + 1.0*self.final*self.x5 + 0.25*(self.running1 - self.x1)**2 + 0.25*(self.running2 - self.x2)**2 )
                #self.m.Obj( 5.0*(self.final*xu_ref[0] - self.final*self.x1)**2 + 5.0*(self.final*xu_ref[1] -self.final*self.x2)**2 + 5.0*(self.final*xu_ref[2] - self.final*self.x3)**2 + 5.0*(self.final*xu_ref[3] - self.final*self.v)**2 + 1.0*self.final*self.x5)
            elif self.mpc_objective == "L1_terminal_cost_lagrange_trajectory_control":
                self.m.Obj( 5.0*self.m.abs2(self.final*xu_ref[0] - self.final*self.x1) + 5.0*self.m.abs2(self.final*xu_ref[1] -self.final*self.x2) + 5.0*self.m.abs2(self.final*xu_ref[2] - self.final*self.x3) + 5.0*self.m.abs2(self.final*xu_ref[3] - self.final*self.v) + 1.0*self.final*self.x5 + 1.0*(self.running1 - self.x1)**2 + 1.0*(self.running2 -self.x2)**2 )
            else:
                print("ERROR IN YOUR MPC OBJ INIT!")
                exit(1)
        elif self.mpc_mode == "way_point_list":
            pass
        else:
            print("ERROR IN YOUR MPC MODE INIT!")
            exit(1)

        # Set Gekko Modes
        self.m.options.IMODE = 6
        self.m.options.NODES = 4 
        self.m.options.MV_TYPE = 1
        self.m.options.SOLVER = 3

    def get_discrete_time_trajectory_matrices(self,x_os, u_os):
        get_F = lambda xo, uo : np.array([0,0,-uo[0]*np.sin(xo[2]), 0,0, uo[0]*np.cos(xo[2]),0,0, 0]).reshape((3,3))
        get_G = lambda xo, uo : np.array([np.cos(xo[2]), 0, np.sin(xo[2]), 0, 1.0/ self.length * np.tan(uo[1]), uo[0]/self.length * 1.0 / np.cos(uo[1])**2 ]).reshape((3,2))
        get_Phi = lambda F, dt : np.sum([np.linalg.matrix_power(F,i) * dt**i / math.factorial(i) for i in range(3)],axis = 0) #2nd order approximation of discrete time matrix exponential Phi_k
        get_Gam = lambda Phi, G, dt : np.dot(Phi, G) * dt # Approximation of discrete time control matrix G_k
        Phis = np.zeros((x_os.shape[0], 3,3))
        Gams = np.zeros((x_os.shape[0], 3,2))
        i = 0
        for xo, uo in zip(x_os, u_os):
            F = get_F(xo,uo)
            G = get_G(xo,uo)
            Phi = get_Phi(F,self.dt)
            Gam = get_Gam(Phi, G, self.dt)
            Phis[i] = Phi
            Gams[i] = Gam
            i += 1
        return Phis, Gams
	
    def non_linear_ackermann_dynamics(self, x, u):
        # first order integration of xdot = f(x)
        xd = u[0] * np.cos(x[2])
        yd = u[0] * np.sin(x[2])
        td = u[0] / self.length * np.tan(u[1])
        sd = np.array([xd,yd,td])
        return x + sd * self.dt

    def plot_mpc_trajectory_controls(self):
        plt.figure(1)
        plt.subplot(311)
        plt.title("States X,Y,Theta vs Time")
        plt.plot(self.m.time, self.x1.value)
        plt.subplot(312)
        plt.plot(self.m.time, self.x2.value)
        plt.subplot(313)
        plt.plot(self.m.time, self.x3.value)
        plt.figure(2)
        plt.subplot(211)
        plt.title("Controls V, Phi vs Time")
        plt.plot(self.m.time, self.v.value)
        plt.subplot(212)
        plt.plot(self.m.time, self.phi.value)
        plt.show()

    def plot_lqr_trajectory_controls(self, xks, uks):
        times = np.arange(0,self.TF + self. dt, self.dt)
        plt.figure(1)
        plt.subplot(311)
        plt.title("States (green) vs Trajectory (blue)")
        plt.plot(times, xks[:,0],'g')
        plt.plot(self.m.time, self.x1.value, 'b')
        plt.subplot(312)
        plt.plot(times, xks[:,1], 'g')
        plt.plot(self.m.time, self.x2.value, 'b')
        plt.subplot(313)
        plt.plot(times, xks[:,2], 'g')
        plt.plot(self.m.time, self.x3.value, 'b')
        plt.figure(2)
        plt.subplot(211)
        plt.title("Stochastic Controls (green) vs Reference Control (blue)")
        plt.plot(times, uks[:,0], 'r')
        plt.plot(self.m.time, self.v.value, 'b')
        plt.subplot(212)
        plt.plot(times, uks[:,1], 'r')
        plt.plot(self.m.time, self.phi.value, 'b')
        fig = plt.figure(3)
        ax = plt.axes(projection='3d')
        ax.plot3D(xks[:,0], xks[:,1], np.zeros(xks.shape[0]) )
        plt.show()

    def get_mpc_trajectory_controls(self):
        if self.mpc_mode != self.mpc_modes[2]: #= ["ref_state_bvp", "ref_traj_bvp", "way_point_list"]
            self._set_mpc_constraints_objective_ics(self.state_ic, self.control_ic, self.set_point_reference, 0.0, self.dt, self.TF)
            self.m.solve() # generates reference trajectory
            if self.m.options.OBJFCNVAL > 12.0:
                print("Objective Value Too Risky! Repick Path")
                return None, None
            else:
                x_os = np.vstack((self.x1.value, self.x2.value, self.x3.value))[:,:-1].T
                u_os = np.vstack((self.v.value, self.phi.value))[:,1:].T
                return x_os, u_os
        else: 
            pass # enter way point code here
	
    def LQR_solve(self, x_os, u_os, Qf = None, Q = None, R = None):
        #self.plot_mpc_trajectory_controls() # check traj with a plot
        #tic = time.time()
        phis, gammas = self.get_discrete_time_trajectory_matrices(x_os, u_os)
        # dynamic programming for error tracker LQR
        if Qf is None:
            Qf = np.eye(3)
        if Q is None:
            Q = np.eye(3)
        if R is None:
            R = self.gek_R
        Pt_1 = Qf
        #Ps = np.zeros((x_os.shape[0],3,3))
        Ks = np.zeros((x_os.shape[0],2,3))
        # Find Optimal Gains given the Phi_k Gam_k's estimated using the MPC trajectory
        # dynamic Programming backwards recursion gives optimal gains for K starting at T-1 to t=0
        i = 0
        for A, B in zip(reversed(phis), reversed(gammas)):
            K = -1.0 * np.matmul(np.matmul(np.matmul(np.linalg.inv( np.matmul(np.matmul(B.T , Pt_1) , B) + R) , B.T) , Pt_1) , A)			
            P_t = np.matmul(np.matmul(A.T , Pt_1) , A) + Q - np.matmul(np.matmul(np.matmul(np.matmul(np.matmul(np.matmul(A.T , Pt_1) , B) , np.linalg.inv(np.matmul(np.matmul(B.T , Pt_1) , B) + R) ) , B.T ) , Pt_1),  A) 
            #Ps[i] = P_t
            Ks[i] = K
            Pt_1 = P_t
            i += 1
        Ks = np.flip(Ks, 0)
        #Ps = np.flip(Ps, 0)
        
        """ # Run error tracking LQR
        # Apply scheduled gains and rollout state forwards
        xk = self.state_ic
        ek = 0.0
        xks = np.zeros((x_os.shape[0]+1,3))
        uks = np.zeros((x_os.shape[0]+1,2))
        i = 0
        xks[i] = xk
        for xo, uo, K in zip(x_os, u_os, Ks):
            # Linearized Stochastic System is this at each step
            #xk_1_lin = Phi @ xk + Gam @ u_app # old, compare to nonlin
            #e_k1_lin = Phi @ ek + Gam @ u_ek # old
            ek = xk - xo # from first order taylor series expansion
            u_ek = np.matmul(K , ek )
            # propogate stochatic control
            # for real time code, send u_app off, and subscribe to a state estimator for your new position
            u_app = u_ek + uo + np.random.randn(2)*np.array([.1, .01])
            xk_1 = self.non_linear_ackermann_dynamics(xk,u_app)
            xk = xk_1 #+ np.random.randn(3)*np.array([.005, .005, .001])
            #store for plotting
            xks[i+1] = xk_1
            uks[i] = u_app
            i += 1 
        """
        return Ks


def get_current_pose(listener):
    global dt
    tic = rospy.get_time()
    gate = True
    time_list = 0.0
    while gate:
        try:
            t,q = listener.lookupTransform('/odom', '/base_link', rospy.Time(0))
            time_list = rospy.get_time() - tic
            gate = False
            #print(t,r)
        except:
            rospy.sleep(.001) #1ms sleep
    rpy = tf.transformations.euler_from_quaternion(q)
    if time_list > dt:
        print("Transform Listener Took over DT!")
    #print("Pose is: ", t[0], t[1], rpy[2])
    #print("Time to get Pose: ", time_list)
    return np.array([ t[0], t[1], rpy[2] ]), time_list

def ackermann_trajectory_planner(msg):
    # Find length of path
    global is_goal_point_defined, mpc, MAX_SPEED, goal_point, dt, HZ, path_pub, cmd_pub, last_time, is_mpc_running, full_path_log
    if rospy.get_time() - last_time < 3.0:
        print("Debouncing Early Path!")
        is_goal_point_defined = False
        return 
    last_time = rospy.get_time()
    if is_goal_point_defined:
        is_goal_point_defined = False
        is_mpc_running = True
        #print("Hello Path!")
        lookup_gate = True
        listener = tf.TransformListener()
        while lookup_gate:
            try:
                trans, q = listener.lookupTransform("/odom", "/base_link", rospy.Time(0))
                lookup_gate = False
            except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException):
                print("Retrying Lookup Transform")
                rospy.sleep(.01)
        rpy = tf.transformations.euler_from_quaternion(q)
        xytheta_start = np.array([trans[0], trans[1], rpy[2]])
        print("XYT: ", xytheta_start)
        len_refpath = len(msg.poses)
        ref_path = np.zeros((len_refpath,2))
        i = 0
        for pose in msg.poses:
            ref_path[i] = np.array([pose.pose.position.x, pose.pose.position.y])
            i += 1
        # come up with method to decide how long ref path will be after interp
        path_distance = np.sum(np.sqrt(np.sum( (ref_path[1:,:] - ref_path[:-1,:] )**2, axis = 1)))
        print("Path Distance is: ", path_distance)
        horizon_time = path_distance / MAX_SPEED + 0.8
        len_refpath_interp = int(horizon_time * HZ)
        x_interp_in = np.linspace(0, len_refpath-1 , len_refpath)
        x_interp_out = np.linspace(0, len_refpath-1, len_refpath_interp)
        print("Scaled Trajectory Length by: ", x_interp_out.size - x_interp_in.size)
        f_int1 = interpolate.interp1d(x_interp_in, ref_path[:,0],kind='linear')
        f_int2 = interpolate.interp1d(x_interp_in, ref_path[:,1], kind='linear')
        interp_ref_x = f_int1(x_interp_out)
        interp_ref_y = f_int2(x_interp_out)
        new_ref_traj = np.zeros((len_refpath_interp+1,2))
        new_ref_traj[:-1,:] = np.vstack((interp_ref_x,interp_ref_y)).T
        
        yaw_goal = goal_point[2]
        yaw = xytheta_start[2]
        if( abs(yaw_goal - yaw) > abs(yaw_goal - 2.0*3.14 - yaw) ):
            yaw_goal -= 2.0*3.14
            print( "FORMATTING YAW GOAL: Setting yaw_goal to ", yaw_goal )
        elif(abs(yaw_goal - yaw) > abs(yaw_goal + 2.0*3.14 - yaw)):
            yaw_goal += 2.0*3.14
            print( "FORMATTING YAW GOAL: Setting yaw_goal to ", yaw_goal )
        goal_point[2] = yaw_goal
        new_ref_traj[-1] = goal_point[:-1]

        print("Start Pose: ", xytheta_start)
        print("Goal Path: ", goal_point)
        print("Start Ref Pose: ", new_ref_traj[0])
        print("End Ref Pose: ", new_ref_traj[-1])
        print("Horizon Time: ", horizon_time)
        print("Steps in Program", len_refpath_interp + 1)
        
        # Now Run the MPC Program to get optimal trajectory
        x0 = xytheta_start
        u0 = np.array([0,0])
        x_u_TF = np.array([goal_point[0], goal_point[1], goal_point[2], 0, None])
        mpc.set_mpc_mode_objective(1, 1) # follow trajectory using L2 cost function
        mpc.set_ics_ref_objective(ics = (x0,u0), bv_state= x_u_TF, tf = horizon_time, trajectory = new_ref_traj)
        x_os, u_os = mpc.get_mpc_trajectory_controls()
        if x_os is None or u_os is None:
            print("Solution Infeasible..")
            return 
        # Now Republish the path to ROS for visualization
        path = Path()
        path.header.frame_id = "/map"
        path.header.stamp = rospy.Time.now()
        for x in x_os:
            geom_msg = PoseStamped()
            geom_msg.header.frame_id = "/map"
            geom_msg.pose.position.x = x[0]
            geom_msg.pose.position.y = x[1]
            geom_msg.pose.position.z = 0
            q = tf.transformations.quaternion_from_euler(0,0,x[2])
            geom_msg.pose.orientation.x = q[0]
            geom_msg.pose.orientation.y = q[1]
            geom_msg.pose.orientation.z = q[2]
            geom_msg.pose.orientation.w = q[3]
            path.poses.append(geom_msg)
        path_pub.publish(path)
        print("Published Path!")
        # Solve LQR Dynamic Programming Problem
        Ks = mpc.LQR_solve(x_os, u_os)
        # do real time loop to see how quickly we can pull either TF transfor or odom data
        tic = rospy.get_time()
        loop_time = dt
        for xo, uo, K in zip(x_os, u_os, Ks):
            t1 = rospy.get_time()
            # Get current position
            xk, time_xk = get_current_pose(listener)
            # Solve control
            if abs(xk[2] - xo[2]) > abs(xk[2] - xo[2] - 2*np.pi):
                #print("QUATERNION SHIFT-> REAJUST!")
                xk[2] -= 2*np.pi
            elif abs(xk[2] - xo[2] ) > abs(xk[2] - xo[2] + 2*np.pi):
                #print("QUATERNION SHIFT-> REAJUST")
                xk[2] += 2*np.pi
            ek = xk - xo
            #print("State Error is: ", ek)
            u_ek = np.matmul(K, ek)
            u_app = u_ek + uo
            if u_app[0] > MAX_SPEED + .10:
                u_app[0] = MAX_SPEED
                print("Clipped u_app speed!")
            if u_app[1] < -np.pi /6.0:
                u_app[1] = -np.pi / 6.0
                print("Clipped u_app! angle")
            elif u_app[1] > np.pi/6.0:
                u_app[1] = np.pi /6.0
                print("Clipped u_app! angle")
            # Send Ackerman control off to ros
            ack_msg = AckermannDriveStamped()
            ack_msg.header.frame_id = "base_link"
            ack_msg.header.stamp = rospy.Time.now()
            ack_msg.drive.speed = u_app[0] #uo[0] #u_app[0]
            ack_msg.drive.steering_angle = u_app[1] #uo[1] #u_app[1]
            cmd_pub.publish(ack_msg)
            
            # Sleep for duration -- Enter Obstacle avoidance pipeline
            #print("Published Control: ", u_app)
            t2 = rospy.get_time()
            if not time_xk + (t2 - t1) > loop_time:
                rospy.sleep(loop_time - (t2 - t1) - time_xk)
                print("Slept For Time: ", loop_time - (t2 - t1) - time_xk)
        toc = rospy.get_time()
        # Make sure driving system is off at end of trajectory
        ack_msg = AckermannDriveStamped()
        ack_msg.header.frame_id = "base_link"
        ack_msg.header.stamp = rospy.Time.now()
        ack_msg.drive.speed = 0
        ack_msg.drive.steering_angle = 0
        cmd_pub.publish(ack_msg)
        # Save the data into pickle file
        print("Logged Path!")
        #print("Shape of path: ", np.hstack((x_os,u_os)).shape)
        traj_log = ( np.concatenate( (x0,u0) ), np.concatenate(( goal_point, np.array([0,None]) )), np.hstack((x_os,u_os)), Ks, (tic, toc))
        full_path_log.append(traj_log)
    is_mpc_running = False

def goal_point_callback(msg):
    global is_goal_point_defined, goal_point
    #print(msg)
    if not is_mpc_running:
        is_goal_point_defined = True
        q = (msg.pose.orientation.x, msg.pose.orientation.y, msg.pose.orientation.z, msg.pose.orientation.w)
        rpy = tf.transformations.euler_from_quaternion(q)
        goal_point = np.array([msg.pose.position.x, msg.pose.position.y, rpy[2]])
        print("Goal is: ", goal_point)
    else:
        print("Move Base Debounce!: ")


MAX_SPEED = 1.25 # m/s
HZ = 15
dt = 1.0 / float(HZ) # seconds -> 20 Hz
goal_point = np.array([0,0,0])
is_goal_point_defined = False # Path debouncing
is_mpc_running = False
rospy.init_node("ros_stochastic_mpc")
last_time = rospy.get_time() # Path Debouncing
mpc = AckermannReferenceTrajectoryController(dt)
path_pub = rospy.Publisher("/tugboat/path/plan", Path, queue_size = 1)
dijkstra_sub = rospy.Subscriber("/move_base/NavfnROS/plan", Path, ackermann_trajectory_planner, queue_size=1)
goal_sub = rospy.Subscriber("/move_base_simple/goal", PoseStamped, goal_point_callback, queue_size=1)
cmd_pub = rospy.Publisher("/ackermann_cmd", AckermannDriveStamped, queue_size =2)
dur = rospy.Rate(HZ)
try:
    while not rospy.is_shutdown():
        dur.sleep()
except Exception:
    now = datetime.datetime.now()
    file_dir = "/home/natsubuntu/catkin_ws/src/nesl_bot/Data/warehouse_trajectories/self_drive_no_obstacles"
    file_name = "self_drive_" + str(now.hour) + "_" + str(now.minute)
    if len(full_path_log) >4:
        trajectories_file = open(file_dir + file_name,'wb')
        pickle.dump(full_path_log, trajectories_file)
        print("Saved Trajectories")
    


