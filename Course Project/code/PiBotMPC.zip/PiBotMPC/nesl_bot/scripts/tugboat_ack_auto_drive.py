#!/usr/bin/env python
import rospy
#import numpy 
#from gekko import GEKKO
#import matplotlib.pyplot as plt
#from nav_msgs.msg import Odometry, Path
#from geometry_msgs.msg import Twist, Quaternion, PoseStamped
from sensor_msgs.msg import Joy
from ackermann_msgs.msg import AckermannDriveStamped
#import tf
#import sys, os 
import numpy as np
#import copy
#sys.path.append("/home/natsubuntu/catkin_ws/src/nesl_bot/scripts/Util/Control/process_models")
#from wheel_odometry_models import ackerman_steering_model_dtime, ackerman_steering_model_ctime


# Subscribe to cmd_vel and when we get it, update the model, and send the new TF
rospy.init_node("tugboat_ack_auto_drive", anonymous=True)

#Abusing Twist message to make it vx, vy, ang_z -> VL, VR, Phi
cmd_msg = AckermannDriveStamped()
cmd_msg.drive.speed = 0.0
cmd_msg.drive.steering_angle = 0.0
cmd_msg.drive.jerk = 0.0
cmd_msg.drive.acceleration = 0.0
cmd_pub = rospy.Publisher("/ackermann_cmd", AckermannDriveStamped, queue_size=5)

""" 
bc_Odom2BL = tf.TransformBroadcaster()
Odom2BL_lis = tf.TransformListener()
odom_pub = rospy.Publisher("/odom", Odometry, queue_size=10)
odom_msg = Odometry()
joy_msg = Joy()
hz = 15
dt = 1.0 / hz
rate = rospy.Rate(hz)
gate = False
while not gate:
    try:
        start_pos,rot = Odom2BL_lis.lookupTransform("/odom", "/base_link", rospy.Time(0))
        rpy = tf.transformations.euler_from_quaternion(rot)
        print(start_pos, rot, rpy)
        gate = True
    except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException):
        print("Asking TF..")
        rate.sleep()
        continue
 
state = np.array([start_pos[0],start_pos[1],rpy[2]])
print("THE STATE IS: ", state)
nav_goal = np.array([0.0,0.0,0.0])
last_time = None
last_speed = 0
last_steer = 0

path_count = 0 """
"""     
def mpc_traj_follow(msg):
    print("Following Path from: ", np.array(state).reshape(-1))
    global last_time, dt, state, cmd_msg, nav_goal, path_count
    path_count += 1

    # Need to figure out remantics of nav goal orientation w.r.t states orientation for the solver
    d1 = np.abs(nav_goal[2] - state[2])
    d2 = np.abs((nav_goal[2] - 2*np.pi) - state[2])
    d3 = np.abs(nav_goal[2] + 2*np.pi - state[2])
    if d2 < d1:
        nav_goal[2] -= 2*np.pi
    if d3 < d1:
        nav_goal[2] += 2*np.pi

    print("NAV GOAL IS : ", nav_goal)

    if not (path_count % 2):
        return
    m = GEKKO()
    tf = 4.0
    intervals = int(tf / dt + 1)
    m.time = np.linspace(0,tf,intervals)
    
    # Controls 
    v = m.MV(value = 0, lb= -.25, ub=1.25)
    phi = m.MV(value = 0, lb = -3.14 / 7, ub = 3.14 / 7)
    v.STATUS = 1 
    v.DCOST = 1
    v.DMAX = 4
    phi.STATUS = 1 
    phi.DCOST = 1
    phi.DMAX = 4

    # States 
    x0 = np.array(state).reshape(-1)
    x1 = m.Var(value=x0[0])
    x2 = m.Var(value=x0[1])
    x3 = m.Var(value= x0[2]) 

    length = .360 # meters
    #Equations
    m.Equation(x1.dt() == v*m.cos(x3))
    m.Equation(x2.dt() == v*m.sin(x3))
    m.Equation(x3.dt() == v / length * m.tan(phi))

    # Format Path
    dum_x_in = np.linspace(0,tf,len(msg.poses))
    dum_x_out = np.linspace(0,tf,len(m.time))
    x1_refs_in = np.array([msg.poses[i].pose.position.x for i in range(len(msg.poses))])
    x2_refs_in = np.array([msg.poses[i].pose.position.y for i in range(len(msg.poses))])
    x1_refs_out = np.interp(dum_x_out, dum_x_in, x1_refs_in)
    x2_refs_out = np.interp(dum_x_out, dum_x_in, x2_refs_in)
    print( "Length of Formatted way-points: ", len(x1_refs_out))

    # Objective Function
    p1 = np.zeros(intervals)
    p1[-1] = 1
    p2 = np.ones(intervals)
    p2[-1] = 0
    final = m.Param(value=p1)
    running = m.Param(value=p2)
    running_ref1 = m.Param(value=p2*x1_refs_out)
    running_ref2 = m.Param(value=p2*x2_refs_out)
    m.Obj(.25*(running_ref2 - running*x2)**2 + .25*(running_ref1 - running*x1)**2 + (final*nav_goal[0] - final*x1)**2 + (final*nav_goal[1] -final*x2)**2 + (final*nav_goal[2] - final*x3)**2 ) 
    m.options.IMODE = 6
    m.options.NODES = 5
    m.options.MV_TYPE = 1
    m.options.SOLVER = 3 
    t = rospy.Time().now()
    m.solve()
    tf = rospy.Time().now()
    print("TIME TO SOLVE: ", (tf-t).to_sec())
    u_tape = np.vstack((v.value, phi.value))
    if m.options.OBJFCNVAL < 15:
        apply_sim_mpc_controls(x0,u_tape,dt, [x1.value,x2.value,x3.value])
    else:
        print("The Objective is too risky! Re-Pick Point")
    
def set_nav_goal_point(msg):
    global nav_goal
    nav_goal[0] = msg.pose.position.x
    nav_goal[1] = msg.pose.position.y
    qw = msg.pose.orientation.w
    qx = msg.pose.orientation.x
    qy = msg.pose.orientation.y
    qz = msg.pose.orientation.z

    xyz = tf.transformations.euler_from_quaternion([qx,qy,qz,qw])
    nav_goal[2] = xyz[2]
    #print("RPY: ", xyz)
    print("A New Goal Point of: ", nav_goal, " has been set!")
 """
def set_joy_cmd(msg):
    global cmd_msg
    MAX_SPEED = 1.25 
    MAX_ANGLE = np.pi / 6.0
    cmd_msg.header.stamp = rospy.Time(0).now()
    cmd_msg.drive.speed = msg.axes[1] * MAX_SPEED
    cmd_msg.drive.steering_angle = msg.axes[3] * MAX_ANGLE
    #cmd_pub.publish(cmd_msg)
    #update_model_joy()
""" 
def get3DVehiclePosition():
    gate = False
    while not gate:
        try:
            new_start_pos,rot = Odom2BL_lis.lookupTransform("/odom", "/base_link", rospy.Time(0))
            new_rpy = tf.transformations.euler_from_quaternion(rot)
            new_state = np.array([new_start_pos[0], new_start_pos[1],new_rpy[2]])
            #print("Set State from TF.. ", state)
            gate = True
            return new_state
        except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException):
            print("Asking TF..")
            rate.sleep()
            continue 

def apply_sim_mpc_controls(x0,u_tape,dt,xs, plot_mpc = False):
    # Time Update for dt
    global state, cmd_msg,Odom2BL_lis
    ctrl_rate = rospy.Rate(int(1.0/dt))
    actual_states = []
    actual_states.append(x0)
    for i in range(u_tape.shape[1]):
        time = rospy.Time().now()
        if i > 0:
            cmd_msg.drive.speed = u_tape[0,i]
            cmd_msg.drive.steering_angle = u_tape[1,i]
            #cmd_msg.drive.acceleration = (u_tape[0,i] - u_tape[0,i-1] ) / dt
            #cmd_msg.drive.steering_angle_velocity = (u_tape[1,i] - u_tape[1,i-1] ) / dt
        else:
            cmd_msg.drive.speed = u_tape[0,i]
            cmd_msg.drive.steering_angle = u_tape[1,i]
            #cmd_msg.drive.acceleration = u_tape[0,i] / dt
            #cmd_msg.drive.steering_angle_velocity = u_tape[1,i] / dt
        cmd_msg.header.stamp = time
        cmd_pub.publish(cmd_msg)
        ctrl_rate.sleep()
        if plot_mpc:
            actual_states.append(get3DVehiclePosition())

    cmd_msg.drive.speed = 0.0
    cmd_msg.drive.steering_angle = 0.0
    cmd_msg.drive.acceleration = 0.0
    cmd_msg.drive.steering_angle_velocity = 0.0
    cmd_pub.publish(cmd_msg)
    state = get3DVehiclePosition()
    print("Applied Control, Landed at: ", state)
    # Plot Final State and Control Histories
    if plot_mpc:
        plt.figure(1)
        plt.subplot(211)
        plt.title("Velocity, Steer Control Histories")
        plt.plot([i for i in range(len(u_tape[0,:]))], u_tape[0,:])
        plt.xlabel("Step")
        plt.ylabel("Velocity")
        plt.subplot(212)
        plt.plot([i for i in range(len(u_tape[1,:]))], u_tape[1,:])
        plt.xlabel("Step")
        plt.ylabel("Steer (rad)")
        plt.figure(2)
        plt.subplot(311)
        plt.title("X, Y, Yaw in 3D")
        plt.xlabel("Step")
        plt.ylabel("PosX (m)")
        plt.plot([i for i in range(len(actual_states))], [a[0] for a in actual_states],'r')
        plt.plot([i for i in range(len(xs[0]))], [x for x in xs[0]],'g')
        plt.subplot(312)
        plt.xlabel("Step")
        plt.ylabel("PosY (m)")
        plt.plot([i for i in range(len(actual_states))], [a[1] for a in actual_states],'r')
        plt.plot([i for i in range(len(xs[1]))], [x for x in xs[1]],'g')
        plt.subplot(313)
        plt.xlabel("Step")
        plt.ylabel("Yaw (rad)")
        plt.plot([i for i in range(len(actual_states))], [a[2] for a in actual_states],'r')
        plt.plot([i for i in range(len(xs[2]))], [x for x in xs[2]],'g')
        plt.show()
 """



#Modelled with Ackerman Steering Dynamics
#Needs Mutex for cmd_msg and cmd_pub...add
if __name__ == "__main__":
    cmd_sub = rospy.Subscriber("/joy", Joy, set_joy_cmd)
    #path_sub = rospy.Subscriber("/move_base/NavfnROS/plan", Path, mpc_traj_follow, queue_size=1)
    #nav_goal_sub = rospy.Subscriber("/move_base_simple/goal", PoseStamped, set_nav_goal_point)
    rate = rospy.Rate(15)
    while not rospy.is_shutdown():
        cmd_pub.publish(cmd_msg)
        rate.sleep()
    rospy.spin()
